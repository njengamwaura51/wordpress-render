<?php
/**
 * Ability: sparks/get-settings
 *
 * @package Codeinwp\Sparks\Abilities
 */

namespace Codeinwp\Sparks\Abilities;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Codeinwp\Sparks\Modules\Base_Module;
use Codeinwp\Sparks\Modules\Comparison_Table\Main as Comparison_Table;

/**
 * Class Read_Settings
 */
class Read_Settings extends Abstract_Ability {
	/**
	 * Get the ability name.
	 *
	 * @return lowercase-string&non-falsy-string
	 */
	public function get_name() {
		return 'sparks/get-settings';
	}

	/**
	 * Get the label.
	 *
	 * @return string
	 */
	public function get_label() {
		return __( 'Get Sparks settings', 'sparks-for-woocommerce' );
	}

	/**
	 * Get the description.
	 *
	 * @return string
	 */
	public function get_description() {
		return __( 'Reads the Sparks modules with their enabled state, and the typed settings shown on the Sparks dashboard (comparison table, wishlist, variation swatches, quick view) with their current and default values.', 'sparks-for-woocommerce' );
	}

	/**
	 * Get the input schema.
	 *
	 * @return array<string, mixed>
	 */
	public function get_input_schema() {
		return [
			'type'                 => 'object',
			'default'              => [],
			'additionalProperties' => false,
			'properties'           => [
				'module' => [
					'type'        => 'string',
					'description' => __( 'Only return this module, by slug (e.g. comparison_table, wish_list, variation_swatches).', 'sparks-for-woocommerce' ),
				],
			],
		];
	}

	/**
	 * Get the output schema.
	 *
	 * @return array<string, mixed>
	 */
	public function get_output_schema() {
		return [
			'type'       => 'object',
			'properties' => [
				'modules' => [
					'type'  => 'array',
					'items' => [
						'type'       => 'object',
						'properties' => [
							'slug'        => [ 'type' => 'string' ],
							'name'        => [ 'type' => 'string' ],
							'description' => [ 'type' => 'string' ],
							'enabled'     => [ 'type' => 'boolean' ],
							'settings'    => [
								'type'  => 'array',
								'items' => [
									'type'       => 'object',
									'properties' => [
										'key'     => [
											'type'        => 'string',
											'description' => __( 'Setting key, as accepted by sparks/update-settings.', 'sparks-for-woocommerce' ),
										],
										'type'    => [ 'type' => 'string' ],
										'value'   => [
											'description' => __( 'Current value. Its JSON type is given by "type".', 'sparks-for-woocommerce' ),
										],
										'default' => [
											'description' => __( 'Default value.', 'sparks-for-woocommerce' ),
										],
									],
								],
							],
						],
					],
				],
			],
		];
	}

	/**
	 * Get the annotations.
	 *
	 * @return array<string, bool>
	 */
	public function get_annotations() {
		return [
			'readonly'    => true,
			'destructive' => false,
			'idempotent'  => true,
		];
	}

	/**
	 * Permission check: same as the Sparks dashboard page and the core settings endpoint it saves through.
	 *
	 * @param mixed $input Ability input.
	 *
	 * @return bool
	 */
	public function has_permission( $input = null ) {
		return current_user_can( 'manage_options' );
	}

	/**
	 * Execute.
	 *
	 * @param mixed $input Ability input.
	 *
	 * @return array<string, mixed>|\WP_Error
	 */
	public function execute( $input = null ) {
		$input  = $this->normalize_input( $input );
		$filter = isset( $input['module'] ) ? sanitize_key( $input['module'] ) : '';

		if ( '' !== $filter && false === sparks()->module( $filter ) ) {
			return new \WP_Error( 'sparks_module_not_found', __( 'Unknown module slug.', 'sparks-for-woocommerce' ), [ 'status' => 404 ] );
		}

		return [
			'modules' => self::get_modules_data( $filter ),
		];
	}

	/**
	 * Get the settings registered by the Sparks modules (the ones the dashboard manages).
	 *
	 * @return array<string, array<string, mixed>> Registered setting args keyed by option name.
	 */
	public static function get_registered_settings() {
		$settings   = [];
		$registered = get_registered_settings();
		$groups     = wp_list_pluck( $registered, 'group' );

		foreach ( $registered as $option_key => $args ) {
			if ( ! isset( $groups[ $option_key ] ) || Base_Module::SETTING_GROUP !== $groups[ $option_key ] || empty( $args['show_in_rest'] ) ) {
				continue;
			}

			$settings[ (string) $option_key ] = $args;
		}

		return $settings;
	}

	/**
	 * Get the value schema of a registered setting, as the core settings endpoint builds it.
	 *
	 * @param array<string, mixed> $args Registered setting args.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_setting_schema( $args ) {
		$schema = [];

		if ( is_array( $args['show_in_rest'] ) && isset( $args['show_in_rest']['schema'] ) && is_array( $args['show_in_rest']['schema'] ) ) {
			$schema = $args['show_in_rest']['schema'];
		}

		if ( empty( $schema['type'] ) ) {
			$schema['type'] = empty( $args['type'] ) ? 'string' : $args['type'];
		}

		return $schema;
	}

	/**
	 * Get the modules with their settings.
	 *
	 * @param string $filter Optional module slug.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function get_modules_data( $filter = '' ) {
		$registered = self::get_registered_settings();
		$modules    = [];

		foreach ( sparks()->modules() as $module ) {
			if ( ! $module->can_be_managed_on_dashboard() ) {
				continue;
			}

			if ( '' !== $filter && $module->get_slug() !== $filter ) {
				continue;
			}

			$prefix     = sprintf( '%s_%s_', Base_Module::OPTION_PLUGIN_PREFIX, $module->get_setting_prefix() );
			$status_key = $module->get_status_option_key();
			$settings   = [];

			foreach ( $registered as $option_key => $args ) {
				if ( $option_key === $status_key ) {
					continue;
				}

				// The comparison table page option does not follow the prefix convention.
				$owned = 0 === strpos( $option_key, $prefix ) || ( Comparison_Table::PAGE_ID_OPTION === $option_key && $module instanceof Comparison_Table );

				if ( ! $owned ) {
					continue;
				}

				$default    = isset( $args['default'] ) ? $args['default'] : null;
				$schema     = self::get_setting_schema( $args );
				$settings[] = [
					'key'     => $option_key,
					'type'    => (string) $schema['type'],
					'value'   => get_option( $option_key, $default ),
					'default' => $default,
				];
			}

			$modules[] = [
				'slug'        => $module->get_slug(),
				'name'        => wp_strip_all_tags( $module->get_name() ),
				'description' => wp_strip_all_tags( $module->get_dashboard_description() ),
				'enabled'     => (bool) $module->get_status(),
				'settings'    => $settings,
			];
		}

		return $modules;
	}
}
