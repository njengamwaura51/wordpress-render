<?php
/**
 * Ability: sparks/list-global-tabs
 *
 * @package Codeinwp\Sparks\Abilities
 */

namespace Codeinwp\Sparks\Abilities;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Codeinwp\Sparks\Modules\Tab_Manager\Product_Tabs_Manager;

/**
 * Class List_Global_Tabs
 */
class List_Global_Tabs extends Abstract_Ability {
	/**
	 * Global tabs post type.
	 */
	const POST_TYPE = 'neve_product_tabs';

	/**
	 * Get the ability name.
	 *
	 * @return lowercase-string&non-falsy-string
	 */
	public function get_name() {
		return 'sparks/list-global-tabs';
	}

	/**
	 * Get the label.
	 *
	 * @return string
	 */
	public function get_label() {
		return __( 'List global product tabs', 'sparks-for-woocommerce' );
	}

	/**
	 * Get the description.
	 *
	 * @return string
	 */
	public function get_description() {
		return __( 'Lists the global product tabs in display order, with their visibility and the product categories they apply to. A tab without categories applies to all products. Pass an id to get a single tab with its content.', 'sparks-for-woocommerce' );
	}

	/**
	 * Get the input schema.
	 *
	 * @return array<string, mixed>
	 */
	public function get_input_schema() {
		return [
			'type'                 => 'object',
			'default'              => [],
			'additionalProperties' => false,
			'properties'           => [
				'id'              => [
					'type'        => 'integer',
					'minimum'     => 1,
					'description' => __( 'Return only this tab, including its content.', 'sparks-for-woocommerce' ),
				],
				'status'          => [
					'type'        => 'string',
					'enum'        => [ 'any', 'publish', 'draft' ],
					'default'     => 'any',
					'description' => __( 'Filter by post status.', 'sparks-for-woocommerce' ),
				],
				'category_id'     => [
					'type'        => 'integer',
					'minimum'     => 1,
					'description' => __( 'Only tabs assigned to this product category.', 'sparks-for-woocommerce' ),
				],
				'include_content' => [
					'type'        => 'boolean',
					'default'     => false,
					'description' => __( 'Include the tab content in the list.', 'sparks-for-woocommerce' ),
				],
			],
		];
	}

	/**
	 * Get the output schema.
	 *
	 * @return array<string, mixed>
	 */
	public function get_output_schema() {
		return [
			'type'       => 'object',
			'properties' => [
				'tabs'  => [
					'type'  => 'array',
					'items' => self::get_tab_schema(),
				],
				'total' => [ 'type' => 'integer' ],
				'limit' => [
					'type'        => 'integer',
					'description' => __( 'Maximum number of global tabs supported.', 'sparks-for-woocommerce' ),
				],
			],
		];
	}

	/**
	 * Get the schema of a tab.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_tab_schema() {
		return [
			'type'       => 'object',
			'properties' => [
				'id'           => [ 'type' => 'integer' ],
				'title'        => [ 'type' => 'string' ],
				'slug'         => [ 'type' => 'string' ],
				'type'         => [
					'type'        => 'string',
					'enum'        => [ 'core', 'global' ],
					'description' => __( 'Core tabs are the WooCommerce description, additional information and reviews tabs; only their visibility and order can change.', 'sparks-for-woocommerce' ),
				],
				'status'       => [ 'type' => 'string' ],
				'visible'      => [ 'type' => 'boolean' ],
				'order'        => [ 'type' => 'integer' ],
				'category_ids' => [
					'type'  => 'array',
					'items' => [ 'type' => 'integer' ],
				],
				'applies_to'   => [
					'type' => 'string',
					'enum' => [ 'all_products', 'categories' ],
				],
				'content'      => [ 'type' => 'string' ],
			],
		];
	}

	/**
	 * Get the annotations.
	 *
	 * @return array<string, bool>
	 */
	public function get_annotations() {
		return [
			'readonly'    => true,
			'destructive' => false,
			'idempotent'  => true,
		];
	}

	/**
	 * Get a capability of the global tabs post type.
	 *
	 * @param string $cap Capability key, e.g. edit_posts.
	 *
	 * @return string
	 */
	public static function get_post_type_cap( $cap ) {
		$post_type = get_post_type_object( self::POST_TYPE );

		if ( $post_type && isset( $post_type->cap->{$cap} ) ) {
			return (string) $post_type->cap->{$cap};
		}

		return $cap;
	}

	/**
	 * Permission check: same as the Product Tabs list screen.
	 *
	 * @param mixed $input Ability input.
	 *
	 * @return bool
	 */
	public function has_permission( $input = null ) {
		return current_user_can( self::get_post_type_cap( 'edit_posts' ) );
	}

	/**
	 * Execute.
	 *
	 * @param mixed $input Ability input.
	 *
	 * @return array<string, mixed>|\WP_Error
	 */
	public function execute( $input = null ) {
		$input = $this->normalize_input( $input );

		$module_check = $this->check_module( 'product_tabs_manager' );
		if ( is_wp_error( $module_check ) ) {
			return $module_check;
		}

		$id = isset( $input['id'] ) ? absint( $input['id'] ) : 0;

		if ( $id ) {
			$post = get_post( $id );
			if ( ! $post instanceof \WP_Post || self::POST_TYPE !== $post->post_type || 'trash' === $post->post_status || ! current_user_can( 'read_post', $post->ID ) ) {
				return new \WP_Error( 'sparks_tab_not_found', __( 'Global tab not found.', 'sparks-for-woocommerce' ), [ 'status' => 404 ] );
			}

			return [
				'tabs'  => [ $this->format_tab( $post, true ) ],
				'total' => 1,
				'limit' => Product_Tabs_Manager::MAX_GLOBAL_TABS_LIMIT,
			];
		}

		$status = isset( $input['status'] ) ? sanitize_key( $input['status'] ) : 'any';
		$args   = [
			'post_type'   => self::POST_TYPE,
			'post_status' => in_array( $status, [ 'publish', 'draft' ], true ) ? $status : [ 'publish', 'draft' ],
			'orderby'     => 'menu_order title',
			'order'       => 'ASC',
			'numberposts' => Product_Tabs_Manager::MAX_GLOBAL_TABS_LIMIT, // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_numberposts
		];

		if ( ! empty( $input['category_id'] ) ) {
			$args['tax_query'] = [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
				[
					'taxonomy'         => 'product_cat',
					'field'            => 'term_id',
					'terms'            => [ absint( $input['category_id'] ) ],
					'include_children' => false,
				],
			];
		}

		$include_content = ! empty( $input['include_content'] );
		$tabs            = [];

		foreach ( get_posts( $args ) as $post ) {
			if ( ! current_user_can( 'read_post', $post->ID ) ) {
				continue;
			}

			$tabs[] = $this->format_tab( $post, $include_content );
		}

		return [
			'tabs'  => $tabs,
			'total' => count( $tabs ),
			'limit' => Product_Tabs_Manager::MAX_GLOBAL_TABS_LIMIT,
		];
	}

	/**
	 * Decide if a global tab is one of the WooCommerce core tabs.
	 *
	 * @param \WP_Post $post Tab post.
	 *
	 * @return bool
	 */
	public static function is_core_tab( $post ) {
		return in_array( $post->post_name, Product_Tabs_Manager::CORE_TABS, true );
	}

	/**
	 * Format a global tab.
	 *
	 * @param \WP_Post $post Tab post.
	 * @param bool     $include_content Include the content.
	 *
	 * @return array<string, mixed>
	 */
	public function format_tab( $post, $include_content = false ) {
		$terms        = get_the_terms( $post->ID, 'product_cat' );
		$category_ids = is_array( $terms ) ? array_map( 'absint', wp_list_pluck( $terms, 'term_id' ) ) : [];

		$tab = [
			'id'           => $post->ID,
			'title'        => $post->post_title,
			'slug'         => $post->post_name,
			'type'         => self::is_core_tab( $post ) ? 'core' : 'global',
			'status'       => $post->post_status,
			'visible'      => 'no' !== get_post_meta( $post->ID, 'nv_tab_visibility', true ),
			'order'        => (int) $post->menu_order,
			'category_ids' => array_values( $category_ids ),
			'applies_to'   => empty( $category_ids ) ? 'all_products' : 'categories',
		];

		if ( $include_content ) {
			$tab['content'] = $post->post_content;
		}

		return $tab;
	}
}
