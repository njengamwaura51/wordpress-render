<?php
/**
 * Ability: sparks/update-product-extras
 *
 * @package Codeinwp\Sparks\Abilities
 */

namespace Codeinwp\Sparks\Abilities;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Codeinwp\Sparks\Modules\Custom_Thank_You\Main as Custom_Thank_You;
use Codeinwp\Sparks\Modules\Tab_Manager\Data_Product;

/**
 * Class Update_Product_Extras
 */
class Update_Product_Extras extends Abstract_Ability {
	/**
	 * Max number of the tabs accepted for a product.
	 */
	const MAX_TABS = 50;

	/**
	 * Get the ability name.
	 *
	 * @return lowercase-string&non-falsy-string
	 */
	public function get_name() {
		return 'sparks/update-product-extras';
	}

	/**
	 * Get the label.
	 *
	 * @return string
	 */
	public function get_label() {
		return __( 'Update product extras', 'sparks-for-woocommerce' );
	}

	/**
	 * Get the description.
	 *
	 * @return string
	 */
	public function get_description() {
		return __( 'Sets the product specific tab layout (core, global and custom tabs, in display order) and the custom thank you page of a WooCommerce product. Only the provided fields are changed. Returns the effective overrides.', 'sparks-for-woocommerce' );
	}

	/**
	 * Get the input schema.
	 *
	 * @return array<string, mixed>
	 */
	public function get_input_schema() {
		return [
			'type'                 => 'object',
			'required'             => [ 'product_id' ],
			'additionalProperties' => false,
			'properties'           => [
				'product_id'        => [
					'type'        => 'integer',
					'minimum'     => 1,
					'description' => __( 'The product ID.', 'sparks-for-woocommerce' ),
				],
				'tabs'              => [
					'type'        => 'array',
					'maxItems'    => self::MAX_TABS,
					'description' => __( 'Complete list of the tabs shown on this product, replacing the current product specific layout. The tabs are displayed in the list order, or by "order" when provided. An empty list removes the product specific layout so the product falls back to the global tabs.', 'sparks-for-woocommerce' ),
					'items'       => [
						'type'                 => 'object',
						'required'             => [ 'type' ],
						'additionalProperties' => false,
						'properties'           => [
							'type'    => [
								'type'        => 'string',
								'enum'        => [ 'core', 'global', 'custom' ],
								'description' => __( '"core" and "global" reference an existing global tab by id (see sparks/list-global-tabs). "custom" is a tab that only exists on this product.', 'sparks-for-woocommerce' ),
							],
							'id'      => [
								'type'        => 'integer',
								'minimum'     => 1,
								'description' => __( 'Required for core and global tabs: the global tab ID. Optional for custom tabs: the ID of an existing custom tab to keep.', 'sparks-for-woocommerce' ),
							],
							'title'   => [
								'type'        => 'string',
								'description' => __( 'Custom tabs only: the tab title.', 'sparks-for-woocommerce' ),
							],
							'content' => [
								'type'        => 'string',
								'description' => __( 'Custom tabs only: the tab content. Limited HTML is allowed.', 'sparks-for-woocommerce' ),
							],
							'order'   => [
								'type'        => 'integer',
								'description' => __( 'Optional sort position. Lower values come first.', 'sparks-for-woocommerce' ),
							],
						],
					],
				],
				'thank_you_page_id' => [
					'type'        => 'integer',
					'minimum'     => 0,
					'description' => __( 'ID of a published custom thank you page to use for this product. 0 removes the assignment.', 'sparks-for-woocommerce' ),
				],
			],
		];
	}

	/**
	 * Get the output schema.
	 *
	 * @return array<string, mixed>
	 */
	public function get_output_schema() {
		return [
			'type'       => 'object',
			'properties' => [
				'product_id'            => [ 'type' => 'integer' ],
				'tabs_override_enabled' => [ 'type' => 'boolean' ],
				'tabs'                  => [
					'type'  => 'array',
					'items' => [
						'type'       => 'object',
						'properties' => [
							'id'      => [ 'type' => 'integer' ],
							'type'    => [ 'type' => 'string' ],
							'slug'    => [ 'type' => 'string' ],
							'title'   => [ 'type' => 'string' ],
							'content' => [ 'type' => 'string' ],
						],
					],
				],
				'thank_you_page_id'     => [ 'type' => 'integer' ],
			],
		];
	}

	/**
	 * Get the annotations.
	 *
	 * @return array<string, bool>
	 */
	public function get_annotations() {
		return [
			'readonly'    => false,
			'destructive' => false,
			'idempotent'  => true,
		];
	}

	/**
	 * Permission check: same as saving the product on the product edit screen.
	 *
	 * @param mixed $input Ability input.
	 *
	 * @return bool
	 */
	public function has_permission( $input = null ) {
		$input      = $this->normalize_input( $input );
		$product_id = isset( $input['product_id'] ) ? absint( $input['product_id'] ) : 0;

		if ( ! $product_id ) {
			return current_user_can( 'edit_products' );
		}

		return current_user_can( 'edit_post', $product_id );
	}

	/**
	 * Execute.
	 *
	 * @param mixed $input Ability input.
	 *
	 * @return array<string, mixed>|\WP_Error
	 */
	public function execute( $input = null ) {
		$input      = $this->normalize_input( $input );
		$product_id = isset( $input['product_id'] ) ? absint( $input['product_id'] ) : 0;

		if ( ! $product_id || 'product' !== get_post_type( $product_id ) ) {
			return new \WP_Error( 'sparks_invalid_product', __( 'Invalid product ID.', 'sparks-for-woocommerce' ), [ 'status' => 404 ] );
		}

		$has_tabs      = array_key_exists( 'tabs', $input );
		$has_thank_you = array_key_exists( 'thank_you_page_id', $input );
		$tabs          = [];
		$thank_you_id  = 0;

		// Validate everything before writing anything.
		if ( $has_tabs ) {
			$module_check = $this->check_module( 'product_tabs_manager' );
			if ( is_wp_error( $module_check ) ) {
				return $module_check;
			}

			$tabs = $this->prepare_tabs( $product_id, $input['tabs'] );
			if ( is_wp_error( $tabs ) ) {
				return $tabs;
			}
		}

		if ( $has_thank_you ) {
			$module_check = $this->check_module( 'custom_thank_you' );
			if ( is_wp_error( $module_check ) ) {
				return $module_check;
			}

			$thank_you_id = absint( $input['thank_you_page_id'] );
			if ( $thank_you_id ) {
				$page = get_post( $thank_you_id );
				if ( ! $page instanceof \WP_Post || Custom_Thank_You::CUSTOM_THANK_YOU_CPT !== $page->post_type || 'publish' !== $page->post_status ) {
					return new \WP_Error( 'sparks_invalid_thank_you_page', __( 'The thank you page must be a published custom thank you page.', 'sparks-for-woocommerce' ), [ 'status' => 400 ] );
				}
			}
		}

		if ( $has_tabs ) {
			if ( empty( $tabs ) ) {
				delete_post_meta( $product_id, 'neve_override_tab_layout' );
				delete_post_meta( $product_id, Data_Product::META_KEY );
			} else {
				update_post_meta( $product_id, 'neve_override_tab_layout', 'on' );
				update_post_meta( $product_id, Data_Product::META_KEY, wp_slash( $tabs ) );
			}
		}

		if ( $has_thank_you ) {
			if ( $thank_you_id ) {
				update_post_meta( $product_id, '_nv_thank_you_page_id', $thank_you_id );
			} else {
				delete_post_meta( $product_id, '_nv_thank_you_page_id' );
			}
		}

		return $this->get_effective_overrides( $product_id );
	}

	/**
	 * Build the tabs data in the same shape the product edit screen stores.
	 *
	 * @param int   $product_id Product ID.
	 * @param mixed $raw_tabs Tabs input.
	 *
	 * @return array<int, array<string, mixed>>|\WP_Error
	 */
	private function prepare_tabs( $product_id, $raw_tabs ) {
		if ( ! is_array( $raw_tabs ) ) {
			return new \WP_Error( 'sparks_invalid_tabs', __( 'The tabs must be a list.', 'sparks-for-woocommerce' ), [ 'status' => 400 ] );
		}

		if ( count( $raw_tabs ) > self::MAX_TABS ) {
			return new \WP_Error( 'sparks_too_many_tabs', __( 'Too many tabs.', 'sparks-for-woocommerce' ), [ 'status' => 400 ] );
		}

		$raw_tabs = $this->sort_tabs( array_values( $raw_tabs ) );
		$tabs     = [];
		$used_ids = [];

		$existing_custom_ids = [];
		$existing            = Data_Product::get_tabs_data( $product_id );
		if ( is_array( $existing ) ) {
			foreach ( $existing as $existing_tab ) {
				if ( 'custom' === $existing_tab['type'] ) {
					$existing_custom_ids[] = (int) $existing_tab['id'];
				}
			}
		}

		foreach ( $raw_tabs as $index => $raw_tab ) {
			$raw_tab = $this->normalize_input( $raw_tab );
			$type    = isset( $raw_tab['type'] ) ? sanitize_key( $raw_tab['type'] ) : '';
			$id      = isset( $raw_tab['id'] ) ? absint( $raw_tab['id'] ) : 0;

			if ( ! in_array( $type, [ 'core', 'global', 'custom' ], true ) ) {
				return $this->tab_error( 'sparks_invalid_tab_type', $index, __( 'The tab type must be core, global or custom.', 'sparks-for-woocommerce' ) );
			}

			if ( 'custom' === $type ) {
				$title = isset( $raw_tab['title'] ) ? trim( (string) $raw_tab['title'] ) : '';
				if ( '' === $title ) {
					return $this->tab_error( 'sparks_missing_tab_title', $index, __( 'Custom tabs need a title.', 'sparks-for-woocommerce' ) );
				}

				// New custom tabs get a time based ID, as on the product edit screen.
				if ( ! $id || ! in_array( $id, $existing_custom_ids, true ) ) {
					$id = (int) round( microtime( true ) * 1000 ) + $index;
				}

				$content = isset( $raw_tab['content'] ) ? (string) $raw_tab['content'] : '';
				$tab     = [
					'id'      => $id,
					'title'   => esc_html( $title ),
					'content' => force_balance_tags( wp_kses( $content, Data_Product::get_allowed_html() ) ),
					'type'    => 'custom',
					'slug'    => (string) $id,
				];
			} else {
				$post = $id ? get_post( $id ) : null;
				if ( ! $post instanceof \WP_Post || 'neve_product_tabs' !== $post->post_type || 'publish' !== $post->post_status ) {
					return $this->tab_error( 'sparks_invalid_global_tab', $index, __( 'Core and global tabs must reference a published global tab by id.', 'sparks-for-woocommerce' ) );
				}

				$is_core = List_Global_Tabs::is_core_tab( $post );
				if ( ( 'core' === $type ) !== $is_core ) {
					return $this->tab_error( 'sparks_tab_type_mismatch', $index, __( 'The tab type does not match the referenced global tab.', 'sparks-for-woocommerce' ) );
				}

				$tab = [
					'id'      => $post->ID,
					'type'    => $type,
					'editUrl' => (string) get_edit_post_link( $post->ID, '' ),
					'slug'    => $post->post_name,
				];

				if ( $is_core ) {
					$tab['title'] = esc_html( $post->post_title );
				}
			}

			if ( in_array( $tab['id'], $used_ids, true ) ) {
				return $this->tab_error( 'sparks_duplicate_tab', $index, __( 'The same tab was listed more than once.', 'sparks-for-woocommerce' ) );
			}

			$used_ids[] = $tab['id'];
			$tabs[]     = $tab;
		}

		return $tabs;
	}

	/**
	 * Sort the tabs by the optional "order" field, keeping the list order otherwise.
	 *
	 * @param array<int, mixed> $raw_tabs Tabs input.
	 *
	 * @return array<int, mixed>
	 */
	private function sort_tabs( $raw_tabs ) {
		$sortable = [];
		foreach ( $raw_tabs as $index => $raw_tab ) {
			$tab_args   = $this->normalize_input( $raw_tab );
			$sortable[] = [
				'order' => isset( $tab_args['order'] ) ? (int) $tab_args['order'] : $index,
				'index' => $index,
				'tab'   => $raw_tab,
			];
		}

		usort(
			$sortable,
			function ( $a, $b ) {
				if ( $a['order'] === $b['order'] ) {
					return $a['index'] - $b['index'];
				}

				return $a['order'] - $b['order'];
			}
		);

		return array_column( $sortable, 'tab' );
	}

	/**
	 * Build an error for a tab item.
	 *
	 * @param string $code Error code.
	 * @param int    $index Tab index.
	 * @param string $message Error message.
	 *
	 * @return \WP_Error
	 */
	private function tab_error( $code, $index, $message ) {
		return new \WP_Error(
			$code,
			$message,
			[
				'status'    => 400,
				'tab_index' => $index,
			]
		);
	}

	/**
	 * Get the effective overrides of the product.
	 *
	 * @param int $product_id Product ID.
	 *
	 * @return array<string, mixed>
	 */
	private function get_effective_overrides( $product_id ) {
		$tabs   = Data_Product::get_tabs_data( $product_id );
		$output = [];

		if ( is_array( $tabs ) ) {
			foreach ( $tabs as $tab ) {
				$item = [
					'id'    => (int) $tab['id'],
					'type'  => (string) $tab['type'],
					'slug'  => (string) $tab['slug'],
					'title' => (string) $tab['title'],
				];

				if ( isset( $tab['content'] ) ) {
					$item['content'] = (string) $tab['content'];
				}

				$output[] = $item;
			}
		}

		return [
			'product_id'            => $product_id,
			'tabs_override_enabled' => 'on' === get_post_meta( $product_id, 'neve_override_tab_layout', true ),
			'tabs'                  => $output,
			'thank_you_page_id'     => (int) get_post_meta( $product_id, '_nv_thank_you_page_id', true ),
		];
	}
}
