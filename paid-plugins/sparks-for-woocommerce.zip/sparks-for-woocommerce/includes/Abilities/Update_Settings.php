<?php
/**
 * Ability: sparks/update-settings
 *
 * @package Codeinwp\Sparks\Abilities
 */

namespace Codeinwp\Sparks\Abilities;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Update_Settings
 */
class Update_Settings extends Read_Settings {
	/**
	 * Max number of the settings accepted in a call.
	 */
	const MAX_SETTINGS = 100;

	/**
	 * Get the ability name.
	 *
	 * @return lowercase-string&non-falsy-string
	 */
	public function get_name() {
		return 'sparks/update-settings';
	}

	/**
	 * Get the label.
	 *
	 * @return string
	 */
	public function get_label() {
		return __( 'Update Sparks settings', 'sparks-for-woocommerce' );
	}

	/**
	 * Get the description.
	 *
	 * @return string
	 */
	public function get_description() {
		return __( 'Enables or disables Sparks modules and updates the typed settings of the Sparks dashboard. Only the provided values change; everything is validated before anything is saved. Use sparks/get-settings for the available keys and types. Returns the effective settings.', 'sparks-for-woocommerce' );
	}

	/**
	 * Get the input schema.
	 *
	 * @return array<string, mixed>
	 */
	public function get_input_schema() {
		return [
			'type'                 => 'object',
			'additionalProperties' => false,
			'properties'           => [
				'modules'  => [
					'type'                 => 'object',
					'description'          => __( 'Module toggles: module slug => enabled, e.g. {"wish_list": true}.', 'sparks-for-woocommerce' ),
					'additionalProperties' => [ 'type' => 'boolean' ],
				],
				'settings' => [
					'type'                 => 'object',
					'description'          => __( 'Setting values: setting key (from sparks/get-settings) => value of the type of that setting.', 'sparks-for-woocommerce' ),
					'additionalProperties' => true,
				],
			],
		];
	}

	/**
	 * Get the output schema.
	 *
	 * @return array<string, mixed>
	 */
	public function get_output_schema() {
		$schema = parent::get_output_schema();

		$schema['properties']['updated'] = [
			'type'        => 'array',
			'description' => __( 'Option keys whose stored value changed.', 'sparks-for-woocommerce' ),
			'items'       => [ 'type' => 'string' ],
		];

		return $schema;
	}

	/**
	 * Get the annotations.
	 *
	 * @return array<string, bool>
	 */
	public function get_annotations() {
		return [
			'readonly'    => false,
			'destructive' => false,
			'idempotent'  => true,
		];
	}

	/**
	 * Execute.
	 *
	 * @param mixed $input Ability input.
	 *
	 * @return array<string, mixed>|\WP_Error
	 */
	public function execute( $input = null ) {
		$input      = $this->normalize_input( $input );
		$toggles    = isset( $input['modules'] ) ? $this->normalize_input( $input['modules'] ) : [];
		$settings   = isset( $input['settings'] ) ? $this->normalize_input( $input['settings'] ) : [];
		$registered = self::get_registered_settings();
		$values     = [];

		if ( empty( $toggles ) && empty( $settings ) ) {
			return new \WP_Error( 'sparks_nothing_to_update', __( 'Provide module toggles or settings to update.', 'sparks-for-woocommerce' ), [ 'status' => 400 ] );
		}

		if ( count( $toggles ) + count( $settings ) > self::MAX_SETTINGS ) {
			return new \WP_Error( 'sparks_too_many_settings', __( 'Too many settings in one call.', 'sparks-for-woocommerce' ), [ 'status' => 400 ] );
		}

		foreach ( $toggles as $slug => $enabled ) {
			$module = sparks()->module( sanitize_key( (string) $slug ) );

			if ( false === $module || ! $module->can_be_managed_on_dashboard() ) {
				return new \WP_Error(
					'sparks_module_not_found',
					/* translators: %s: module slug */
					sprintf( __( 'Unknown module "%s".', 'sparks-for-woocommerce' ), (string) $slug ),
					[ 'status' => 400 ]
				);
			}

			$settings[ $module->get_status_option_key() ] = $enabled;
		}

		// Validate everything first, as the core settings endpoint does for each value.
		foreach ( $settings as $option_key => $value ) {
			$option_key = (string) $option_key;

			if ( ! isset( $registered[ $option_key ] ) ) {
				return new \WP_Error(
					'sparks_unknown_setting',
					/* translators: %s: setting key */
					sprintf( __( 'Unknown setting "%s".', 'sparks-for-woocommerce' ), $option_key ),
					[ 'status' => 400 ]
				);
			}

			$schema = self::get_setting_schema( $registered[ $option_key ] );
			$valid  = rest_validate_value_from_schema( $value, $schema, $option_key );

			if ( is_wp_error( $valid ) ) {
				return new \WP_Error(
					'sparks_invalid_setting',
					$valid->get_error_message(),
					[
						'status'  => 400,
						'setting' => $option_key,
					]
				);
			}

			$sanitized = rest_sanitize_value_from_schema( $value, $schema, $option_key );
			if ( is_wp_error( $sanitized ) ) {
				return new \WP_Error(
					'sparks_invalid_setting',
					$sanitized->get_error_message(),
					[
						'status'  => 400,
						'setting' => $option_key,
					]
				);
			}

			$values[ $option_key ] = $sanitized;
		}

		$updated = [];

		// The sanitize callbacks registered by the modules run inside update_option().
		foreach ( $values as $option_key => $value ) {
			if ( update_option( $option_key, $value ) ) {
				$updated[] = $option_key;
			}
		}

		return [
			'updated' => $updated,
			'modules' => self::get_modules_data(),
		];
	}
}
