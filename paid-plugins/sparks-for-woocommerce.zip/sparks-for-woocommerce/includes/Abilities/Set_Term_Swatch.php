<?php
/**
 * Ability: sparks/set-term-swatch
 *
 * @package Codeinwp\Sparks\Abilities
 */

namespace Codeinwp\Sparks\Abilities;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Codeinwp\Sparks\Modules\Variation_Swatches\Admin;

/**
 * Class Set_Term_Swatch
 */
class Set_Term_Swatch extends Abstract_Ability {
	/**
	 * Attribute types handled by the Variation Swatches module.
	 */
	const SWATCH_TYPES = [ 'color', 'image', 'label' ];

	/**
	 * Get the ability name.
	 *
	 * @return lowercase-string&non-falsy-string
	 */
	public function get_name() {
		return 'sparks/set-term-swatch';
	}

	/**
	 * Get the label.
	 *
	 * @return string
	 */
	public function get_label() {
		return __( 'Set attribute term swatch', 'sparks-for-woocommerce' );
	}

	/**
	 * Get the description.
	 *
	 * @return string
	 */
	public function get_description() {
		return __( 'Sets or removes the color, image or label swatch of a product attribute term. The swatch type is defined by the attribute type (color, image or label) and must match it.', 'sparks-for-woocommerce' );
	}

	/**
	 * Get the input schema.
	 *
	 * @return array<string, mixed>
	 */
	public function get_input_schema() {
		return [
			'type'                 => 'object',
			'required'             => [ 'attribute', 'term_id' ],
			'additionalProperties' => false,
			'properties'           => [
				'attribute' => [
					'type'        => 'string',
					'description' => __( 'The global product attribute, as a taxonomy name (pa_color) or attribute slug (color).', 'sparks-for-woocommerce' ),
				],
				'term_id'   => [
					'type'        => 'integer',
					'minimum'     => 1,
					'description' => __( 'The attribute term ID.', 'sparks-for-woocommerce' ),
				],
				'swatch'    => [
					'type'                 => 'object',
					'required'             => [ 'type' ],
					'additionalProperties' => false,
					'description'          => __( 'The swatch to store. Omit it and set "remove" to delete the stored swatch.', 'sparks-for-woocommerce' ),
					'properties'           => [
						'type'     => [
							'type' => 'string',
							'enum' => self::SWATCH_TYPES,
						],
						'color'    => [
							'type'        => 'string',
							'description' => __( 'Hex color, e.g. #ff0000. Used by color swatches.', 'sparks-for-woocommerce' ),
						],
						'image_id' => [
							'type'        => 'integer',
							'minimum'     => 1,
							'description' => __( 'Media library image ID. Used by image swatches.', 'sparks-for-woocommerce' ),
						],
						'label'    => [
							'type'        => 'string',
							'description' => __( 'Short text. Used by label swatches.', 'sparks-for-woocommerce' ),
						],
					],
				],
				'remove'    => [
					'type'        => 'boolean',
					'default'     => false,
					'description' => __( 'Remove the stored swatch of the term.', 'sparks-for-woocommerce' ),
				],
			],
		];
	}

	/**
	 * Get the output schema.
	 *
	 * @return array<string, mixed>
	 */
	public function get_output_schema() {
		return [
			'type'       => 'object',
			'properties' => [
				'taxonomy'  => [ 'type' => 'string' ],
				'term_id'   => [ 'type' => 'integer' ],
				'term_name' => [ 'type' => 'string' ],
				'type'      => [ 'type' => 'string' ],
				'value'     => [
					'type'        => 'string',
					'description' => __( 'Stored swatch value: hex color, image URL or label. Empty when no swatch is stored.', 'sparks-for-woocommerce' ),
				],
			],
		];
	}

	/**
	 * Get the annotations.
	 *
	 * @return array<string, bool>
	 */
	public function get_annotations() {
		return [
			'readonly'    => false,
			'destructive' => false,
			'idempotent'  => true,
		];
	}

	/**
	 * Permission check: same as the attribute term edit screen where the swatch field lives.
	 *
	 * @param mixed $input Ability input.
	 *
	 * @return bool
	 */
	public function has_permission( $input = null ) {
		$input   = $this->normalize_input( $input );
		$term_id = isset( $input['term_id'] ) ? absint( $input['term_id'] ) : 0;

		if ( ! $term_id ) {
			return current_user_can( 'edit_product_terms' );
		}

		return current_user_can( 'edit_term', $term_id );
	}

	/**
	 * Execute.
	 *
	 * @param mixed $input Ability input.
	 *
	 * @return array<string, mixed>|\WP_Error
	 */
	public function execute( $input = null ) {
		$input = $this->normalize_input( $input );

		$module_check = $this->check_module( 'variation_swatches' );
		if ( is_wp_error( $module_check ) ) {
			return $module_check;
		}

		$attribute = isset( $input['attribute'] ) ? sanitize_title( (string) $input['attribute'] ) : '';
		$taxonomy  = 0 === strpos( $attribute, 'pa_' ) ? $attribute : wc_attribute_taxonomy_name( $attribute );
		$type      = $this->get_attribute_type( $taxonomy );

		if ( false === $type || ! taxonomy_exists( $taxonomy ) ) {
			return new \WP_Error( 'sparks_invalid_attribute', __( 'The product attribute does not exist.', 'sparks-for-woocommerce' ), [ 'status' => 404 ] );
		}

		if ( ! in_array( $type, self::SWATCH_TYPES, true ) ) {
			return new \WP_Error(
				'sparks_attribute_not_swatch',
				/* translators: %s: attribute type */
				sprintf( __( 'The attribute type is "%s". Change the attribute type to color, image or label before setting swatches.', 'sparks-for-woocommerce' ), $type ),
				[ 'status' => 400 ]
			);
		}

		$term_id = isset( $input['term_id'] ) ? absint( $input['term_id'] ) : 0;
		$term    = get_term( $term_id, $taxonomy );
		if ( ! $term instanceof \WP_Term ) {
			return new \WP_Error( 'sparks_invalid_term', __( 'The term does not belong to the attribute.', 'sparks-for-woocommerce' ), [ 'status' => 404 ] );
		}

		$meta_key = 'product_' . $taxonomy;
		$swatch   = isset( $input['swatch'] ) ? $this->normalize_input( $input['swatch'] ) : [];

		if ( empty( $swatch ) ) {
			if ( empty( $input['remove'] ) ) {
				return new \WP_Error( 'sparks_missing_swatch', __( 'Provide a swatch, or set "remove" to delete the stored one.', 'sparks-for-woocommerce' ), [ 'status' => 400 ] );
			}

			delete_term_meta( $term_id, $meta_key );

			return $this->get_output( $term, $taxonomy, $type );
		}

		$swatch_type = isset( $swatch['type'] ) ? sanitize_key( $swatch['type'] ) : '';
		if ( $swatch_type !== $type ) {
			return new \WP_Error(
				'sparks_swatch_type_mismatch',
				/* translators: %s: attribute type */
				sprintf( __( 'This attribute only accepts "%s" swatches.', 'sparks-for-woocommerce' ), $type ),
				[ 'status' => 400 ]
			);
		}

		$value = $this->get_swatch_value( $swatch, $type );
		if ( '' === $value ) {
			return new \WP_Error( 'sparks_invalid_swatch_value', __( 'The swatch value is missing or not valid for this swatch type.', 'sparks-for-woocommerce' ), [ 'status' => 400 ] );
		}

		update_term_meta( $term_id, $meta_key, wp_slash( $value ) );

		return $this->get_output( $term, $taxonomy, $type );
	}

	/**
	 * Get the sanitized value to store, using the module's own sanitization.
	 *
	 * @param array<string, mixed> $swatch Swatch input.
	 * @param string               $type Attribute type.
	 *
	 * @return string Empty string if the value is not valid.
	 */
	private function get_swatch_value( $swatch, $type ) {
		$value = '';

		switch ( $type ) {
			case 'color':
				$value = isset( $swatch['color'] ) ? (string) sanitize_hex_color( trim( (string) $swatch['color'] ) ) : '';
				break;
			case 'image':
				$image_id = isset( $swatch['image_id'] ) ? absint( $swatch['image_id'] ) : 0;
				if ( $image_id && wp_attachment_is_image( $image_id ) ) {
					$value = (string) wp_get_attachment_url( $image_id );
				}
				break;
			case 'label':
				$value = isset( $swatch['label'] ) ? trim( (string) $swatch['label'] ) : '';
				break;
		}

		if ( '' === $value ) {
			return '';
		}

		return (string) ( new Admin() )->sanitize_term_value( wp_kses_post( $value ), $type );
	}

	/**
	 * Get the attribute type of a taxonomy.
	 *
	 * @param string $taxonomy Taxonomy name.
	 *
	 * @return string|false
	 */
	private function get_attribute_type( $taxonomy ) {
		foreach ( wc_get_attribute_taxonomies() as $tax ) {
			if ( 'pa_' . $tax->attribute_name === $taxonomy ) {
				return (string) $tax->attribute_type;
			}
		}

		return false;
	}

	/**
	 * Build the output.
	 *
	 * @param \WP_Term $term Term.
	 * @param string   $taxonomy Taxonomy name.
	 * @param string   $type Attribute type.
	 *
	 * @return array<string, mixed>
	 */
	private function get_output( $term, $taxonomy, $type ) {
		return [
			'taxonomy'  => $taxonomy,
			'term_id'   => $term->term_id,
			'term_name' => $term->name,
			'type'      => $type,
			'value'     => (string) get_term_meta( $term->term_id, 'product_' . $taxonomy, true ),
		];
	}
}
