<?php
/**
 * Registers the Sparks abilities with the WordPress Abilities API.
 *
 * @package Codeinwp\Sparks\Abilities
 */

namespace Codeinwp\Sparks\Abilities;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Registrar
 */
class Registrar {
	/**
	 * Ability category slug.
	 */
	const CATEGORY = 'sparks';

	/**
	 * Hook the registration callbacks.
	 *
	 * @return void
	 */
	public function init() {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		add_action( 'wp_abilities_api_categories_init', [ $this, 'register_category' ] );
		add_action( 'wp_abilities_api_init', [ $this, 'register_abilities' ] );
	}

	/**
	 * Register the ability category.
	 *
	 * @return void
	 */
	public function register_category() {
		if ( ! function_exists( 'wp_register_ability_category' ) ) {
			return;
		}

		wp_register_ability_category(
			self::CATEGORY,
			[
				'label'       => __( 'Sparks for WooCommerce', 'sparks-for-woocommerce' ),
				'description' => __( 'Merchandising features of Sparks for WooCommerce: product tabs, variation swatches, thank you pages and module settings.', 'sparks-for-woocommerce' ),
			]
		);
	}

	/**
	 * Register the abilities.
	 *
	 * @return void
	 */
	public function register_abilities() {
		$abilities = [
			new Update_Product_Extras(),
			new Set_Term_Swatch(),
			new List_Global_Tabs(),
			new Upsert_Global_Tab(),
			new Read_Settings(),
			new Update_Settings(),
		];

		foreach ( $abilities as $ability ) {
			$ability->register();
		}
	}
}
