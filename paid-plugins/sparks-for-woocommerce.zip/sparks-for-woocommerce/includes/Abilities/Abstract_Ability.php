<?php
/**
 * Base class of the Sparks abilities.
 *
 * @package Codeinwp\Sparks\Abilities
 */

namespace Codeinwp\Sparks\Abilities;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Codeinwp\Sparks\Core\Loader;

/**
 * Class Abstract_Ability
 */
abstract class Abstract_Ability {
	/**
	 * Get the ability name, e.g. "sparks/list-global-tabs".
	 *
	 * @return lowercase-string&non-falsy-string
	 */
	abstract public function get_name();

	/**
	 * Get the human readable label.
	 *
	 * @return string
	 */
	abstract public function get_label();

	/**
	 * Get the description.
	 *
	 * @return string
	 */
	abstract public function get_description();

	/**
	 * Get the input JSON schema.
	 *
	 * @return array<string, mixed>
	 */
	abstract public function get_input_schema();

	/**
	 * Get the output JSON schema.
	 *
	 * @return array<string, mixed>
	 */
	abstract public function get_output_schema();

	/**
	 * Get the behaviour annotations.
	 *
	 * @return array<string, bool>
	 */
	abstract public function get_annotations();

	/**
	 * Check if the current user can run the ability.
	 *
	 * @param mixed $input Ability input.
	 *
	 * @return bool|\WP_Error
	 */
	abstract public function has_permission( $input = null );

	/**
	 * Run the ability.
	 *
	 * @param mixed $input Ability input.
	 *
	 * @return array<string, mixed>|\WP_Error
	 */
	abstract public function execute( $input = null );

	/**
	 * Register the ability.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		wp_register_ability(
			$this->get_name(),
			[
				'label'               => $this->get_label(),
				'description'         => $this->get_description(),
				'category'            => Registrar::CATEGORY,
				'input_schema'        => $this->get_input_schema(),
				'output_schema'       => $this->get_output_schema(),
				'execute_callback'    => [ $this, 'execute' ],
				'permission_callback' => [ $this, 'has_permission' ],
				'meta'                => [
					'annotations'  => $this->get_annotations(),
					'show_in_rest' => true,
				],
			]
		);
	}

	/**
	 * Normalize the ability input to an array.
	 *
	 * @param mixed $input Ability input.
	 *
	 * @return array<string, mixed>
	 */
	protected function normalize_input( $input ) {
		if ( is_object( $input ) ) {
			$input = (array) $input;
		}

		return is_array( $input ) ? $input : [];
	}

	/**
	 * Returns an error if the given Sparks module is not running (disabled or the license is not valid).
	 *
	 * @param string $module_slug Module slug.
	 *
	 * @return true|\WP_Error
	 */
	protected function check_module( $module_slug ) {
		$module = sparks()->module( $module_slug );

		if ( false === $module ) {
			return new \WP_Error(
				'sparks_module_not_found',
				/* translators: %s: module slug */
				sprintf( __( 'The "%s" Sparks module is not available.', 'sparks-for-woocommerce' ), $module_slug ),
				[ 'status' => 400 ]
			);
		}

		if ( 'valid' !== Loader::get_instance()->get_license_status() ) {
			return new \WP_Error(
				'sparks_license_inactive',
				__( 'Sparks modules only run with a valid license.', 'sparks-for-woocommerce' ),
				[ 'status' => 400 ]
			);
		}

		if ( ! $module->get_status() ) {
			return new \WP_Error(
				'sparks_module_inactive',
				/* translators: %s: module name */
				sprintf( __( 'The "%s" module is disabled. Enable it first.', 'sparks-for-woocommerce' ), $module->get_name() ),
				[ 'status' => 400 ]
			);
		}

		return true;
	}
}
