<?php
/**
 * Ability: sparks/upsert-global-tab
 *
 * @package Codeinwp\Sparks\Abilities
 */

namespace Codeinwp\Sparks\Abilities;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Codeinwp\Sparks\Modules\Tab_Manager\Product_Tabs_Manager;

/**
 * Class Upsert_Global_Tab
 */
class Upsert_Global_Tab extends List_Global_Tabs {
	/**
	 * Max number of the categories accepted for a tab.
	 */
	const MAX_CATEGORIES = 100;

	/**
	 * Get the ability name.
	 *
	 * @return lowercase-string&non-falsy-string
	 */
	public function get_name() {
		return 'sparks/upsert-global-tab';
	}

	/**
	 * Get the label.
	 *
	 * @return string
	 */
	public function get_label() {
		return __( 'Create or update a global product tab', 'sparks-for-woocommerce' );
	}

	/**
	 * Get the description.
	 *
	 * @return string
	 */
	public function get_description() {
		return __( 'Creates a global product tab, or updates one when an id is given. Only the provided fields are changed. A tab without categories is shown on all products; with categories it is only shown on products of those categories. Core tabs only accept visible and order.', 'sparks-for-woocommerce' );
	}

	/**
	 * Get the input schema.
	 *
	 * @return array<string, mixed>
	 */
	public function get_input_schema() {
		return [
			'type'                 => 'object',
			'additionalProperties' => false,
			'properties'           => [
				'id'           => [
					'type'        => 'integer',
					'minimum'     => 1,
					'description' => __( 'ID of the tab to update. Omit to create a new tab.', 'sparks-for-woocommerce' ),
				],
				'title'        => [
					'type'        => 'string',
					'description' => __( 'Tab title. Required when creating.', 'sparks-for-woocommerce' ),
				],
				'content'      => [
					'type'        => 'string',
					'description' => __( 'Tab content (HTML or block markup).', 'sparks-for-woocommerce' ),
				],
				'category_ids' => [
					'type'        => 'array',
					'maxItems'    => self::MAX_CATEGORIES,
					'items'       => [
						'type'    => 'integer',
						'minimum' => 1,
					],
					'description' => __( 'Product category IDs the tab applies to, replacing the current ones. An empty list applies the tab to all products.', 'sparks-for-woocommerce' ),
				],
				'visible'      => [
					'type'        => 'boolean',
					'description' => __( 'Show or hide the tab on the product pages.', 'sparks-for-woocommerce' ),
				],
				'order'        => [
					'type'        => 'integer',
					'minimum'     => 0,
					'description' => __( 'Display position. Lower values come first.', 'sparks-for-woocommerce' ),
				],
				'status'       => [
					'type'        => 'string',
					'enum'        => [ 'publish', 'draft' ],
					'description' => __( 'Post status. Draft tabs are not displayed. Defaults to publish for new tabs.', 'sparks-for-woocommerce' ),
				],
			],
		];
	}

	/**
	 * Get the output schema.
	 *
	 * @return array<string, mixed>
	 */
	public function get_output_schema() {
		return [
			'type'       => 'object',
			'properties' => [
				'created' => [ 'type' => 'boolean' ],
				'tab'     => self::get_tab_schema(),
			],
		];
	}

	/**
	 * Get the annotations.
	 *
	 * @return array<string, bool>
	 */
	public function get_annotations() {
		return [
			'readonly'    => false,
			'destructive' => false,
			'idempotent'  => true,
		];
	}

	/**
	 * Permission check.
	 *
	 * Mirrors the Product Tabs screens: post type capabilities for the tab itself, "edit_products" for
	 * the visibility and order (as the module REST routes) and the product category assign capability.
	 *
	 * @param mixed $input Ability input.
	 *
	 * @return bool
	 */
	public function has_permission( $input = null ) {
		$input = $this->normalize_input( $input );
		$id    = isset( $input['id'] ) ? absint( $input['id'] ) : 0;

		if ( ! current_user_can( self::get_post_type_cap( 'edit_posts' ) ) ) {
			return false;
		}

		if ( $id ) {
			if ( ! current_user_can( 'edit_post', $id ) ) {
				return false;
			}
		} elseif ( ! current_user_can( self::get_post_type_cap( 'create_posts' ) ) ) {
			return false;
		}

		$publishes = $id ? ( isset( $input['status'] ) && 'publish' === $input['status'] ) : ( ! isset( $input['status'] ) || 'publish' === $input['status'] );
		if ( $publishes && ! current_user_can( self::get_post_type_cap( 'publish_posts' ) ) ) {
			return false;
		}

		if ( ( array_key_exists( 'visible', $input ) || array_key_exists( 'order', $input ) ) && ! current_user_can( 'edit_products' ) ) {
			return false;
		}

		if ( array_key_exists( 'category_ids', $input ) ) {
			$taxonomy = get_taxonomy( 'product_cat' );
			if ( ! $taxonomy || ! current_user_can( $taxonomy->cap->assign_terms ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Execute.
	 *
	 * @param mixed $input Ability input.
	 *
	 * @return array<string, mixed>|\WP_Error
	 */
	public function execute( $input = null ) {
		$input = $this->normalize_input( $input );

		$module_check = $this->check_module( 'product_tabs_manager' );
		if ( is_wp_error( $module_check ) ) {
			return $module_check;
		}

		$id      = isset( $input['id'] ) ? absint( $input['id'] ) : 0;
		$is_core = false;

		if ( $id ) {
			$post = get_post( $id );
			if ( ! $post instanceof \WP_Post || self::POST_TYPE !== $post->post_type || 'trash' === $post->post_status ) {
				return new \WP_Error( 'sparks_tab_not_found', __( 'Global tab not found.', 'sparks-for-woocommerce' ), [ 'status' => 404 ] );
			}

			$is_core = self::is_core_tab( $post );
		} elseif ( (int) get_option( Product_Tabs_Manager::OPTION_POST_COUNT, 0 ) >= Product_Tabs_Manager::MAX_GLOBAL_TABS_LIMIT ) {
			return new \WP_Error(
				'sparks_tab_limit_reached',
				/* translators: %d: number of the allowed global custom tabs */
				sprintf( __( 'The maximum number(%d) of allowed Global Custom Tabs has been reached, therefore creating new Global Custom Tabs is restricted.', 'sparks-for-woocommerce' ), Product_Tabs_Manager::MAX_GLOBAL_TABS_LIMIT ),
				[ 'status' => 400 ]
			);
		}

		if ( $is_core && array_intersect( [ 'title', 'content', 'category_ids', 'status' ], array_keys( $input ) ) ) {
			return new \WP_Error( 'sparks_core_tab_locked', __( 'Only the visibility and the order of a core tab can be changed.', 'sparks-for-woocommerce' ), [ 'status' => 400 ] );
		}

		$postarr = [];

		if ( array_key_exists( 'title', $input ) ) {
			$postarr['post_title'] = sanitize_text_field( (string) $input['title'] );
		}

		if ( ( ! $id || array_key_exists( 'title', $input ) ) && ( ! isset( $postarr['post_title'] ) || '' === $postarr['post_title'] ) ) {
			return new \WP_Error( 'sparks_missing_tab_title', __( 'The tab title is required.', 'sparks-for-woocommerce' ), [ 'status' => 400 ] );
		}

		if ( array_key_exists( 'content', $input ) ) {
			$postarr['post_content'] = (string) $input['content'];
		}

		if ( array_key_exists( 'status', $input ) ) {
			$status = sanitize_key( $input['status'] );
			if ( ! in_array( $status, [ 'publish', 'draft' ], true ) ) {
				return new \WP_Error( 'sparks_invalid_status', __( 'The status must be publish or draft.', 'sparks-for-woocommerce' ), [ 'status' => 400 ] );
			}
			$postarr['post_status'] = $status;
		}

		if ( array_key_exists( 'order', $input ) ) {
			$postarr['menu_order'] = absint( $input['order'] );
		}

		$category_ids = null;
		if ( array_key_exists( 'category_ids', $input ) ) {
			$category_ids = $this->prepare_category_ids( $input['category_ids'] );
			if ( is_wp_error( $category_ids ) ) {
				return $category_ids;
			}
		}

		if ( $id ) {
			if ( ! empty( $postarr ) ) {
				$postarr['ID'] = $id;
				$result        = wp_update_post( wp_slash( $postarr ), true );
				if ( is_wp_error( $result ) ) {
					return $result;
				}
			}
		} else {
			$postarr['post_type'] = self::POST_TYPE;
			if ( ! isset( $postarr['post_status'] ) ) {
				$postarr['post_status'] = 'publish';
			}

			$result = wp_insert_post( wp_slash( $postarr ), true );
			if ( is_wp_error( $result ) ) {
				return $result;
			}

			$id = (int) $result;

			// New tabs go last, as when they are created on the Product Tabs screen.
			if ( ! isset( $postarr['menu_order'] ) ) {
				wp_update_post(
					[
						'ID'         => $id,
						'menu_order' => $id,
					]
				);
			}
		}

		if ( isset( $postarr['menu_order'] ) ) {
			wp_cache_delete( 'neve_pt_menu_orders_cache' );
		}

		if ( is_array( $category_ids ) ) {
			$terms_result = wp_set_object_terms( $id, $category_ids, 'product_cat' );
			if ( is_wp_error( $terms_result ) ) {
				return $terms_result;
			}
		}

		if ( array_key_exists( 'visible', $input ) ) {
			update_post_meta( $id, 'nv_tab_visibility', ! empty( $input['visible'] ) ? 'yes' : 'no' );
		}

		$post = get_post( $id );
		if ( ! $post instanceof \WP_Post ) {
			return new \WP_Error( 'sparks_tab_not_found', __( 'Global tab not found.', 'sparks-for-woocommerce' ), [ 'status' => 404 ] );
		}

		return [
			'created' => ! isset( $input['id'] ) || ! absint( $input['id'] ),
			'tab'     => $this->format_tab( $post, true ),
		];
	}

	/**
	 * Validate the product category IDs.
	 *
	 * @param mixed $raw_ids Category IDs input.
	 *
	 * @return int[]|\WP_Error
	 */
	private function prepare_category_ids( $raw_ids ) {
		if ( ! is_array( $raw_ids ) || count( $raw_ids ) > self::MAX_CATEGORIES ) {
			return new \WP_Error( 'sparks_invalid_categories', __( 'The category IDs must be a list.', 'sparks-for-woocommerce' ), [ 'status' => 400 ] );
		}

		$category_ids = array_values( array_unique( array_filter( array_map( 'absint', $raw_ids ) ) ) );

		foreach ( $category_ids as $category_id ) {
			if ( ! get_term( $category_id, 'product_cat' ) instanceof \WP_Term ) {
				return new \WP_Error(
					'sparks_invalid_category',
					/* translators: %d: category ID */
					sprintf( __( 'Product category %d does not exist.', 'sparks-for-woocommerce' ), $category_id ),
					[ 'status' => 400 ]
				);
			}
		}

		return $category_ids;
	}
}
