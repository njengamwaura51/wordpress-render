<?php
/**
 * Sparks Functions to Wrap WP/WooCommerce Core Functions.
 *
 * @package Codeinwp\Sparks\Utilities
 */

if ( ! function_exists( 'sparks_normalize_deps' ) ) {
	/**
	 * Coerce an enqueue dependency argument into the array of handles core expects.
	 *
	 * @param  mixed $deps Dependencies passed by the caller.
	 * @return string[]
	 */
	function sparks_normalize_deps( $deps ) {
		return array_values(
			array_filter(
				(array) $deps,
				function ( $dep ) {
					return is_string( $dep ) && '' !== $dep;
				}
			)
		);
	}
}

if ( ! function_exists( 'sparks_get_asset_meta' ) ) {
	/**
	 * Read a build metadata file, falling back to safe defaults.
	 *
	 * @param  string $relative_path Path to the .asset.php file, relative to the plugin root.
	 * @return array{dependencies: string[], version: string}
	 */
	function sparks_get_asset_meta( $relative_path ) {
		$defaults = [
			'dependencies' => [],
			'version'      => SPARKS_WC_VERSION,
		];

		$file = SPARKS_WC_PATH . ltrim( $relative_path, '/' );

		if ( ! is_file( $file ) ) {
			return $defaults;
		}

		$meta = include $file;

		if ( ! is_array( $meta ) ) {
			return $defaults;
		}

		$version = isset( $meta['version'] ) ? $meta['version'] : '';

		return [
			'dependencies' => sparks_normalize_deps( isset( $meta['dependencies'] ) ? $meta['dependencies'] : [] ),
			'version'      => is_string( $version ) && '' !== $version ? $version : SPARKS_WC_VERSION,
		];
	}
}

if ( ! function_exists( 'sparks_enqueue_style' ) ) {
	/**
	 * Enqueue style
	 *
	 * @param  string           $handle Name of the style.
	 * @param  string           $src [optional] URL or path.
	 * @param  mixed            $deps [optional] Needed dependencies.
	 * @param  string|bool|null $ver [optional] Version number.
	 * @return void
	 */
	function sparks_enqueue_style( $handle, $src = '', $deps = [], $ver = SPARKS_WC_VERSION ) {
		if ( apply_filters( 'sparks_needs_enqueue_style', true, $handle, $src ) ) {
			wp_enqueue_style( $handle, $src, sparks_normalize_deps( $deps ), $ver );
			wp_style_add_data( $handle, 'rtl', 'replace' );
			wp_style_add_data( $handle, 'suffix', '.min' );
		}
	}
}

if ( ! function_exists( 'sparks_enqueue_script' ) ) {
	/**
	 * Enqueue Script
	 *
	 * @param  string           $handle Name of the script.
	 * @param  string           $src [Optional] URL or path.
	 * @param  mixed            $deps [Optional] Dependencies.
	 * @param  string|bool|null $ver [optional] Version number.
	 * @param  bool             $in_footer [Optional] Load before the </body> tag or not.
	 * @return void
	 */
	function sparks_enqueue_script( $handle, $src = '', $deps = [], $ver = SPARKS_WC_VERSION, $in_footer = false ) {
		if ( apply_filters( 'sparks_needs_enqueue_script', true, $handle, $src ) ) {
			wp_enqueue_script( $handle, $src, sparks_normalize_deps( $deps ), $ver, $in_footer );

			sparks_dev_enqueue_runtime_script();
		}
	}
}

if ( ! function_exists( 'sparks_dev_enqueue_runtime_script' ) ) {
	/**
	 * Enqueue runtime script
	 *
	 * @return void
	 */
	function sparks_dev_enqueue_runtime_script() {
		
		if ( ! defined( 'WP_DEBUG' ) ) {
			return;
		}

		if ( ! is_file( SPARKS_WC_PATH . 'includes/assets/build/runtime.js' ) ) {
			return;
		}

		$runtime_asset = sparks_get_asset_meta( 'includes/assets/build/runtime.asset.php' );

		wp_enqueue_script( 'sparks-runtime', SPARKS_WC_URL . 'includes/assets/build/runtime.js', $runtime_asset['dependencies'], $runtime_asset['version'], true );
	}
}
