<?php
namespace TI\Template_Cloud\Common;

use TI\Template_Cloud\Main;

/**
 * Class License
 */
final class License {
	const API_URL                  = 'https://api.themeisle.com/templates-cloud/';
	const LICENSE_DATA_OPTIONS_KEY = Main::PRODUCT_KEY . '_license_data';
	const LICENSE_KEY_OPTION_KEY   = Main::PRODUCT_KEY . '_license';
	const LICENSE_TRANSIENT_KEY    = Main::PRODUCT_KEY . '_license_check';

	const NEVE_CATEGORY_MAPPING = array(
		1 => 1,
		2 => 1,
		3 => 2,
		4 => 2,
		5 => 3,
		6 => 3,
		7 => 1,
		8 => 2,
		9 => 3,
	);

	/**
	 * License tiers that are valid.
	 */
	const TEMPLATES_CLOUD_TIERS = array( 1, 3, 5, 6, 7, 8, 9, 12, 13, 14, 17, 18, 19, 20, 23 );

	/**
	 * The main instance var.
	 *
	 * @var License|null
	 */
	protected static $instance = null;

	/**
	 * Whether the license options are being written by this class.
	 *
	 * Set while `set_license()` runs, so the option hooks that mirror an
	 * external write do not re-check a license this class just checked.
	 *
	 * @var bool
	 */
	private $is_writing_license = false;

	/**
	 * Constructor
	 *
	 * @return void
	 */
	private function __construct() {
		add_action( 'admin_init', array( $this, 'inherit_license_from_neve' ) );
		add_filter(
			'tiob_license_key',
			function () {
				return get_option( self::LICENSE_KEY_OPTION_KEY );
			}
		);
		add_filter(
			'pre_update_option_' . self::LICENSE_KEY_OPTION_KEY,
			function ( $value ) {
				$this->sync_license_data( $value );

				return $value;
			}
		);

		register_setting(
			'tpc_license_settings',
			self::LICENSE_KEY_OPTION_KEY,
			array(
				'type'         => 'string',
				'show_in_rest' => true,
				'default'      => '',
			)
		);
	}

	/**
	 * Get Instance
	 *
	 * @return $this
	 */
	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Get the URL.
	 *
	 * For VIP, use vip_safe_wp_remote_get.
	 *
	 * @param string $url URL to get.
	 * @param array  $args Optional. Request arguments.
	 *
	 * @return array|\WP_Error
	 */
	private function safe_get( $url, $args = array() ) {
		return function_exists( 'vip_safe_wp_remote_get' )
			? vip_safe_wp_remote_get( $url )
			: wp_remote_get( //phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.wp_remote_get_wp_remote_get, Already used.
				$url,
				$args
			);
	}

	/**
	 * Inherit license from Neve
	 */
	public function inherit_license_from_neve() {
		$should_inherit = ! get_option( 'tiob_inherited_autoactivate', false );

		if ( $should_inherit && false === self::has_active_license() && 'valid' === apply_filters( 'product_neve_license_status', false ) ) {
			$neve_license = apply_filters( 'product_neve_license_key', 'free' );
			$this->check_license( $neve_license );
			update_option( 'tiob_inherited_autoactivate', true );
			return;
		}

		if ( ! get_transient( self::LICENSE_TRANSIENT_KEY ) ) {
			$tiob_license = apply_filters( 'tiob_license_key', 'free' );
			$this->check_license( $tiob_license );
		}
	}

	/**
	 * Set the license.
	 *
	 * @param string $license License key.
	 * @param object $license_data License data.
	 *
	 * @return void
	 */
	private function set_license( $license, $license_data ) {
		$this->is_writing_license = true;

		update_option( self::LICENSE_KEY_OPTION_KEY, $license );
		update_option( self::LICENSE_DATA_OPTIONS_KEY, $license_data );
		set_transient( self::LICENSE_TRANSIENT_KEY, true, 12 * HOUR_IN_SECONDS );

		$this->is_writing_license = false;
	}

	/**
	 * Bring the stored license data in line with a license key written elsewhere.
	 *
	 * @param string $license_key The license key that was just stored.
	 *
	 * @return void
	 */
	public function sync_license_data( $license_key ) {
		if ( $this->is_writing_license ) {
			return;
		}

		$license_key = is_string( $license_key ) ? trim( $license_key ) : '';

		// When the license is deactivated, the key is stored as an empty string.
		// The API treats that as a free license, so the stored data should reflect that.
		if ( '' === $license_key || 'free' === $license_key ) {
			delete_option( self::LICENSE_DATA_OPTIONS_KEY );
			delete_transient( self::LICENSE_TRANSIENT_KEY );

			return;
		}

		$license_data = $this->fetch_license_data( $license_key );

		if ( false === $license_data ) {
			delete_transient( self::LICENSE_TRANSIENT_KEY );
			return;
		}

		// Only the data is stored here: the key option is already being written by
		// whoever triggered this, so writing it again would nest option updates.
		update_option( self::LICENSE_DATA_OPTIONS_KEY, $license_data );
		set_transient( self::LICENSE_TRANSIENT_KEY, true, 12 * HOUR_IN_SECONDS );
	}

	/**
	 * Check the license.
	 *
	 * @param string $license License key.
	 *
	 * @return bool
	 */
	public function check_license( $license ) {
		$license_data = $this->fetch_license_data( $license );

		if ( false === $license_data ) {
			return false;
		}

		$this->set_license( $license, $license_data );

		return self::is_license_valid( $license_data );
	}

	/**
	 * Ask the licensing API about a license key.
	 *
	 * @param string $license License key.
	 *
	 * @return object|false The license data, or false when the API could not be
	 *                     reached - in which case nothing about the stored
	 *                     license can be concluded.
	 */
	private function fetch_license_data( $license ) {
		$license_url = sprintf( '%stemplates/?license_id=%s&site_url=%s&license_check=1', self::API_URL, $license, rawurlencode( home_url() ) );
		$response    = $this->safe_get( $license_url );

		if ( is_wp_error( $response ) ) {
			return false;
		}

		if ( wp_remote_retrieve_response_code( $response ) !== 200 ) {
			return false;
		}

		$license_data = json_decode( wp_remote_retrieve_body( $response ) );

		// A body carrying a code or a message is the API rejecting the key.
		if ( ! empty( $license_data ) && ( isset( $license_data->code ) || isset( $license_data->message ) ) ) {
			return self::get_free_license_data();
		}

		return $license_data;
	}

	/**
	 * License data standing for "no license".
	 *
	 * @return object
	 */
	private static function get_free_license_data() {
		return (object) array(
			'key'        => 'free',
			'license'    => 'invalid',
			'expiration' => '',
			'tier'       => 0,
		);
	}

	/**
	 * Get active license.
	 *
	 * @return bool
	 */
	public static function has_active_license() {
		$status = self::get_license_data();

		if ( ! $status ) {
			return false;
		}

		if ( ! isset( $status->license ) ) {
			return false;
		}

		if ( 'not_active' === $status->license || 'invalid' === $status->license ) {
			return false;
		}

		return true;
	}

	/**
	 * Get the license data.
	 *
	 * @return bool|\stdClass
	 */
	public static function get_license_data() {
		return get_option( self::LICENSE_DATA_OPTIONS_KEY );
	}

	/**
	 * Check if the license itself is valid, regardless of its tier.
	 *
	 * @param object|false|null $license_data Optional. License data. Defaults to the stored one.
	 *
	 * @return bool
	 */
	public static function is_license_valid( $license_data = null ) {
		if ( null === $license_data ) {
			$license_data = self::get_license_data();
		}

		if ( ! is_object( $license_data ) ) {
			return false;
		}

		if ( isset( $license_data->valid ) && 'valid' === $license_data->valid ) {
			return true;
		}

		return isset( $license_data->license ) && 'valid' === $license_data->license;
	}

	/**
	 * Check if a license tier is entitled to Templates Cloud.
	 *
	 * @param mixed $tier The tier key returned by the licensing API.
	 *
	 * @return bool
	 */
	public static function is_templates_cloud_tier( $tier ) {
		if ( ! is_numeric( $tier ) ) {
			return false;
		}

		return in_array( (int) $tier, self::TEMPLATES_CLOUD_TIERS, true );
	}

	/**
	 * Check if the license grants access to Templates Cloud.
	 *
	 * @param object|false|null $license_data License data.
	 *
	 * @return bool
	 */
	public static function has_templates_cloud_access( $license_data = null ) {
		if ( null === $license_data ) {
			$license_data = self::get_license_data();
		}

		if ( ! self::is_license_valid( $license_data ) ) {
			return false;
		}

		return self::is_templates_cloud_tier( isset( $license_data->tier ) ? $license_data->tier : null );
	}

	/**
	 * Get the license tier.
	 *
	 * @param int $default_tier The default tier.
	 * @return int
	 */
	public static function get_license_tier( $default_tier = 0 ) {
		$license = self::get_license_data();

		if ( isset( $license->tier ) && absint( $license->tier ) >= 0 ) {
			$tier = $license->tier;

			if ( $license->tier !== 3 ) {
				$category_mapping = self::NEVE_CATEGORY_MAPPING;
				$tier             = isset( $category_mapping[ $license->tier ] ) ? $category_mapping[ $license->tier ] : $license->tier;
			}

			return (int) $tier;
		}

		return $default_tier;
	}

	/**
	 * Throw error on object clone
	 *
	 * @return void
	 */
	public function __clone() {
		// Cloning instances of the class is forbidden.
		_doing_it_wrong( __FUNCTION__, '', '1.0.0' );
	}

	/**
	 * Disable un-serializing of the class
	 *
	 * @return void
	 */
	public function __wakeup() {
		// Un-serializing instances of the class is forbidden.
		_doing_it_wrong( __FUNCTION__, '', '1.0.0' );
	}
}
