/**
 * External dependencies
 */
import { defineConfig, devices } from '@playwright/test';

/**
 * WordPress dependencies
 */
import baseConfig from '@wordpress/scripts/config/playwright.config.js';

const config = defineConfig( {
	...baseConfig,
	// The mu-plugin toggles site-global options per spec, so parallel workers
	// would race on them.
	workers: 1,
	testDir: './e2e-tests/specs',
	globalSetup: './e2e-tests/config/global-setup.ts',
	projects: [
		{
			name: 'chromium',
			use: { ...devices[ 'Desktop Chrome' ] },
		},
	],
} );

export default config;
