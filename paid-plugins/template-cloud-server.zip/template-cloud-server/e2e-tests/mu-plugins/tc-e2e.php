<?php
/**
 * Plugin Name: TC Server E2E Mocks
 * Description: Test-only mu-plugin that short-circuits the external license calls made by template-cloud-server so the Playwright suite runs offline and deterministic. Loaded only when the TC_E2E constant is set by .wp-env.json.
 *
 * @package template-cloud-server
 */

if ( ! defined( 'TC_E2E' ) || ! TC_E2E || wp_get_environment_type() === 'production' ) {
	return;
}

define( 'TC_E2E_SCENARIO_OPTION', 'tc_e2e_license_scenario' );

/**
 * License payload the mocked API answers with for a scenario.
 *
 * A 200 body without code/message keys is what License::check_license stores as
 * the license data; a body with them is treated as an invalid license.
 *
 * @param string $scenario Scenario name: agency, personal or invalid.
 * @return array
 */
function tc_e2e_license_payload( $scenario ) {
	$payloads = array(
		// Tier 3 includes Templates Cloud.
		'agency'   => array(
			'license' => 'valid',
			'key'     => 'tc-e2e-agency-key',
			'tier'    => 3,
			'expires' => 'lifetime',
		),
		// A valid license on a tier that does not include Templates Cloud.
		'personal' => array(
			'license' => 'valid',
			'key'     => 'tc-e2e-personal-key',
			'tier'    => 2,
			'expires' => 'lifetime',
		),
		'invalid'  => array(
			'code'    => 'invalid_license',
			'message' => 'TC E2E: invalid license.',
		),
	);

	return isset( $payloads[ $scenario ] ) ? $payloads[ $scenario ] : $payloads['agency'];
}

// Specs switch the license the mocked API returns through this route. Deleting
// the stored data and the check transient makes the next admin request re-read
// the license, so the dashboard always reflects the requested scenario.
add_action(
	'rest_api_init',
	function () {
		register_rest_route(
			'tc-e2e/v1',
			'/license',
			array(
				'methods'             => 'POST',
				'permission_callback' => function () {
					return current_user_can( 'manage_options' );
				},
				'args'                => array(
					'scenario' => array(
						'type' => 'string',
						'enum' => array( 'agency', 'personal', 'invalid' ),
					),
				),
				'callback'            => function ( $request ) {
					update_option( TC_E2E_SCENARIO_OPTION, $request->get_param( 'scenario' ) );
					delete_option( 'template_cloud_server_license_data' );
					delete_transient( 'template_cloud_server_license_check' );
					return rest_ensure_response( array( 'success' => true ) );
				},
			)
		);
	}
);

add_filter(
	'pre_http_request',
	function ( $preempt, $args, $url ) {
		if ( false !== $preempt ) {
			return $preempt;
		}

		if ( false === strpos( $url, 'api.themeisle.com/templates-cloud/' ) ) {
			return $preempt;
		}

		$scenario = get_option( TC_E2E_SCENARIO_OPTION, 'agency' );

		return array(
			'response' => array(
				'code'    => 200,
				'message' => 'OK',
			),
			'headers'  => array( 'content-type' => 'application/json' ),
			'body'     => wp_json_encode( tc_e2e_license_payload( $scenario ) ),
			'cookies'  => array(),
		);
	},
	10,
	3
);

// Drop the cached license check so every request re-hits the mocked API instead
// of serving a stale result from a previous, possibly unmocked, run.
add_action(
	'init',
	function () {
		delete_transient( 'template_cloud_server_license_check' );
	}
);
