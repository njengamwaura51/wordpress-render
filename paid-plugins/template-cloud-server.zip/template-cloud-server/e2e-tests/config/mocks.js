/**
 * Browser-side mocks. The dashboard checks a license key by fetching the
 * cross-origin Templates Cloud API directly, so activation is mocked here with
 * page.route; the server-side check is mocked by the tc-e2e mu-plugin.
 */

// Must match the payloads in mu-plugins/tc-e2e.php.
export const AGENCY_LICENSE = {
	license: 'valid',
	key: 'tc-e2e-agency-key',
	tier: 3,
	expires: 'lifetime',
};

// A valid license on a tier that does not include Templates Cloud.
export const PERSONAL_LICENSE = {
	license: 'valid',
	key: 'tc-e2e-personal-key',
	tier: 2,
	expires: 'lifetime',
};

export const INVALID_LICENSE = {
	code: 'invalid_license',
	message: 'TC E2E: invalid license.',
};

// apiFetch sends credentialed requests, so the mocked cross-origin responses
// must echo the exact origin (a wildcard is rejected by the browser).
const corsHeaders = ( route ) => ( {
	'access-control-allow-origin': route.request().headers().origin || '*',
	'access-control-allow-credentials': 'true',
	'access-control-allow-headers': '*',
	'access-control-allow-methods': '*',
} );

const fulfillJson = ( route, body ) => {
	if ( route.request().method() === 'OPTIONS' ) {
		return route.fulfill( { status: 200, headers: corsHeaders( route ) } );
	}

	return route.fulfill( {
		status: 200,
		contentType: 'application/json',
		headers: corsHeaders( route ),
		body: JSON.stringify( body ),
	} );
};

/**
 * Answer the license check (license_check=1) with the given license data.
 *
 * @param {Object} page    Playwright page.
 * @param {Object} license License payload returned by the mocked API.
 */
export async function mockLicenseCheckRoute( page, license = AGENCY_LICENSE ) {
	await page.route( '**/api.themeisle.com/templates-cloud/**', ( route ) =>
		fulfillJson( route, license )
	);
}
