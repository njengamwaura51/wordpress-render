/**
 * WordPress dependencies
 */
import { test, expect } from '@wordpress/e2e-test-utils-playwright';

/**
 * Internal dependencies
 */
import {
	AGENCY_LICENSE,
	PERSONAL_LICENSE,
	mockLicenseCheckRoute,
} from '../config/mocks';

const DASHBOARD_URL = 'themes.php?page=ti-template-cloud';
const ACCESS_KEYS_URL = `${ DASHBOARD_URL }&tab=access`;

const KEYS_ENDPOINT = '/ti-template-cloud/v1/keys';

// Switches the license the mocked API returns, so the dashboard loads with the
// license state a spec needs. See mu-plugins/tc-e2e.php.
const setLicenseScenario = ( requestUtils, scenario ) =>
	requestUtils.rest( {
		path: '/tc-e2e/v1/license',
		method: 'POST',
		data: { scenario },
	} );

// Creates an access key the way the dashboard form does, but straight against
// the endpoint. `rest()` rejects with the error body on a non-2xx status, so
// both outcomes are returned instead of thrown.
const createKeyViaRest = ( requestUtils ) =>
	requestUtils
		.rest( {
			path: KEYS_ENDPOINT,
			method: 'POST',
			data: {
				name: 'REST enforcement key',
				mode: 'all',
				collections: [],
				categories: [],
			},
		} )
		.then(
			( data ) => ( { data } ),
			( error ) => ( { error } )
		);

test.describe( 'License activation', () => {
	// The panel only offers activation while no valid license is stored.
	test.beforeEach( async ( { requestUtils } ) => {
		await setLicenseScenario( requestUtils, 'invalid' );
	} );

	test.afterEach( async ( { requestUtils } ) => {
		await setLicenseScenario( requestUtils, 'agency' );
	} );

	// The license itself is valid here - only the tier is not entitled, which is
	// what keeps it from being activated.
	test( 'an invalid plan cannot be activated', async ( {
		page,
		admin,
	} ) => {
		await mockLicenseCheckRoute( page, PERSONAL_LICENSE );
		await admin.visitAdminPage( DASHBOARD_URL );

		await page.getByLabel( 'License Key' ).fill( PERSONAL_LICENSE.key );
		await page.getByRole( 'button', { name: 'Activate' } ).click();

		await expect(
			page.getByText( 'Can not activate this license!' )
		).toBeVisible();
	} );

	test( 'activating a valid plan', async ( {
		page,
		admin,
	} ) => {
		await mockLicenseCheckRoute( page, AGENCY_LICENSE );
		await admin.visitAdminPage( DASHBOARD_URL );

		await page.getByLabel( 'License Key' ).fill( AGENCY_LICENSE.key );
		await page.getByRole( 'button', { name: 'Activate' } ).click();

		await expect(
			page.getByRole( 'button', { name: 'Deactivate' } )
		).toBeVisible();
	} );
} );

// A license can be stored without being entitled - it is inherited from Neve, or
// the plan simply does not include Templates Cloud. The panel still has to treat
// it as a stored license.
test.describe( 'A stored license on an unsupported plan', () => {
	test.beforeEach( async ( { requestUtils, admin } ) => {
		await setLicenseScenario( requestUtils, 'personal' );
		await admin.visitAdminPage( DASHBOARD_URL );
	} );

	test.afterEach( async ( { requestUtils } ) => {
		await setLicenseScenario( requestUtils, 'agency' );
	} );

	test( 'can be deactivated', async ( { page } ) => {
		await expect(
			page.getByRole( 'button', { name: 'Deactivate' } )
		).toBeVisible();
	} );

	test( 'is masked in the license field', async ( { page } ) => {
		await expect( page.getByLabel( 'License Key' ) ).toHaveValue(
			'******************************l-key'
		);
	} );

	test( 'is not reported as verified', async ( { page } ) => {
		await expect( page.getByText( 'Verified - Expires at' ) ).toBeHidden();
	} );

	test( 'explains that the plan is not entitled', async ( { page } ) => {
		await expect(
			page.getByText(
				'In order to create access keys please make sure you have a valid license key.'
			)
		).toBeVisible();
	} );
} );

test.describe( 'Access keys entitlement', () => {
	test.afterEach( async ( { requestUtils } ) => {
		await setLicenseScenario( requestUtils, 'agency' );
	} );

	test( 'an invalid plan cannot create access keys', async ( {
		page,
		admin,
		requestUtils,
	} ) => {
		await setLicenseScenario( requestUtils, 'personal' );
		await admin.visitAdminPage( ACCESS_KEYS_URL );

		await expect(
			page.getByRole( 'heading', { name: 'Invalid license key' } )
		).toBeVisible();
	} );

	test( 'an invalid license cannot create access keys', async ( {
		page,
		admin,
		requestUtils,
	} ) => {
		await setLicenseScenario( requestUtils, 'invalid' );
		await admin.visitAdminPage( ACCESS_KEYS_URL );

		await expect(
			page.getByRole( 'heading', { name: 'Invalid license key' } )
		).toBeVisible();
	} );

	test( 'a valid plan can create access keys', async ( {
		page,
		admin,
		requestUtils,
	} ) => {
		await setLicenseScenario( requestUtils, 'agency' );
		await admin.visitAdminPage( ACCESS_KEYS_URL );

		await expect(
			page.getByRole( 'button', { name: 'Create Access Key' } )
		).toBeVisible();
	} );
} );

// Hiding the form in the dashboard is not enforcement: the endpoint itself has
// to refuse a license that is not entitled to Templates Cloud.
test.describe( 'Access keys endpoint entitlement', () => {
	const createdKeys = [];

	// Visiting an admin page is what makes the plugin re-check the license, so
	// the scenario payload is the stored license by the time the REST call runs.
	const storeLicense = async ( requestUtils, admin, scenario ) => {
		await setLicenseScenario( requestUtils, scenario );
		await admin.visitAdminPage( DASHBOARD_URL );
	};

	test.afterEach( async ( { requestUtils } ) => {
		while ( createdKeys.length ) {
			await requestUtils.rest( {
				path: `${ KEYS_ENDPOINT }/${ createdKeys.pop() }`,
				method: 'DELETE',
			} );
		}

		await setLicenseScenario( requestUtils, 'agency' );
	} );

	test( 'an invalid plan cannot create access keys through the endpoint', async ( {
		admin,
		requestUtils,
	} ) => {
		await storeLicense( requestUtils, admin, 'personal' );

		const { error } = await createKeyViaRest( requestUtils );

		expect( error?.code ).toBe( 'ti_tc_license_required' );
	} );

	test( 'an invalid license cannot create access keys through the endpoint', async ( {
		admin,
		requestUtils,
	} ) => {
		await storeLicense( requestUtils, admin, 'invalid' );

		const { error } = await createKeyViaRest( requestUtils );

		expect( error?.code ).toBe( 'ti_tc_license_required' );
	} );

	test( 'a valid plan can create access keys through the endpoint', async ( {
		admin,
		requestUtils,
	} ) => {
		await storeLicense( requestUtils, admin, 'agency' );

		const { data } = await createKeyViaRest( requestUtils );
		createdKeys.push( ...Object.keys( data?.keys || {} ) );

		expect( data?.success ).toBe( true );
	} );
} );
