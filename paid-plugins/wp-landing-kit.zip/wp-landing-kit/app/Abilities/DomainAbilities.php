<?php

namespace WpLandingKit\Abilities;

use WP_Error;
use WP_Post;
use WPLK_Mapping;
use WpLandingKit\Ajax\FetchDomainConnectionStatusAjaxHandler;
use WpLandingKit\DomainIntercept\DomainMap;
use WpLandingKit\Facades\Settings;
use WpLandingKit\Framework\Facades\App;
use WpLandingKit\Framework\Utils\Arr;
use WpLandingKit\Models\Domain;
use WpLandingKit\Utils\DomainRegistry;

/**
 * Class DomainAbilities
 * @package WpLandingKit\Abilities
 *
 * Exposes mapped domains through the WordPress Abilities API. Every ability is a thin wrapper over the Domain model,
 * the domain map and the connection checker that the admin screens already use.
 */
class DomainAbilities {

	const CATEGORY = 'landing-kit';
	const PER_PAGE = 50;
	const MAX_MAPPINGS = 50;

	public function register_category() {
		wp_register_ability_category( self::CATEGORY, [
			'label' => __( 'WP Landing Kit', 'wp-landing-kit' ),
			'description' => __( 'Map domains to site content and inspect their connection.', 'wp-landing-kit' ),
		] );
	}

	public function register() {
		wp_register_ability( 'landing-kit/list-domains', [
			'label' => __( 'List mapped domains', 'wp-landing-kit' ),
			'description' => __( 'List mapped domains with their routing configuration, active state and last known connection state. Filter by domain id or by the id of a post the domain maps to. This does not manage DNS or certificates.', 'wp-landing-kit' ),
			'category' => self::CATEGORY,
			'input_schema' => [
				'type' => 'object',
				'properties' => [
					'id' => [
						'type' => 'integer',
						'description' => __( 'Return only the domain with this id.', 'wp-landing-kit' ),
						'minimum' => 1,
					],
					'post_id' => [
						'type' => 'integer',
						'description' => __( 'Return only domains with a mapping that targets this post or page id.', 'wp-landing-kit' ),
						'minimum' => 1,
					],
					'page' => [
						'type' => 'integer',
						'description' => __( 'Page of results, 50 domains per page.', 'wp-landing-kit' ),
						'minimum' => 1,
						'default' => 1,
					],
				],
				'default' => [],
				'additionalProperties' => false,
			],
			'output_schema' => [
				'type' => 'object',
				'properties' => [
					'domains' => [
						'type' => 'array',
						'items' => $this->domain_schema(),
					],
					'total' => [ 'type' => 'integer' ],
					'page' => [ 'type' => 'integer' ],
					'per_page' => [ 'type' => 'integer' ],
					'total_pages' => [ 'type' => 'integer' ],
				],
			],
			'execute_callback' => [ $this, 'list_domains' ],
			'permission_callback' => [ $this, 'can_list_domains' ],
			'meta' => [
				'annotations' => [
					'readonly' => true,
					'destructive' => false,
					'idempotent' => true,
				],
				'show_in_rest' => true,
			],
		] );

		wp_register_ability( 'landing-kit/upsert-domain', [
			'label' => __( 'Create or update a mapped domain', 'wp-landing-kit' ),
			'description' => __( 'Create a mapped domain, or update one by id: host name, the posts or pages its root and URL paths map to, and whether it is active. Activating a domain changes public routing. This does not manage DNS or certificates.', 'wp-landing-kit' ),
			'category' => self::CATEGORY,
			'input_schema' => [
				'type' => 'object',
				'properties' => [
					'id' => [
						'type' => 'integer',
						'description' => __( 'Id of the domain to update. Omit to create a new domain.', 'wp-landing-kit' ),
						'minimum' => 1,
					],
					'domain' => [
						'type' => 'string',
						'description' => __( 'Host name, e.g. mydomain.com. Required when creating. Protocol and path are stripped.', 'wp-landing-kit' ),
					],
					'mappings' => [
						'type' => 'array',
						'description' => __( 'Mappings to add or replace, matched by path. An empty path is the domain root.', 'wp-landing-kit' ),
						'maxItems' => self::MAX_MAPPINGS,
						'items' => [
							'type' => 'object',
							'properties' => [
								'path' => [
									'type' => 'string',
									'description' => __( 'URL path on the domain, without leading slash. Empty for the domain root.', 'wp-landing-kit' ),
								],
								'post_id' => [
									'type' => 'integer',
									'description' => __( 'Id of the published post or page to serve at this path.', 'wp-landing-kit' ),
									'minimum' => 1,
								],
								'map_sub_pages' => [
									'type' => 'boolean',
									'description' => __( 'Also serve child pages below this path. Hierarchical post types only.', 'wp-landing-kit' ),
									'default' => false,
								],
							],
							'required' => [ 'post_id' ],
							'additionalProperties' => false,
						],
					],
					'replace_mappings' => [
						'type' => 'boolean',
						'description' => __( 'Remove existing URL path mappings that are not listed in mappings. The root and fallback mappings are always kept.', 'wp-landing-kit' ),
						'default' => false,
					],
					'active' => [
						'type' => 'boolean',
						'description' => __( 'Whether the domain intercepts requests. New domains are inactive unless set. Activation requires a mapped root.', 'wp-landing-kit' ),
					],
					'dry_run' => [
						'type' => 'boolean',
						'description' => __( 'Validate and return the resulting domain without saving.', 'wp-landing-kit' ),
						'default' => false,
					],
				],
				'additionalProperties' => false,
			],
			'output_schema' => [
				'type' => 'object',
				'properties' => [
					'mapping' => $this->domain_schema(),
					'created' => [ 'type' => 'boolean' ],
					'dry_run' => [ 'type' => 'boolean' ],
				],
			],
			'execute_callback' => [ $this, 'upsert_domain' ],
			'permission_callback' => [ $this, 'can_upsert_domain' ],
			'meta' => [
				'annotations' => [
					'readonly' => false,
					'destructive' => true,
					'idempotent' => false,
				],
				'show_in_rest' => true,
			],
		] );

		wp_register_ability( 'landing-kit/check-domain-connection', [
			'label' => __( 'Check domain connection', 'wp-landing-kit' ),
			'description' => __( 'Request the mapped domain over HTTPS and HTTP and report whether it reaches this site. The result is stored as the domain\'s connection state. This does not change DNS or certificates.', 'wp-landing-kit' ),
			'category' => self::CATEGORY,
			'input_schema' => [
				'type' => 'object',
				'properties' => [
					'id' => [
						'type' => 'integer',
						'description' => __( 'Id of the domain to check.', 'wp-landing-kit' ),
						'minimum' => 1,
					],
				],
				'required' => [ 'id' ],
				'additionalProperties' => false,
			],
			'output_schema' => [
				'type' => 'object',
				'properties' => [
					'id' => [ 'type' => 'integer' ],
					'domain' => [ 'type' => 'string' ],
					'connected' => [ 'type' => 'boolean' ],
					'connection_state' => [ 'type' => 'string' ],
					'checked_at' => [ 'type' => 'string' ],
					'message' => [ 'type' => 'string' ],
				],
			],
			'execute_callback' => [ $this, 'check_domain_connection' ],
			'permission_callback' => [ $this, 'can_check_domain_connection' ],
			'meta' => [
				'annotations' => [
					'readonly' => false,
					'destructive' => false,
					'idempotent' => true,
				],
				'show_in_rest' => true,
			],
		] );
	}

	/**
	 * Mirrors the Domains list screen, which requires the post type's `edit_posts` capability (edit_domains).
	 *
	 * @return bool
	 */
	public function can_list_domains() {
		return current_user_can( $this->cap( 'edit_posts' ) );
	}

	/**
	 * Mirrors the Add New / Edit Domain screens: the post type's `edit_posts` (edit_domains) and `create_posts`
	 * (create_domains) capabilities to create, as wp-admin/post-new.php requires both; `edit_post` on the domain to
	 * update; and the post type's `publish_posts` capability (publish_domains) to activate.
	 *
	 * @param mixed $input
	 *
	 * @return bool
	 */
	public function can_upsert_domain( $input = [] ) {
		$input = (array) $input;
		$id = absint( Arr::get( $input, 'id', 0 ) );

		if ( $id ) {
			if ( ! current_user_can( 'edit_post', $id ) ) {
				return false;
			}
		} elseif ( ! current_user_can( $this->cap( 'edit_posts' ) ) or ! current_user_can( $this->cap( 'create_posts' ) ) ) {
			return false;
		}

		if ( ! empty( $input['active'] ) and ! current_user_can( $this->cap( 'publish_posts' ) ) ) {
			return false;
		}

		return true;
	}

	/**
	 * The connection check is only offered on the Edit Domain screen, so it requires `edit_post` on the domain.
	 *
	 * @param mixed $input
	 *
	 * @return bool
	 */
	public function can_check_domain_connection( $input = [] ) {
		$id = absint( Arr::get( (array) $input, 'id', 0 ) );

		return $id and current_user_can( 'edit_post', $id );
	}

	/**
	 * @param mixed $input
	 *
	 * @return array|WP_Error
	 */
	public function list_domains( $input = [] ) {
		$input = (array) $input;
		$id = absint( Arr::get( $input, 'id', 0 ) );
		$post_id = absint( Arr::get( $input, 'post_id', 0 ) );
		$page = max( 1, absint( Arr::get( $input, 'page', 1 ) ) );

		if ( $id ) {
			$domain = $this->find_domain( $id );
			if ( is_wp_error( $domain ) ) {
				return $domain;
			}
			$domains = [ $domain ];
		} else {
			$domains = Domain::all( [
				'post_status' => [ 'publish', 'draft', 'pending', 'private', 'future' ],
				'orderby' => 'ID',
				'order' => 'ASC',
			] );
		}

		$domains = array_values( array_filter( $domains, function ( Domain $domain ) use ( $post_id ) {
			if ( ! current_user_can( 'edit_post', $domain->ID ) ) {
				return false;
			}

			return ! $post_id or $this->domain_maps_post( $domain, $post_id );
		} ) );

		$total = count( $domains );
		$domains = array_slice( $domains, ( $page - 1 ) * self::PER_PAGE, self::PER_PAGE );

		return [
			'domains' => array_map( [ $this, 'format_domain' ], $domains ),
			'total' => $total,
			'page' => $page,
			'per_page' => self::PER_PAGE,
			'total_pages' => (int) ceil( $total / self::PER_PAGE ),
		];
	}

	/**
	 * @param mixed $input
	 *
	 * @return array|WP_Error
	 */
	public function upsert_domain( $input = [] ) {
		$input = (array) $input;
		$id = absint( Arr::get( $input, 'id', 0 ) );
		$dry_run = ! empty( $input['dry_run'] );
		$is_new = ! $id;

		if ( $is_new ) {
			if ( empty( $input['domain'] ) ) {
				return new WP_Error( 'wplk_missing_domain', __( 'A host name is required to create a domain.', 'wp-landing-kit' ) );
			}
			$domain = Domain::generate( [ 'post_author' => get_current_user_id() ] );
			$domain->deactivate();
		} else {
			$domain = $this->find_domain( $id );
			if ( is_wp_error( $domain ) ) {
				return $domain;
			}
		}

		if ( isset( $input['domain'] ) ) {
			$host = Domain::post_type_obj()->sanitize_title( sanitize_text_field( (string) $input['domain'] ) );
			if ( ! $host ) {
				return new WP_Error( 'wplk_invalid_domain', __( 'The host name is not valid.', 'wp-landing-kit' ) );
			}

			$stored = Domain::find_by_domain( $host );
			if ( $stored and $stored->post_status !== 'trash' and (int) $stored->ID !== (int) $domain->ID ) {
				return new WP_Error( 'wplk_duplicate_domain', __( 'Another domain already uses this host name.', 'wp-landing-kit' ) );
			}

			$domain->set_host( $host );
		}

		if ( isset( $input['mappings'] ) ) {
			$mappings = $this->merge_mappings( $domain, (array) $input['mappings'], ! empty( $input['replace_mappings'] ) );
			if ( is_wp_error( $mappings ) ) {
				return $mappings;
			}
			$domain->set_mappings( $mappings );
		}

		if ( isset( $input['active'] ) ) {
			if ( $input['active'] ) {
				if ( ! $this->root_is_mapped( $domain ) ) {
					return new WP_Error( 'wplk_cannot_activate', __( 'The domain cannot be activated until its root is mapped.', 'wp-landing-kit' ) );
				}
				$domain->activate();
			} else {
				$domain->deactivate();
			}
		}

		if ( $dry_run ) {
			return [
				'mapping' => $this->format_domain( $domain ),
				'created' => false,
				'dry_run' => true,
			];
		}

		// The model persists the site script from its in-memory settings, so carry the stored value over.
		if ( ! $is_new ) {
			$domain->set_site_script( get_post_meta( $domain->ID, '_wplk_gtm_script', true ) );
		}

		$saved = $domain->save();
		if ( is_wp_error( $saved ) ) {
			return $saved;
		}
		if ( ! $saved ) {
			return new WP_Error( 'wplk_save_failed', __( 'The domain could not be saved.', 'wp-landing-kit' ) );
		}

		$this->update_domain_map( $domain );

		return [
			'mapping' => $this->format_domain( $domain ),
			'created' => $is_new,
			'dry_run' => false,
		];
	}

	/**
	 * @param mixed $input
	 *
	 * @return array|WP_Error
	 */
	public function check_domain_connection( $input = [] ) {
		$domain = $this->find_domain( absint( Arr::get( (array) $input, 'id', 0 ) ) );
		if ( is_wp_error( $domain ) ) {
			return $domain;
		}

		if ( ! $domain->host() ) {
			return new WP_Error( 'wplk_invalid_domain', __( 'The domain has no host name.', 'wp-landing-kit' ) );
		}

		$connected = (bool) FetchDomainConnectionStatusAjaxHandler::check( $domain->ID, $domain->host() );

		return [
			'id' => (int) $domain->ID,
			'domain' => $domain->host(),
			'connected' => $connected,
			'connection_state' => $domain->get_status(),
			'checked_at' => gmdate( 'c' ),
			'message' => $connected
				? __( 'Your domain is properly configured.', 'wp-landing-kit' )
				: __( 'We couldn\'t verify if the domain is properly configured. Please check your DNS settings and try again.', 'wp-landing-kit' ),
		];
	}

	/**
	 * @param string $name Post type capability key, e.g. `edit_posts`.
	 *
	 * @return string
	 */
	private function cap( $name ) {
		$type = get_post_type_object( Domain::post_type() );

		return ( $type and isset( $type->cap->$name ) ) ? $type->cap->$name : 'do_not_allow';
	}

	/**
	 * @param int $id
	 *
	 * @return Domain|WP_Error
	 */
	private function find_domain( $id ) {
		$post = $id ? get_post( $id ) : null;

		if ( ! $post instanceof WP_Post or $post->post_type !== Domain::post_type() or $post->post_status === 'trash' ) {
			return new WP_Error( 'wplk_domain_not_found', __( 'Domain not found.', 'wp-landing-kit' ) );
		}

		return Domain::make( $post );
	}

	/**
	 * Merge the requested post mappings into the domain's stored mappings. Stored mappings that are not addressed by
	 * the input are kept as they are, so options set in the admin screen are not lost.
	 *
	 * @param Domain $domain
	 * @param array $input
	 * @param bool $replace Drop stored URL path mappings that aren't in the input.
	 *
	 * @return array|WP_Error Mappings keyed by mapping id: root first, fallback last.
	 */
	private function merge_mappings( Domain $domain, array $input, $replace ) {
		if ( count( $input ) > self::MAX_MAPPINGS ) {
			return new WP_Error( 'wplk_too_many_mappings', sprintf( __( 'No more than %d mappings can be set per call.', 'wp-landing-kit' ), self::MAX_MAPPINGS ) );
		}

		if ( count( $domain->mappings() ) < 2 ) {
			$lone_root = $domain->root_mapping();
			$domain->set_mappings( [] );
		}

		$root = empty( $lone_root ) ? $domain->root_mapping() : $lone_root;
		$fallback = $domain->fallback_mapping();
		$dynamic = array_values( $domain->dynamic_mappings() );
		$mappable = (array) Settings::get( 'mappable_post_types', [] );
		$requested = [];
		$seen = [];

		foreach ( $input as $index => $item ) {
			$item = (array) $item;
			$path = trim( sanitize_text_field( (string) Arr::get( $item, 'path', '' ) ) );
			$path = trim( $path, '/' );
			$post = get_post( absint( Arr::get( $item, 'post_id', 0 ) ) );

			if ( in_array( $path, $seen, true ) ) {
				return new WP_Error( 'wplk_duplicate_path', sprintf( __( 'Mapping %1$d repeats the path "%2$s".', 'wp-landing-kit' ), $index, $path ) );
			}
			$seen[] = $path;

			if ( ! $post instanceof WP_Post or $post->post_status !== 'publish' ) {
				return new WP_Error( 'wplk_invalid_post', sprintf( __( 'Mapping %d does not target a published post.', 'wp-landing-kit' ), $index ) );
			}

			if ( ! in_array( $post->post_type, $mappable, true ) ) {
				return new WP_Error( 'wplk_post_type_not_mappable', sprintf( __( 'Mapping %1$d targets the post type "%2$s", which is not enabled for mapping in the plugin settings.', 'wp-landing-kit' ), $index, $post->post_type ) );
			}

			$mapping = new WPLK_Mapping( $path );
			$mapped = $mapping->maps_to_post( $post, ! empty( $item['map_sub_pages'] ) );
			if ( is_wp_error( $mapped ) ) {
				return $mapped;
			}

			$mapping = $mapping->to_db_array();
			$mapping['url_path'] = $path;
			$mapping['is_regex'] = false;

			if ( $path === '' ) {
				$mapping['mapping_id'] = Arr::get( $root, 'mapping_id' ) ?: $mapping['mapping_id'];
				$root = $mapping;
				continue;
			}

			$requested[ $path ] = $mapping;
		}

		$merged = [];
		foreach ( $dynamic as $stored ) {
			$stored_path = trim( (string) Arr::get( $stored, 'url_path', '' ), '/' );
			$is_target = ( ! Arr::get( $stored, 'is_regex', false ) and isset( $requested[ $stored_path ] ) );

			if ( $is_target ) {
				$requested[ $stored_path ]['mapping_id'] = Arr::get( $stored, 'mapping_id' ) ?: $requested[ $stored_path ]['mapping_id'];
				$merged[] = $requested[ $stored_path ];
				unset( $requested[ $stored_path ] );
			} elseif ( ! $replace ) {
				$merged[] = $stored;
			}
		}

		$all = array_merge( [ $root ], $merged, array_values( $requested ), [ $fallback ] );
		$keyed = [];
		foreach ( $all as $mapping ) {
			$mapping_id = Arr::get( $mapping, 'mapping_id' ) ?: uniqid();
			$mapping['mapping_id'] = $mapping_id;
			$keyed[ $mapping_id ] = $mapping;
		}

		return $keyed;
	}

	/**
	 * @param Domain $domain
	 *
	 * @return bool
	 */
	private function root_is_mapped( Domain $domain ) {
		$root = $domain->root_mapping();

		if ( Arr::get( $root, 'action' ) === 'redirect' ) {
			return (bool) Arr::get( $root, 'redirect_url' );
		}

		foreach ( [ 'page_id', 'p', 'term_id', 'vendor' ] as $key ) {
			if ( Arr::get( $root, $key ) ) {
				return true;
			}
		}

		return ( Arr::get( $root, 'resource_type' ) === 'post-type-archive' and Arr::get( $root, 'post_type' ) );
	}

	/**
	 * @param Domain $domain
	 * @param int $post_id
	 *
	 * @return bool
	 */
	private function domain_maps_post( Domain $domain, $post_id ) {
		foreach ( $domain->mappings() as $mapping ) {
			if ( Arr::get( $mapping, 'action' ) !== 'map_to_resource' ) {
				continue;
			}
			if ( (int) Arr::get( $mapping, 'page_id' ) === $post_id or (int) Arr::get( $mapping, 'p' ) === $post_id ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Rebuild the domain map the same way the public PHP API does after a save. All map groups are loaded first as
	 * they are only loaded in the admin by default and would otherwise be overwritten with partial data.
	 *
	 * @param Domain $domain
	 */
	private function update_domain_map( Domain $domain ) {
		/** @var DomainMap $map */
		$map = App::make( DomainMap::class );
		$map->load_domain_mappings();
		$map->load_post_mappings();
		$map->load_term_mappings();
		$map->load_post_type_archive_mappings();
		$map->load_woocommerce_mappings();
		$map->load_edd_mappings();
		$map->load_dokan_mappings();
		$map->update_domain( $domain );
		$map->save();

		DomainRegistry::purge( $domain->ID );
	}

	/**
	 * @param Domain $domain
	 *
	 * @return array
	 */
	public function format_domain( Domain $domain ) {
		$mappings = array_values( $domain->mappings() );
		$last = count( $mappings ) - 1;
		$mapped_to = [];

		foreach ( $mappings as $index => $mapping ) {
			$mapping = (array) $mapping;
			$role = $index === 0 ? 'root' : ( $index === $last ? 'fallback' : 'path' );
			$action = (string) Arr::get( $mapping, 'action', 'map_to_resource' );
			$post_id = (int) ( Arr::get( $mapping, 'page_id' ) ?: Arr::get( $mapping, 'p' ) );

			$mapped_to[] = [
				'mapping_id' => (string) Arr::get( $mapping, 'mapping_id', '' ),
				'role' => $role,
				'path' => $role === 'path' ? (string) Arr::get( $mapping, 'url_path', '' ) : '',
				'is_regex' => $role === 'path' ? (bool) Arr::get( $mapping, 'is_regex', false ) : false,
				'action' => $action,
				'resource_type' => $action === 'map_to_resource' ? (string) Arr::get( $mapping, 'resource_type', '' ) : '',
				'post_id' => $action === 'map_to_resource' ? $post_id : 0,
				'post_type' => $action === 'map_to_resource' ? (string) Arr::get( $mapping, 'post_type', '' ) : '',
				'taxonomy' => $action === 'map_to_resource' ? (string) Arr::get( $mapping, 'taxonomy', '' ) : '',
				'term_id' => $action === 'map_to_resource' ? (int) Arr::get( $mapping, 'term_id', 0 ) : 0,
				'map_sub_pages' => (bool) Arr::get( $mapping, 'map_sub_pages', false ),
				'redirect_url' => $action === 'redirect' ? (string) Arr::get( $mapping, 'redirect_url', '' ) : '',
				'redirect_status' => $action === 'redirect' ? (int) Arr::get( $mapping, 'redirect_status', 0 ) : 0,
			];
		}

		$status = $domain->ID ? get_post_meta( $domain->ID, FetchDomainConnectionStatusAjaxHandler::META, true ) : [];
		$checked = is_array( $status ) ? (int) Arr::get( $status, 'date', 0 ) : 0;

		return [
			'id' => (int) $domain->ID,
			'domain' => (string) $domain->host(),
			'active' => (bool) $domain->is_active(),
			'enforced_protocol' => (string) $domain->enforced_protocol(),
			'mapped_to' => $mapped_to,
			'connection_state' => $domain->ID ? $domain->get_status() : 'initial',
			'connection_checked_at' => $checked ? gmdate( 'c', $checked ) : '',
		];
	}

	/**
	 * @return array
	 */
	private function domain_schema() {
		return [
			'type' => 'object',
			'properties' => [
				'id' => [ 'type' => 'integer' ],
				'domain' => [ 'type' => 'string' ],
				'active' => [ 'type' => 'boolean' ],
				'enforced_protocol' => [ 'type' => 'string' ],
				'mapped_to' => [
					'type' => 'array',
					'items' => [
						'type' => 'object',
						'properties' => [
							'mapping_id' => [ 'type' => 'string' ],
							'role' => [ 'type' => 'string', 'enum' => [ 'root', 'path', 'fallback' ] ],
							'path' => [ 'type' => 'string' ],
							'is_regex' => [ 'type' => 'boolean' ],
							'action' => [ 'type' => 'string' ],
							'resource_type' => [ 'type' => 'string' ],
							'post_id' => [ 'type' => 'integer' ],
							'post_type' => [ 'type' => 'string' ],
							'taxonomy' => [ 'type' => 'string' ],
							'term_id' => [ 'type' => 'integer' ],
							'map_sub_pages' => [ 'type' => 'boolean' ],
							'redirect_url' => [ 'type' => 'string' ],
							'redirect_status' => [ 'type' => 'integer' ],
						],
					],
				],
				'connection_state' => [ 'type' => 'string', 'enum' => [ 'initial', 'connected', 'failed' ] ],
				'connection_checked_at' => [ 'type' => 'string' ],
			],
		];
	}

}
