<?php

namespace WpLandingKit\Abilities;

use WpLandingKit\Framework\Providers\ServiceProviderBase;

/**
 * Class AbilitiesServiceProvider
 * @package WpLandingKit\Abilities
 *
 * Registers the plugin's abilities with the WordPress Abilities API (WordPress 6.9+). No-op on older versions.
 */
class AbilitiesServiceProvider extends ServiceProviderBase {

	public function register() {
		$this->app->singleton( DomainAbilities::class );
	}

	public function boot() {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		$abilities = $this->app->make( DomainAbilities::class );

		add_action( 'wp_abilities_api_categories_init', [ $abilities, 'register_category' ] );
		add_action( 'wp_abilities_api_init', [ $abilities, 'register' ] );
	}

}
