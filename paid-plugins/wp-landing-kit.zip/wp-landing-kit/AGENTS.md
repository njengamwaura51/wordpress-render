# WP Landing Kit

## Overview

WP Landing Kit maps domains to WordPress content. Application code is in `app/`, reusable framework code is in `framework/`, configuration is in `config/`, templates are in `templates/`, and automated tests are in `tests/`.

## Environment

The Copilot setup workflow has already installed the locked Composer and npm dependencies, started MySQL, and installed the WordPress test suite. Do not rerun `composer install`, `npm ci`, or `bin/install-wp-tests.sh` unless the task changes their manifests or test setup.

The project runs its test suite on PHP 7.4.

## Validation

Run the PHPUnit suite:

```bash
phpunit --configuration phpunit.xml.dist
```

There is no existing E2E test suite. Do not create or run an E2E suite unless the task introduces one. Run `npm run prod` only when JavaScript or Sass source changes require updated build assets.

## Conventions

- Keep WordPress-facing code compatible with PHP 7.4.
- Put application behavior in `app/` and generic framework behavior in `framework/`.
- Follow the surrounding coding style and test related changes in the matching `tests/app/` or `tests/framework/` area.
