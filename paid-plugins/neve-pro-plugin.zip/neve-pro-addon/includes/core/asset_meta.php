<?php
/**
 * Reader for build-generated asset.
 *
 * @package Neve_Pro\Core
 */

namespace Neve_Pro\Core;

/**
 * Class Asset_Meta
 *
 * @package Neve_Pro\Core
 */
class Asset_Meta {

	/**
	 * Get asset meta from a generated asset file.
	 *
	 * @param string $path Absolute path to the generated asset file.
	 *
	 * @return array
	 */
	public static function get( $path ) {
		$meta = self::read( $path );

		if ( ! isset( $meta['dependencies'] ) || ! is_array( $meta['dependencies'] ) ) {
			$meta['dependencies'] = array();
		}

		if ( ! isset( $meta['version'] ) ) {
			$meta['version'] = defined( 'NEVE_PRO_VERSION' ) ? NEVE_PRO_VERSION : false;
		}

		return $meta;
	}

	/**
	 * Read the file content.
	 *
	 * @param string $path Absolute path to the generated asset file.
	 *
	 * @return array
	 */
	private static function read( $path ) {
		if ( ! is_file( $path ) || ! is_readable( $path ) ) {
			return array();
		}

		$meta = include $path;

		return is_array( $meta ) ? $meta : array();
	}
}
