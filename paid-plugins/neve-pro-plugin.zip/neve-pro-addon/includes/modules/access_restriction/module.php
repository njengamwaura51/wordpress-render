<?php
/**
 * Access Restriction Module Main Class
 *
 * @package Neve_Pro\Modules\Access_Restriction
 */
namespace Neve_Pro\Modules\Access_Restriction;

use Neve_Pro\Core\Abstract_Module;
use Neve_Pro\Core\Loader;
use Neve_Pro\Modules\Access_Restriction\Admin\Dashboard\Manager as Admin_Dashboard;
use Neve_Pro\Modules\Access_Restriction\Admin\Content_Restriction\Edit_Post as Admin_Post_Edit;
use Neve_Pro\Modules\Access_Restriction\Admin\Content_Restriction\Edit_Term as Admin_Term_Edit;
use Neve_Pro\Modules\Access_Restriction\Content_Restriction\Facade as Content_Restriction_Facade;
use Neve_Pro\Modules\Access_Restriction\General_Settings\Storage_Adapter;
use Neve_Pro\Modules\Access_Restriction\Router\Restriction_Behavior\Redirect_Custom_Login;

/**
 * Main class which initializes the module
 */
class Module extends Abstract_Module {

	/**
	 * Components the frontend enforcement path cannot work without, relative to
	 * this namespace.
	 *
	 * @var string[]
	 */
	const REQUIRED_CLASSES = array(
		// Interfaces and traits the implementations below are declared against.
		'Content_Restriction\Authorization_Layer\Layer',
		'Content_Resource\Type\Content_Resource',
		'Content_Resource\Type\Utility',
		'Content_Resource\Authorization\Checker\Builder\Builder',
		'Content_Resource\Authorization\Checker\Builder\Utility',
		'Utility\Context_Trait',
		'Utility\Sanitize',
		// The enforcement path itself.
		'Content_Restriction\Facade',
		'Content_Restriction\Authorization_Layer\Main_Query',
		'Content_Restriction\Authorization_Layer\Post',
		'Content_Resource\Resource_Factory',
		'Content_Resource\Settings\Resource_Settings',
		'Content_Resource\Type\Post',
		'Content_Resource\Type\Term',
		'Content_Resource\Authorization\Checker\Checker_Composite',
		'Content_Resource\Authorization\Checker\Builder\Director',
		'Content_Resource\Authorization\Checker\Builder\Post_Builder',
		'Content_Resource\Authorization\Checker\Builder\Term_Builder',
		'Router\Restrict_Current_Page',
		'General_Settings\Module_Settings',
	);

	/**
	 * Classes that are missing and prevent the module from enforcing restrictions.
	 *
	 * @var array<string>
	 */
	private $missing = array();

	/**
	 * Constructor
	 *
	 * @return void
	 */
	public function __construct() {
		parent::__construct();
		Redirect_Custom_Login::register_hook_for_custom_login_redirect(); // That's here because should be run earlier.
		( new Admin_Dashboard() )->init(); // We enqueue scripts here to allow the toggle to work properly, if it is already disabled.
	}

	/**
	 * Run Module
	 *
	 * @return void
	 */
	public function run_module() {
		add_action( 'init', [ $this, 'register_hooks' ], 1 );
	}

	/**
	 * Init Module
	 *
	 * Run on 'init' hook because Custom Post Types are not registered before init.
	 * (Custom Post Types are needed to prepare module options)
	 *
	 * @return void
	 */
	public function register_hooks() {
		// If any of the required classes are missing, the module cannot enforce restrictions.
		// Register a fail-closed response instead of silently skipping the facade.
		$this->missing = $this->get_missing();

		if ( ! empty( $this->missing ) ) {
			add_action( 'template_redirect', array( $this, 'deny_request' ), 0 );

			return;
		}

		( new Content_Restriction_Facade() )->run(); // restricts content on front side

		if ( class_exists( Admin_Post_Edit::class ) ) {
			( new Admin_Post_Edit() )->init();
		}

		if ( class_exists( Admin_Term_Edit::class ) ) {
			( new Admin_Term_Edit() )->init();
		}
	}

	/**
	 * Define Module Properties
	 *
	 * @return void
	 */
	public function define_module_properties() {
		$this->slug              = 'access_restriction';
		$this->order             = 11;
		$this->has_dynamic_style = false;
		$this->force_enabled     = true;
	}
	
	/**
	 * Setup module labels.
	 */
	public function setup_labels() {
		$this->name          = __( 'Content restriction', 'neve-pro-addon' );
		$this->description   = __( 'Create members-only content areas. Control access by user roles, logged-in status, or custom rules.', 'neve-pro-addon' );
		$this->documentation = array(
			'url'   => 'https://docs.themeisle.com/article/1863-content-restriction-module-documentation',
			'label' => __( 'Learn more', 'neve-pro-addon' ),
		);

		$options[ Storage_Adapter::WP_OPTION_NAME ] = array(
			'type'              => 'react',
			'default'           => 0,
			'show_in_rest'      => true,
			'sanitize_callback' => 'absint',
		);

		$this->options = array(
			array(
				'label'   => __( 'Enable / disable content restriction for content types', 'neve-pro-addon' ),
				'options' => $options,
			),
		);
	}

	/**
	 * Required components that are unavailable on this install.
	 *
	 * @return string[] Relative component names, empty when the module is intact.
	 */
	private function get_missing() {
		$missing = array();

		foreach ( self::REQUIRED_CLASSES as $relative_name ) {
			$file = __DIR__ . '/' . strtolower( str_replace( '\\', '/', $relative_name ) ) . '.php';

			if ( ! is_file( $file ) || ! is_readable( $file ) ) {
				$missing[] = $relative_name;
			}
		}

		return $missing;
	}

	/**
	 * Stop the request with a controlled 503.
	 *
	 * @return void
	 */
	public function deny_request() {
		if ( current_user_can( 'manage_options' ) ) {
			return;
		}

		error_log( 'Neve Pro content restriction: cannot enforce restrictions, the frontend is being denied. Unavailable: ' . implode( ', ', $this->missing ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log

		nocache_headers();

		wp_die(
			esc_html__( 'This content is restricted.', 'neve-pro-addon' ),
			esc_html__( 'Restricted', 'neve-pro-addon' ),
			array( 'response' => 503 )
		);
	}
}
