<?php
/**
 * Replace header, footer or hooks for Elementor page builder.
 *
 * @package Neve_Pro\Modules\Custom_Layouts\Admin\Builders
 */

namespace Neve_Pro\Modules\Custom_Layouts\Admin\Builders;

use Neve_Pro\Traits\Core;
use Neve_Pro\Admin\Custom_Layouts_Cpt;

/**
 * Class Elementor
 *
 * @package Neve_Pro\Modules\Custom_Layouts\Admin\Builders
 */
class Elementor extends Abstract_Builders {
	use Core;

	/**
	 * Check if class should load or not.
	 *
	 * @return bool
	 */
	public function should_load() {
		return class_exists( '\Elementor\Plugin', false );
	}

	/**
	 * Function that enqueues styles if needed.
	 */
	public function add_styles() {
		$custom_layouts   = Custom_Layouts_Cpt::get_custom_layouts();
		$registered_posts = array();

		foreach ( $custom_layouts as $custom_layout_ids ) {
			foreach ( array_keys( $custom_layout_ids ) as $post_id ) {
				$post_id = Abstract_Builders::maybe_get_translated_layout( $post_id );

				if ( isset( $registered_posts[ $post_id ] ) ) {
					continue;
				}

				if ( ! $this->is_elementor_layout( $post_id ) ) {
					continue;
				}

				if ( $this->is_expired( $post_id ) || ! $this->check_conditions( $post_id ) ) {
					continue;
				}

				/**
				 * Register the layout before Elementor enqueues post styles. Elementor 4's
				 * atomic styles manager uses this action to collect the post IDs whose
				 * generated styles need to be included on the current page.
				 */
				do_action( 'elementor/post/render', $post_id ); // phpcs:ignore WordPress.NamingConventions.ValidHookName.UseUnderscores -- Elementor hook.
				$registered_posts[ $post_id ] = true;
			}
		}

		if ( ! empty( $registered_posts ) ) {
			$this->enqueue_elementor_styles();
		}
	}

	/**
	 * Check whether a Custom Layout is built with Elementor.
	 *
	 * @param int $post_id Layout post ID.
	 *
	 * @return bool
	 */
	protected function is_elementor_layout( $post_id ) {
		return Abstract_Builders::get_post_builder( $post_id ) === 'elementor';
	}

	/**
	 * Run Elementor's frontend style pipeline for pages where only a Custom Layout
	 * uses Elementor.
	 *
	 * @return void
	 */
	protected function enqueue_elementor_styles() {
		\Elementor\Plugin::instance()->frontend->enqueue_styles();
	}

	/**
	 * Builder id.
	 *
	 * @return string
	 */
	function get_builder_id() {
		return 'elementor';
	}

	/**
	 * Load markup for current hook.
	 *
	 * @param int $post_id Layout id.
	 *
	 * @return mixed|void
	 */
	function render( $post_id ) {
		$post_id = Abstract_Builders::maybe_get_translated_layout( $post_id );
		$content = \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $post_id, true );
		echo apply_filters( 'neve_custom_layout_magic_tags', $content, $post_id ); //phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		return true;
	}

	/**
	 * Enqueue necessary hooks.
	 *
	 * @return void
	 */
	public function register_hooks() {
		parent::register_hooks();

		$custom_layouts = Custom_Layouts_Cpt::get_custom_layouts();
		foreach ( $custom_layouts as $layout => $custom_layout_ids ) {
			$this->try_re_enqueue_wordpress_styles( $custom_layout_ids );
		}
	}

	/**
	 * Re-enqueue WordPress styles if needed. Some plugins might dequeue them, which will break the layout.
	 *
	 * @param int[] $custom_layout_ids The custom layout IDs.
	 * @return void
	 */
	public function try_re_enqueue_wordpress_styles( $custom_layout_ids ) {

		/**
		 * If we have some core blocks in the custom layout, we need to re-enqueue their styles.
		 */
		$has_core_blocks = false;
		foreach ( $custom_layout_ids as $custom_layout_id => $priority ) {
			if ( has_blocks( $custom_layout_id ) ) {
				$has_core_blocks = true;
				break;
			}
		}

		if ( ! $has_core_blocks ) {
			return;
		}

		add_action(
			'wp_enqueue_scripts',
			function() {
				if ( wp_style_is( 'wp-block-library', 'enqueued' ) ) {
					return;
				}

				wp_enqueue_style( 'wp-block-library' );
			},
			1000 // After Elementor de-queues the block library styles.
		);
	}
}
