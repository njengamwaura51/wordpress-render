<?php
/**
 * Template used for component rendering wrapper.
 *
 * Name:    Header Footer Grid
 *
 * @version 1.0.0
 * @package HFG
 */
namespace HFG;

use HFG\Core\Components\SecondNav;

$style = component_setting( SecondNav::STYLE_ID, 'style-plain' );

$container_classes = [ 'nav-menu-secondary' ];
if ( $style !== 'style-plain' ) {
	$container_classes[] = $style;
	$container_classes[] = 'm-style';
}

?>
<?php
// Device rows can render this landmark twice and pro allows extra
// instances — suffix the label like the header nav does, and keep the
// menu id unique per device/instance (a bare 'secondary-menu' id also
// collides with the theme's secondary menu component).
$nav_device       = current_device( \Neve_Pro\Modules\Header_Footer_Grid\Builder\Page_Header::BUILDER_NAME );
$nav_device_label = $nav_device === 'mobile' ? __( 'Mobile', 'neve-pro-addon' ) : __( 'Desktop', 'neve-pro-addon' );
$nav_id           = current_component( \Neve_Pro\Modules\Header_Footer_Grid\Builder\Page_Header::BUILDER_NAME )->get_id();
$instance_suffix  = '';
if ( preg_match( '/_(\d+)$/', (string) $nav_id, $nav_instance ) && (int) $nav_instance[1] > 1 ) {
	$instance_suffix = ' ' . ( (int) $nav_instance[1] - 1 );
}
$landmark_label = __( 'Page Header Menu', 'neve-pro-addon' ) . $instance_suffix . ' (' . $nav_device_label . ')';
$nav_menu_id    = 'page-header-menu-' . ( $nav_device ? $nav_device : 'desktop' ) . ( $instance_suffix !== '' ? '-' . (int) $nav_instance[1] : '' );
?>
<div class="nv-top-bar">
	<div role="navigation" class="menu-content <?php echo esc_attr( join( ' ', $container_classes ) ); ?>"
		aria-label="<?php echo esc_attr( $landmark_label ); ?>">
		<?php
		wp_nav_menu(
			array(
				'theme_location' => 'page-header',
				'menu_id'        => $nav_menu_id,
				'menu_class'     => 'nav-ul',
				'container'      => 'ul',
				'depth'          => - 1,
				'fallback_cb'    => '__return_false',
				'before'         => '<div class="wrap">',
				'after'          => '</div>',
			)
		);
		?>
	</div>
</div>

