<?php
/**
 * Rest Endpoints Handler.
 *
 * @package Neve_Pro\Modules\LifterLMS_Booster\Rest
 */

namespace Neve_Pro\Modules\LifterLMS_Booster\Rest;

use WP_Query;

/**
 * Class Server
 *
 * @package Neve_Pro\Modules\LifterLMS_Booster\Rest
 */
class Server {

	/**
	 * Query parameters the client is allowed to submit.
	 * All other keys are either controlled server-side (silently dropped)
	 * Limiting the surface area prevents unintended query shapes,
	 * expensive JOINs, and content enumeration via meta/tax filters.
	 */
	const ALLOWED_QUERY_ARGS = array( 's', 'order', 'orderby', 'author', 'year', 'monthnum' );

	/**
	 * Valid values for the 'order' query argument.
	 * Any other value is rejected to prevent unexpected sort semantics.
	 */
	const ALLOWED_ORDER_VALUES = array( 'ASC', 'DESC' );

	/**
	 * Valid values for the 'orderby' query argument.
	 * Restricted to safe, indexed columns only. Non-indexed columns cause
	 * full-table sorts that significantly degrade database performance.
	 */
	const ALLOWED_ORDERBY_VALUES = array( 'date', 'title', 'menu_order' );

	/**
	 * Upper bound for posts_per_page regardless of the stored LifterLMS
	 * option value. Prevents resource exhaustion if a store admin sets
	 * a very high value in the LifterLMS settings.
	 */
	const MAX_POSTS_PER_PAGE = 100;

	/**
	 * Initialize the rest functionality.
	 */
	public function register_hooks() {
		add_action( 'rest_api_init', array( $this, 'register_endpoints' ) );
	}

	/**
	 * Register endpoints.
	 */
	public function register_endpoints() {

		register_rest_route(
			NEVE_PRO_REST_NAMESPACE,
			'/courses/page/(?P<page_number>\d+)/',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'get_courses' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'query'       => array(
						'type'              => 'string',
						'sanitize_callback' => array( $this, 'sanitize_query_param' ),
						'validate_callback' => array( $this, 'validate_infinite_scroll_query' ),
					),
					'page_number' => array(
						'validate_callback' => array( $this, 'validate_page_number' ),
					),
				),
			)
		);

		register_rest_route(
			NEVE_PRO_REST_NAMESPACE,
			'memberships/page/(?P<page_number>\d+)/',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'get_memberships' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'query'       => array(
						'type'              => 'string',
						'sanitize_callback' => array( $this, 'sanitize_query_param' ),
						'validate_callback' => array( $this, 'validate_infinite_scroll_query' ),
					),
					'page_number' => array(
						'validate_callback' => array( $this, 'validate_page_number' ),
					),
				),
			)
		);
	}

	/**
	 * Check if query is a valid JSON.
	 *
	 * @param string $query Query in JSON format.
	 *
	 * @return bool
	 */
	public function validate_infinite_scroll_query( $query ) {
		json_decode( $query );

		return ( json_last_error() === 0 );
	}

	/**
	 * Validate that page_number is numeric.
	 *
	 * @param mixed $value The page_number value from the URL.
	 * @return bool
	 */
	public function validate_page_number( $value ) {
		return is_numeric( $value );
	}

	/**
	 * Decode and sanitize the raw JSON 'query' REST parameter.
	 *
	 * Only keys in ALLOWED_QUERY_ARGS are forwarded to WP_Query.
	 * All other keys are silently dropped, preserving backward compatibility
	 * with the frontend which echoes the full $wp_query->query (including
	 * keys such as post_type that the server always overrides anyway).
	 *
	 * Validated values:
	 * - order   → must be ASC or DESC
	 * - orderby → must be one of ALLOWED_ORDERBY_VALUES
	 * - s       → sanitized as plain text (strips HTML/scripts)
	 * - author / year / monthnum → cast to positive integers
	 *
	 * @param string $query Raw JSON string from the request body.
	 * @return array|\WP_Error Sanitized arg array, or WP_Error on invalid input.
	 */
	public function sanitize_query_param( $query ) {
		$decoded  = json_decode( $query, true );
		$filtered = array_intersect_key( is_array( $decoded ) ? $decoded : array(), array_flip( self::ALLOWED_QUERY_ARGS ) );

		$sanitized = array();

		if ( isset( $filtered['s'] ) ) {
			$sanitized['s'] = sanitize_text_field( $filtered['s'] );
		}

		if ( isset( $filtered['author'] ) ) {
			$sanitized['author'] = absint( $filtered['author'] );
		}

		if ( isset( $filtered['year'] ) ) {
			$sanitized['year'] = absint( $filtered['year'] );
		}
		if ( isset( $filtered['monthnum'] ) ) {
			$sanitized['monthnum'] = absint( $filtered['monthnum'] );
		}

		if ( isset( $filtered['order'] ) ) {
			$order_upper = strtoupper( (string) $filtered['order'] );
			if ( ! in_array( $order_upper, self::ALLOWED_ORDER_VALUES, true ) ) {
				return new \WP_Error(
					'invalid_query',
					'Unsupported query parameters provided.',
					array( 'status' => 400 )
				);
			}
			$sanitized['order'] = $order_upper;
		}

		if ( isset( $filtered['orderby'] ) ) {
			if ( ! in_array( $filtered['orderby'], self::ALLOWED_ORDERBY_VALUES, true ) ) {
				return new \WP_Error(
					'invalid_query',
					'Unsupported query parameters provided.',
					array( 'status' => 400 )
				);
			}
			$sanitized['orderby'] = $filtered['orderby'];
		}

		return $sanitized;
	}

	/**
	 * Infinite scroll REST Api callback for courses.
	 *
	 * @param \WP_REST_Request $request Rest request.
	 *
	 * @return \WP_REST_Response.
	 */
	public function get_courses( \WP_REST_Request $request ) {

		if ( empty( $request['page_number'] ) ) {
			return new \WP_REST_Response(
				array(
					'code'    => 'error',
					'message' => esc_html__( 'Course infinite scroll error: Page number is missing.', 'neve-pro-addon' ),
				),
				400
			);
		}

		$page_number = absint( $request['page_number'] );
		$client_args = is_array( $request['query'] ) ? $request['query'] : array();
		$sorting     = explode( ',', get_option( 'lifterlms_shop_ordering', 'menu_order,ASC' ) );
		$order_by    = empty( $sorting[0] ) ? 'menu_order' : $sorting[0];

		if ( 'menu_order' === $order_by ) {
			$order_by .= ' post_title';
		}
		$order    = empty( $sorting[1] ) ? 'ASC' : $sorting[1];
		$order_by = apply_filters( 'llms_courses_orderby', $order_by );
		$order    = apply_filters( 'llms_courses_order', $order );
		$per_page = min( absint( get_option( 'lifterlms_shop_courses_per_page', 9 ) ), self::MAX_POSTS_PER_PAGE );
		$args     = array_merge(
			$client_args,
			array(
				'post_type'           => 'course',
				'post_status'         => 'publish',
				'posts_per_page'      => $per_page,
				'paged'               => $page_number,
				'order'               => $order,
				'orderby'             => $order_by,
				'ignore_sticky_posts' => true,
			)
		);

		remove_all_actions( 'lifterlms_before_loop' );
		remove_all_actions( 'lifterlms_after_loop' );
		add_filter( 'llms_get_template_part', array( $this, 'remove_pagination' ), 10, 3 );
		add_action( 'lifterlms_before_loop_item', array( $this, 'wrap_lifter_card_media' ), 0 );
		add_action( 'lifterlms_before_loop_item_title', array( $this, 'wrap_close' ), 40 );
		add_action( 'lifterlms_before_loop_item_title', array( $this, 'wrap_lifter_card_content' ), 45 );
		add_action( 'lifterlms_after_loop_item', array( $this, 'wrap_close' ), 40 );

		ob_start();
		$query = new WP_Query( $args );
		if ( $query->have_posts() ) {
			lifterlms_loop( $query );
		}
		$markup = ob_get_contents();
		ob_end_clean();

		if ( $markup === '' ) {
			return new \WP_REST_Response(
				null,
				204
			);
		}

		return new \WP_REST_Response(
			array(
				'code'   => 'success',
				'markup' => $markup,
			),
			200
		);
	}

	/**
	 * Infinite scroll REST Api callback for memberships.
	 *
	 * @param \WP_REST_Request $request Rest request.
	 *
	 * @return \WP_REST_Response.
	 */
	public function get_memberships( \WP_REST_Request $request ) {

		if ( empty( $request['page_number'] ) ) {
			return new \WP_REST_Response(
				array(
					'code'    => 'error',
					'message' => esc_html__( 'Membership infinite scroll error: Page number is missing.', 'neve-pro-addon' ),
				),
				400
			);
		}
		$page_number = absint( $request['page_number'] );
		$client_args = is_array( $request['query'] ) ? $request['query'] : array();

		$per_page = min( absint( get_option( 'lifterlms_memberships_per_page', 9 ) ), self::MAX_POSTS_PER_PAGE );
		$sorting  = $request['sorting'];
		$order_by = empty( $sorting[0] ) ? 'menu_order' : $sorting[0];
		if ( 'menu_order' === $order_by ) {
			$order_by .= ' post_title';
		}
		$order    = empty( $sorting[1] ) ? 'ASC' : $sorting[1];
		$order_by = apply_filters( 'llms_memberships_orderby', $order_by );
		$order    = apply_filters( 'llms_memberships_order', $order );
		$args     = array_merge(
			$client_args,
			array(
				'post_type'           => 'llms_membership',
				'post_status'         => 'publish',
				'posts_per_page'      => $per_page,
				'paged'               => $page_number,
				'order'               => $order,
				'orderby'             => $order_by,
				'ignore_sticky_posts' => true,
			)
		);

		$query = new WP_Query( $args );
		remove_all_actions( 'lifterlms_before_loop' );
		remove_all_actions( 'lifterlms_after_loop' );
		add_filter( 'llms_get_template_part', array( $this, 'remove_pagination' ), 10, 3 );
		add_action( 'lifterlms_before_loop_item', array( $this, 'wrap_lifter_card_media' ), 0 );
		add_action( 'lifterlms_before_loop_item_title', array( $this, 'wrap_close' ), 40 );
		add_action( 'lifterlms_before_loop_item_title', array( $this, 'wrap_lifter_card_content' ), 45 );
		add_action( 'lifterlms_after_loop_item', array( $this, 'wrap_close' ), 40 );

		ob_start();
		if ( $query->have_posts() ) {
			lifterlms_loop( $query );
		}
		$markup = ob_get_contents();
		ob_end_clean();

		if ( $markup === '' ) {
			return new \WP_REST_Response(
				null,
				204
			);
		}

		return new \WP_REST_Response(
			array(
				'code'   => 'success',
				'markup' => $markup,
			),
			200
		);
	}

	/**
	 * Card media wrapper.
	 */
	public function wrap_lifter_card_media() {
		echo '<div class="nv-lifter-card-media-wrap">';
	}

	/**
	 * Close wrapper.
	 */
	public function wrap_close() {
		echo '</div>';
	}

	/**
	 * Card content wrapper.
	 */
	public function wrap_lifter_card_content() {
		echo '<div class="nv-lifter-card-content-wrap">';
	}

	/**
	 * Remove pagination when fetching posts.
	 *
	 * @param string $template Template.
	 * @param string $slug Slug.
	 * @param string $name Name.
	 *
	 * @return string;
	 */
	public function remove_pagination( $template, $slug, $name ) {
		if ( $slug === 'loop/pagination' ) {
			return '';
		}

		return $template;
	}

}
