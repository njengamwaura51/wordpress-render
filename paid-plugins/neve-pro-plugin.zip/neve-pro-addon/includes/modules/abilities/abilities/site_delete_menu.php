<?php
/**
 * Ability: neve/site-delete-menu.
 *
 * Delete a navigation menu, optionally unassigning any attached locations.
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */

namespace Neve_Pro\Modules\Abilities\Abilities;

/**
 * Class Site_Delete_Menu
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */
class Site_Delete_Menu extends Abstract_Ability {

	/**
	 * {@inheritDoc}
	 */
	protected function get_id() {
		return 'site-delete-menu';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_label() {
		return __( 'Delete navigation menu', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_description() {
		return __( 'Delete a navigation menu and unassign it from any Neve menu locations. Set confirm=true to proceed.', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_annotations() {
		return array( 'destructive' => true );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_input_schema() {
		return array(
			'type'       => 'object',
			'required'   => array( 'menu_id' ),
			'properties' => array(
				'menu_id'  => array(
					'type'        => 'integer',
					'description' => 'The menu id to delete.',
				),
				'confirm'  => array(
					'type'        => 'boolean',
					'description' => 'Must be true to delete the menu.',
					'default'     => false,
				),
				'unassign' => array(
					'type'        => 'boolean',
					'description' => 'Unassign the menu from any locations before deleting it.',
					'default'     => true,
				),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'success'              => array( 'type' => 'boolean' ),
				'error'                => array(
					'type'       => 'object',
					'properties' => array(
						'code'    => array( 'type' => 'string' ),
						'message' => array( 'type' => 'string' ),
						'field'   => array( 'type' => 'string' ),
					),
				),
				'menu_id'              => array( 'type' => 'integer' ),
				'deleted'              => array( 'type' => 'boolean' ),
				'unassigned_locations' => array(
					'type'  => 'array',
					'items' => array( 'type' => 'string' ),
				),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function run( array $input ) {
		$menu_id = isset( $input['menu_id'] ) ? (int) $input['menu_id'] : 0;

		if ( ! is_nav_menu( $menu_id ) ) {
			return $this->validation_issue( 'unknown_menu', __( 'No menu with that id exists.', 'neve-pro-addon' ), 'menu_id' );
		}

		if ( empty( $input['confirm'] ) ) {
			return $this->validation_issue( 'confirm_required', __( 'Set confirm=true to delete this menu.', 'neve-pro-addon' ), 'confirm' );
		}

		$unassigned_locations = array();
		if ( ! isset( $input['unassign'] ) || $input['unassign'] ) {
			$locations = get_theme_mod( 'nav_menu_locations', array() );
			$locations = is_array( $locations ) ? $locations : array();

			foreach ( $locations as $location => $assigned_menu_id ) {
				if ( (int) $assigned_menu_id !== $menu_id ) {
					continue;
				}

				unset( $locations[ $location ] );
				$unassigned_locations[] = $location;
			}

			set_theme_mod( 'nav_menu_locations', $locations );
		}

		$deleted = wp_delete_nav_menu( $menu_id );
		if ( is_wp_error( $deleted ) ) {
			return $deleted;
		}

		if ( false === $deleted ) {
			return $this->error( 'delete_failed', __( 'The menu could not be deleted.', 'neve-pro-addon' ), 500 );
		}

		return array(
			'success'              => true,
			'menu_id'              => $menu_id,
			'deleted'              => true,
			'unassigned_locations' => $unassigned_locations,
		);
	}
}
