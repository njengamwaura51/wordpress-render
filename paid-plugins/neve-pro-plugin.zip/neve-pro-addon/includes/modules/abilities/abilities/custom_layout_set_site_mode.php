<?php
/**
 * Ability: neve/custom-layout-set-site-mode.
 *
 * Switch the whole-site mode between normal, maintenance and coming-soon. Site
 * mode is driven by a published Custom Layout whose type is "maintenance" or
 * "coming_soon".
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */

namespace Neve_Pro\Modules\Abilities\Abilities;

/**
 * Class Custom_Layout_Set_Site_Mode
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */
class Custom_Layout_Set_Site_Mode extends Custom_Layout_Helpers {

	/**
	 * Layout types that drive a site mode.
	 */
	const MODE_TYPES = array( 'maintenance', 'coming_soon' );

	/**
	 * {@inheritDoc}
	 */
	protected function get_id() {
		return 'custom-layout-set-site-mode';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_label() {
		return __( 'Set site mode', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_description() {
		return __( 'Put the site into maintenance or coming-soon mode using a Custom Layout, or turn it off. Maintenance/coming-soon require a layout_id of a layout to serve.', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_capability() {
		return 'manage_options';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_annotations() {
		return array(
			'readonly'    => false,
			'destructive' => true,
			'idempotent'  => true,
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_input_schema() {
		return array(
			'type'       => 'object',
			'required'   => array( 'mode' ),
			'properties' => array(
				'mode'      => array(
					'type' => 'string',
					'enum' => array( 'off', 'maintenance', 'coming_soon' ),
				),
				'layout_id' => array(
					'type'        => 'integer',
					'description' => 'Layout to serve (required for maintenance/coming_soon).',
				),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'success'   => array( 'type' => 'boolean' ),
				'error'     => array(
					'type'       => 'object',
					'properties' => array(
						'code'    => array( 'type' => 'string' ),
						'message' => array( 'type' => 'string' ),
						'field'   => array( 'type' => 'string' ),
					),
				),
				'mode'      => array( 'type' => 'string' ),
				'layout_id' => array( 'type' => 'integer' ),
				'active'    => array( 'type' => 'boolean' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function run( array $input ) {
		$mode = isset( $input['mode'] ) ? $input['mode'] : 'off';

		// Turn off any currently active mode layouts first.
		$this->deactivate_mode_layouts();

		if ( 'off' === $mode ) {
			delete_transient( 'custom_layouts_post_map_v3' );
			return array(
				'success' => true,
				'mode'    => 'off',
				'active'  => false,
			);
		}

		if ( empty( $input['layout_id'] ) ) {
			return $this->validation_issue( 'layout_required', __( 'layout_id is required when mode is maintenance or coming_soon.', 'neve-pro-addon' ), 'layout_id' );
		}

		$layout_id = (int) $input['layout_id'];
		$post      = get_post( $layout_id );

		if ( ! $post || self::CPT !== $post->post_type ) {
			return $this->validation_issue( 'layout_required', __( 'A valid layout_id is required for this mode.', 'neve-pro-addon' ), 'layout_id' );
		}

		update_post_meta( $layout_id, self::META_LAYOUT, $mode );
		wp_update_post(
			array(
				'ID'          => $layout_id,
				'post_status' => 'publish',
			)
		);

		delete_transient( 'custom_layouts_post_map_v3' );

		return array(
			'success'   => true,
			'mode'      => $mode,
			'layout_id' => $layout_id,
			'active'    => true,
		);
	}

	/**
	 * Draft any published layouts currently driving a site mode.
	 *
	 * @return void
	 */
	private function deactivate_mode_layouts() {
		$query = new \WP_Query(
			array(
				'post_type'      => self::CPT,
				'post_status'    => 'publish',
				'posts_per_page' => 100,
				'meta_key'       => self::META_LAYOUT, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value'     => self::MODE_TYPES, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				'meta_compare'   => 'IN',
			)
		);

		foreach ( $query->posts as $post ) {
			wp_update_post(
				array(
					'ID'          => $post->ID,
					'post_status' => 'draft',
				)
			);
		}
	}
}
