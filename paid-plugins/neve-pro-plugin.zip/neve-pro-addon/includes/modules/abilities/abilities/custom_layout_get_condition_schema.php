<?php
/**
 * Ability: neve/custom-layout-get-condition-schema.
 *
 * The live conditional-display ruleset used by Custom Layouts. Roots are
 * integration-aware (Woo / LMS / WPML roots only appear when active), so this
 * is the source of truth for building `conditions` in custom-layout-upsert.
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */

namespace Neve_Pro\Modules\Abilities\Abilities;

use Neve_Pro\Admin\Conditional_Display;

/**
 * Class Custom_Layout_Get_Condition_Schema
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */
class Custom_Layout_Get_Condition_Schema extends Abstract_Ability {

	/**
	 * End-value sets that are large/dynamic; we describe rather than enumerate them.
	 */
	const DYNAMIC_END_SETS = array( 'posts', 'pages', 'users' );

	/**
	 * Cap for enumerating an end-value set inline.
	 */
	const ENUM_CAP = 60;

	/**
	 * {@inheritDoc}
	 */
	protected function get_id() {
		return 'custom-layout-get-condition-schema';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_label() {
		return __( 'Get custom layout condition schema', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_description() {
		return __( 'Return the live conditional-display ruleset for Custom Layouts: the available condition roots (grouped, integration-aware) and their valid end values. Optionally omit enumerated end options for a lighter response. Use this before building conditions in custom-layout-upsert.', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_capability() {
		return 'edit_custom_layouts';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_annotations() {
		return array( 'readonly' => true );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_input_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'include_end_options' => array(
					'type'        => 'boolean',
					'description' => 'Include enumerated end_options for smaller rule sets. Clients that cannot call this ability with an empty object may send include_end_options=true.',
				),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'roots'      => array(
					'type'  => 'array',
					'items' => array(
						'type'       => 'object',
						'properties' => array(
							'root'        => array( 'type' => 'string' ),
							'label'       => array( 'type' => 'string' ),
							'group'       => array( 'type' => 'string' ),
							'multiselect' => array( 'type' => 'boolean' ),
							'end_source'  => array( 'type' => 'string' ),
							'end_options' => array( 'type' => 'array' ),
						),
					),
				),
				'conditions' => array(
					'type'  => 'array',
					'items' => array( 'type' => 'string' ),
				),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function run( array $input ) {
		if ( ! class_exists( '\Neve_Pro\Admin\Conditional_Display' ) ) {
			return $this->error( 'conditions_unavailable', __( 'Conditional display is not available.', 'neve-pro-addon' ), 501 );
		}

		$include_end_options = ! array_key_exists( 'include_end_options', $input ) || (bool) $input['include_end_options'];

		$cd          = new Conditional_Display();
		$root_groups = $cd->get_root_ruleset();
		$end_ruleset = $cd->get_end_ruleset();
		$ruleset_map = $cd->get_ruleset_map();

		// Invert the ruleset map: root => end-set key.
		$root_to_end = array();
		foreach ( $ruleset_map as $end_key => $roots ) {
			foreach ( $roots as $root ) {
				$root_to_end[ $root ] = $end_key;
			}
		}

		$multiselect = defined( '\Neve_Pro\Admin\Conditional_Display::MULTISELECT_RULES' ) ? Conditional_Display::MULTISELECT_RULES : array();

		$roots = array();
		foreach ( $root_groups as $group_label => $group ) {
			$label = isset( $group['label'] ) ? $group['label'] : $group_label;

			if ( empty( $group['choices'] ) || ! is_array( $group['choices'] ) ) {
				continue;
			}

			foreach ( $group['choices'] as $root => $root_label ) {
				$end_key = isset( $root_to_end[ $root ] ) ? $root_to_end[ $root ] : '';

				$entry = array(
					'root'        => $root,
					'label'       => $root_label,
					'group'       => $label,
					'multiselect' => in_array( $root, $multiselect, true ),
					'end_source'  => $end_key,
				);

				if ( $include_end_options && '' !== $end_key && ! in_array( $end_key, self::DYNAMIC_END_SETS, true ) && isset( $end_ruleset[ $end_key ] ) && is_array( $end_ruleset[ $end_key ] ) ) {
					$options = $end_ruleset[ $end_key ];
					if ( count( $options ) <= self::ENUM_CAP ) {
						$entry['end_options'] = $this->format_options( $options );
					}
				}

				$roots[] = $entry;
			}
		}

		return array(
			'roots'      => $roots,
			'conditions' => array( '===', '!==' ),
		);
	}

	/**
	 * Normalize a {value => label} map into a [{value,label}] list.
	 *
	 * @param array $options The options map.
	 * @return array
	 */
	private function format_options( array $options ) {
		$formatted = array();
		foreach ( $options as $value => $label ) {
			$formatted[] = array(
				'value' => (string) $value,
				'label' => is_string( $label ) ? $label : (string) $value,
			);
		}

		return $formatted;
	}
}
