<?php
/**
 * Ability: neve/custom-layout-set-status.
 *
 * Publish or unpublish a Custom Layout.
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */

namespace Neve_Pro\Modules\Abilities\Abilities;

/**
 * Class Custom_Layout_Set_Status
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */
class Custom_Layout_Set_Status extends Custom_Layout_Helpers {

	/**
	 * {@inheritDoc}
	 */
	protected function get_id() {
		return 'custom-layout-set-status';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_label() {
		return __( 'Set custom layout status', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_description() {
		return __( 'Publish or unpublish (draft) a Custom Layout.', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_capability() {
		return 'edit_custom_layouts';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_annotations() {
		return array( 'idempotent' => true );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_input_schema() {
		return array(
			'type'       => 'object',
			'required'   => array( 'id', 'status' ),
			'properties' => array(
				'id'     => array( 'type' => 'integer' ),
				'status' => array(
					'type' => 'string',
					'enum' => array( 'publish', 'draft' ),
				),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'id'     => array( 'type' => 'integer' ),
				'status' => array( 'type' => 'string' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function run( array $input ) {
		$id   = isset( $input['id'] ) ? (int) $input['id'] : 0;
		$post = get_post( $id );

		if ( ! $post || self::CPT !== $post->post_type ) {
			return $this->error( 'not_found', __( 'No custom layout with that id.', 'neve-pro-addon' ), 404 );
		}

		$result = wp_update_post(
			array(
				'ID'          => $id,
				'post_status' => 'publish' === $input['status'] ? 'publish' : 'draft',
			),
			true
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		delete_transient( 'custom_layouts_post_map_v3' );

		return array(
			'id'     => $id,
			'status' => get_post_status( $id ),
		);
	}
}
