<?php
/**
 * Ability: neve/custom-layout-list.
 *
 * List Custom Layouts as summaries (no bodies).
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */

namespace Neve_Pro\Modules\Abilities\Abilities;

/**
 * Class Custom_Layout_List
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */
class Custom_Layout_List extends Custom_Layout_Helpers {

	/**
	 * {@inheritDoc}
	 */
	protected function get_id() {
		return 'custom-layout-list';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_label() {
		return __( 'List custom layouts', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_description() {
		return __( 'List Custom Layouts with their type, location, conditions summary, priority and status. Returns summaries only (no bodies); use custom-layout-get for full detail.', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_capability() {
		return 'edit_custom_layouts';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_annotations() {
		return array( 'readonly' => true );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_input_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'type'   => array(
					'type'        => 'string',
					'enum'        => $this->layout_types(),
					'description' => 'Filter by layout type.',
				),
				'status' => array(
					'type'        => 'string',
					'enum'        => array( 'publish', 'draft', 'any' ),
					'default'     => 'any',
					'description' => 'Filter by status.',
				),
				'noop'   => array(
					'type'        => 'boolean',
					'description' => 'Optional compatibility flag; ignored. Clients that cannot call this ability with an empty object may send noop=true.',
				),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'layouts' => array(
					'type'  => 'array',
					'items' => array(
						'type'                 => 'object',
						'additionalProperties' => true,
					),
				),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function run( array $input ) {
		$args = array(
			'post_type'      => self::CPT,
			'post_status'    => isset( $input['status'] ) ? $input['status'] : 'any',
			'posts_per_page' => 100,
			'orderby'        => 'title',
			'order'          => 'ASC',
		);

		if ( isset( $input['type'] ) && '' !== $input['type'] ) {
			$args['meta_key']   = self::META_LAYOUT; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			$args['meta_value'] = $input['type']; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
		}

		$query   = new \WP_Query( $args );
		$layouts = array();

		foreach ( $query->posts as $post ) {
			$layouts[] = $this->summarize_layout( $post );
		}

		return array( 'layouts' => $layouts );
	}
}
