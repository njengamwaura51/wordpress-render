<?php
/**
 * Ability: neve/site-configure-menu.
 *
 * Create or assign a navigation menu to one of Neve's three registered
 * locations (primary, footer, top-bar).
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */

namespace Neve_Pro\Modules\Abilities\Abilities;

/**
 * Class Site_Configure_Menu
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */
class Site_Configure_Menu extends Abstract_Ability {

	/**
	 * Neve's registered menu locations.
	 */
	const LOCATIONS = array( 'primary', 'footer', 'top-bar' );

	/**
	 * {@inheritDoc}
	 */
	protected function get_id() {
		return 'site-configure-menu';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_label() {
		return __( 'Configure navigation menu', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_description() {
		return __( 'Assign an existing menu, create and assign a new menu with items, or unassign a Neve menu location (primary, footer, top-bar). Use site-delete-menu to permanently remove a menu.', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_annotations() {
		return array(
			'readonly'    => false,
			'destructive' => false,
			'idempotent'  => true,
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_input_schema() {
		return array(
			'type'       => 'object',
			'required'   => array( 'location' ),
			'properties' => array(
				'location' => array(
					'type'        => 'string',
					'enum'        => self::LOCATIONS,
					'description' => 'The menu location to assign.',
				),
				'unassign' => array(
					'type'        => 'boolean',
					'description' => 'Unassign any menu currently attached to this location.',
					'default'     => false,
				),
				'menu_id'  => array(
					'type'        => 'integer',
					'description' => 'Assign this existing menu to the location.',
				),
				'create'   => array(
					'type'        => 'object',
					'description' => 'Create a new menu and assign it.',
					'required'    => array( 'name' ),
					'properties'  => array(
						'name'  => array( 'type' => 'string' ),
						'items' => array(
							'type'  => 'array',
							'items' => array(
								'type'       => 'object',
								'required'   => array( 'type' ),
								'properties' => array(
									'type'      => array(
										'type' => 'string',
										'enum' => array( 'page', 'post', 'custom', 'category' ),
									),
									'object_id' => array( 'type' => 'integer' ),
									'url'       => array( 'type' => 'string' ),
									'label'     => array( 'type' => 'string' ),
								),
							),
						),
					),
				),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'success'     => array( 'type' => 'boolean' ),
				'error'       => array(
					'type'       => 'object',
					'properties' => array(
						'code'    => array( 'type' => 'string' ),
						'message' => array( 'type' => 'string' ),
						'field'   => array( 'type' => 'string' ),
					),
				),
				'location'    => array( 'type' => 'string' ),
				'menu_id'     => array( 'type' => 'integer' ),
				'items_count' => array( 'type' => 'integer' ),
				'unassigned'  => array( 'type' => 'boolean' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function run( array $input ) {
		$location = isset( $input['location'] ) ? $input['location'] : '';
		if ( ! in_array( $location, self::LOCATIONS, true ) ) {
			return $this->validation_issue( 'invalid_location', __( 'Unknown menu location.', 'neve-pro-addon' ), 'location' );
		}

		$locations = get_theme_mod( 'nav_menu_locations', array() );
		$locations = is_array( $locations ) ? $locations : array();

		if ( ! empty( $input['unassign'] ) ) {
			unset( $locations[ $location ] );
			set_theme_mod( 'nav_menu_locations', $locations );

			return array(
				'success'     => true,
				'location'    => $location,
				'menu_id'     => 0,
				'items_count' => 0,
				'unassigned'  => true,
			);
		}

		$menu_id = 0;

		if ( isset( $input['create'] ) && is_array( $input['create'] ) ) {
			$menu_id = $this->create_menu( $input['create'] );
			if ( is_wp_error( $menu_id ) ) {
				return $menu_id;
			}
		} elseif ( isset( $input['menu_id'] ) ) {
			$menu_id = (int) $input['menu_id'];
			if ( ! is_nav_menu( $menu_id ) ) {
				return $this->validation_issue( 'unknown_menu', __( 'No menu with that id exists.', 'neve-pro-addon' ), 'menu_id' );
			}
		} else {
			return $this->validation_issue( 'missing_menu', __( 'Provide either menu_id, create, or unassign=true.', 'neve-pro-addon' ) );
		}

		$locations[ $location ] = $menu_id;
		set_theme_mod( 'nav_menu_locations', $locations );

		$items = wp_get_nav_menu_items( $menu_id );

		return array(
			'success'     => true,
			'location'    => $location,
			'menu_id'     => $menu_id,
			'items_count' => is_array( $items ) ? count( $items ) : 0,
			'unassigned'  => false,
		);
	}

	/**
	 * Create a menu and append its items.
	 *
	 * @param array $create The create block.
	 * @return int|\WP_Error The new menu id.
	 */
	private function create_menu( array $create ) {
		if ( empty( $create['name'] ) ) {
			return $this->error( 'missing_name', __( 'A menu name is required.', 'neve-pro-addon' ) );
		}

		$menu_id = wp_create_nav_menu( sanitize_text_field( $create['name'] ) );
		if ( is_wp_error( $menu_id ) ) {
			return $menu_id;
		}

		if ( ! empty( $create['items'] ) && is_array( $create['items'] ) ) {
			foreach ( $create['items'] as $item ) {
				$this->add_menu_item( $menu_id, $item );
			}
		}

		return (int) $menu_id;
	}

	/**
	 * Append a single item to a menu.
	 *
	 * @param int   $menu_id The menu id.
	 * @param array $item    The item descriptor.
	 * @return void
	 */
	private function add_menu_item( $menu_id, array $item ) {
		$type = isset( $item['type'] ) ? $item['type'] : 'custom';
		$args = array(
			'menu-item-status' => 'publish',
			'menu-item-title'  => isset( $item['label'] ) ? sanitize_text_field( $item['label'] ) : '',
		);

		switch ( $type ) {
			case 'page':
			case 'post':
				if ( empty( $item['object_id'] ) ) {
					return;
				}
				$args['menu-item-type']      = 'post_type';
				$args['menu-item-object']    = 'page' === $type ? 'page' : 'post';
				$args['menu-item-object-id'] = (int) $item['object_id'];
				break;
			case 'category':
				if ( empty( $item['object_id'] ) ) {
					return;
				}
				$args['menu-item-type']      = 'taxonomy';
				$args['menu-item-object']    = 'category';
				$args['menu-item-object-id'] = (int) $item['object_id'];
				break;
			default:
				if ( empty( $item['url'] ) ) {
					return;
				}
				$args['menu-item-type'] = 'custom';
				$args['menu-item-url']  = esc_url_raw( $item['url'] );
				break;
		}

		wp_update_nav_menu_item( $menu_id, 0, $args );
	}
}
