<?php
/**
 * Ability: neve/starter-site-list.
 *
 * List the available Neve starter sites.
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */

namespace Neve_Pro\Modules\Abilities\Abilities;

/**
 * Class Starter_Site_List
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */
class Starter_Site_List extends Starter_Site_Helpers {

	/**
	 * {@inheritDoc}
	 */
	protected function get_id() {
		return 'starter-site-list';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_label() {
		return __( 'List starter sites', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_description() {
		return __( 'List the available Neve starter sites (demo templates) with their slug, builder, required plugins and preview. Optionally filter by search query or builder.', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_capability() {
		return 'manage_options';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_annotations() {
		return array( 'readonly' => true );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_input_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'query'   => array(
					'type'        => 'string',
					'description' => 'Filter by title/slug substring.',
				),
				'builder' => array(
					'type'        => 'string',
					'enum'        => array( 'gutenberg', 'elementor', 'beaver', 'brizy' ),
					'description' => 'Filter by page builder.',
				),
				'noop'    => array(
					'type'        => 'boolean',
					'description' => 'Optional compatibility flag; ignored. Clients that cannot call this ability with an empty object may send noop=true.',
				),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'sites' => array(
					'type'  => 'array',
					'items' => array(
						'type'                 => 'object',
						'additionalProperties' => true,
					),
				),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function run( array $input ) {
		if ( ! $this->tpc_available() ) {
			return $this->error( 'tpc_unavailable', __( 'The starter sites library is not available.', 'neve-pro-addon' ), 501 );
		}

		$query   = isset( $input['query'] ) ? strtolower( $input['query'] ) : '';
		$builder = isset( $input['builder'] ) ? $input['builder'] : '';
		$sites   = array();

		foreach ( $this->get_sites() as $builder_key => $builder_sites ) {
			if ( '' !== $builder && $builder !== $builder_key ) {
				continue;
			}

			foreach ( $builder_sites as $slug => $data ) {
				$title = isset( $data['title'] ) ? $data['title'] : $slug;

				if ( '' !== $query && false === strpos( strtolower( $title . ' ' . $slug ), $query ) ) {
					continue;
				}

				$required = array();
				if ( isset( $data['mandatory_plugins'] ) && is_array( $data['mandatory_plugins'] ) ) {
					$required = array_keys( $data['mandatory_plugins'] );
				}

				$sites[] = array(
					'slug'             => $slug,
					'title'            => $title,
					'builder'          => $builder_key,
					'required_plugins' => $required,
					'preview_url'      => isset( $data['screenshot'] ) ? $data['screenshot'] : '',
					'license_tier'     => ( isset( $data['upsell'] ) && true === $data['upsell'] ) ? 'pro' : 'free',
				);
			}
		}

		return array( 'sites' => $sites );
	}
}
