<?php
/**
 * Neve Pro extensions for the abilities registered by the Neve theme.
 *
 * When the theme owns the shared `neve/*` abilities, Neve Pro no longer
 * registers its own copies. Instead it plugs the Pro-only fields, settings and
 * state sections into the theme's abilities through filters.
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */

namespace Neve_Pro\Modules\Abilities\Abilities;

use Neve_Pro\Traits\Core;
use WP_Error;

/**
 * Class Free_Extensions
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */
class Free_Extensions {
	use Core;
	use Helpers;

	/**
	 * Performance toggles owned by the Pro performance module.
	 */
	const PERFORMANCE_OPTIONS = array(
		'remove_emoji'       => 'nv_pro_enable_emoji_removal',
		'remove_oembed'      => 'nv_pro_enable_embedded_removal',
		'content_visibility' => 'nv_pro_enable_lazy_content',
	);

	/**
	 * Gate messages per module slug, resolved once per request.
	 *
	 * @var array<string,string>
	 */
	private $gate_messages = array();

	/**
	 * Hook into the theme abilities.
	 *
	 * @return void
	 */
	public function init() {
		add_filter( 'neve_ability_pro_field', array( $this, 'handle_pro_field' ), 10, 5 );
		add_filter( 'neve_ability_site_state_section', array( $this, 'extend_site_state' ), 10, 2 );
		add_filter( 'neve_ability_display_fields', array( $this, 'add_display_fields' ), 10, 2 );
		add_filter( 'neve_abilities_theme_mod_allowlist', array( $this, 'bridge_theme_mod_allowlist' ) );
	}

	/**
	 * Validate or apply a Pro-only field of a theme ability.
	 *
	 * @param null|array|WP_Error $result  Previous result.
	 * @param string              $ability Ability slug.
	 * @param string              $field   Input field name.
	 * @param mixed               $value   Field value.
	 * @param bool                $dry_run Only validate when true.
	 * @return null|array|WP_Error Affected setting keys, an error, or null when not handled here.
	 */
	public function handle_pro_field( $result, $ability, $field, $value, $dry_run ) {
		if ( null !== $result ) {
			return $result;
		}

		$key = $ability . ':' . $field;

		if ( ! in_array( $key, array( 'header-configure:sticky', 'header-configure:transparent', 'footer-configure:copyright', 'site-set-performance:remove_emoji', 'site-set-performance:remove_oembed', 'site-set-performance:content_visibility' ), true ) ) {
			return $result;
		}

		$module_name = 'site-set-performance' === $ability ? __( 'Performance', 'neve-pro-addon' ) : __( 'Header Booster', 'neve-pro-addon' );

		if ( $this->get_license_type() < 1 ) {
			return new WP_Error(
				'neve_ability_license_required',
				$this->get_license_message( $module_name ),
				array(
					'status' => 403,
					'field'  => $field,
				)
			);
		}

		if ( 'site-set-performance' === $ability ) {
			$option = self::PERFORMANCE_OPTIONS[ $field ];
			if ( ! $dry_run ) {
				update_option( $option, (bool) $value );
			}

			return array( $option );
		}

		$module = $this->get_pro_module( 'hfg_module' );
		if ( null === $module || ! $module['enabled'] ) {
			return new WP_Error(
				'neve_ability_module_disabled',
				$this->get_module_disabled_message( $module_name ),
				array(
					'status' => 403,
					'field'  => $field,
				)
			);
		}

		if ( 'sticky' === $field ) {
			if ( ! $dry_run ) {
				set_theme_mod(
					'hfg_header_layout_main_sticky_responsive',
					array(
						'mobile'  => (bool) $value,
						'desktop' => (bool) $value,
					)
				);
			}

			return array( 'hfg_header_layout_main_sticky_responsive' );
		}

		if ( 'transparent' === $field ) {
			if ( ! $dry_run ) {
				set_theme_mod( 'neve_transparent_header', (bool) $value );
			}

			return array( 'neve_transparent_header' );
		}

		if ( ! $dry_run ) {
			set_theme_mod( 'footer_copyright_content', wp_kses_post( (string) $value ) );
		}

		return array( 'footer_copyright_content' );
	}

	/**
	 * Add the Pro state to neve/site-get-state.
	 *
	 * @param mixed  $data    Section data.
	 * @param string $section Section name.
	 * @return array
	 */
	public function extend_site_state( $data, $section ) {
		$data = is_array( $data ) ? $data : array();

		if ( 'modules' === $section ) {
			foreach ( $this->get_pro_modules() as $module ) {
				$data[ $module['slug'] ] = $module['enabled'];
			}
		}

		if ( 'license' === $section ) {
			$tier = $this->get_license_type();
			$data = array(
				'tier'  => $tier,
				'valid' => $tier > 0,
			);
		}

		if ( 'performance' === $section ) {
			foreach ( self::PERFORMANCE_OPTIONS as $key => $option ) {
				$data[ $key ] = (bool) get_option( $option, false );
			}
		}

		return $data;
	}

	/**
	 * Add the Pro display settings to neve/appearance-update.
	 *
	 * @param mixed  $fields Field definitions.
	 * @param string $group  Group name: blog, single or shop.
	 * @return array
	 */
	public function add_display_fields( $fields, $group ) {
		$fields = is_array( $fields ) ? $fields : array();

		if ( 'blog' === $group ) {
			$pro_fields = array(
				'pagination_type'     => array(
					'mod'     => 'neve_pagination_type',
					'type'    => 'enum',
					'choices' => array( 'number', 'infinite', 'jump-to' ),
					'default' => 'number',
				),
				'posts_order'         => array(
					'mod'     => 'neve_posts_order',
					'type'    => 'enum',
					'choices' => array( 'date_posted_asc', 'date_posted_desc', 'date_updated' ),
					'default' => 'date_posted_desc',
				),
				'read_more_style'     => array(
					'mod'     => 'neve_read_more_style',
					'type'    => 'enum',
					'choices' => array( 'text', 'primary_button', 'secondary_button' ),
				),
				'read_more_text'      => array(
					'mod'  => 'neve_read_more_text',
					'type' => 'string',
				),
				'list_image_position' => array(
					'mod'         => 'neve_blog_list_image_position',
					'type'        => 'enum',
					'choices'     => array( 'left', 'no', 'right' ),
					'description' => 'Image position for the list layout.',
				),
				'content_alignment'   => array(
					'mod'     => 'neve_blog_content_alignment',
					'type'    => 'enum',
					'choices' => array( 'left', 'center', 'right' ),
				),
			);

			return array_merge( $fields, $this->gate_fields( $pro_fields, 'blog_pro', __( 'Blog Booster', 'neve-pro-addon' ) ) );
		}

		if ( 'shop' === $group ) {
			$pro_fields = array(
				'product_card_layout' => array(
					'mod'     => 'neve_product_card_layout',
					'type'    => 'enum',
					'choices' => array( 'list', 'grid' ),
					'default' => 'grid',
				),
				'products_per_page'   => array(
					'mod'  => 'neve_products_per_page',
					'type' => 'int',
					'min'  => 1,
					'max'  => 500,
				),
				'pagination_type'     => array(
					'mod'     => 'neve_shop_pagination_type',
					'type'    => 'enum',
					'choices' => array( 'number', 'infinite' ),
					'default' => 'number',
				),
				'product_filter'      => array(
					'mod'     => 'neve_enable_product_filter',
					'type'    => 'bool',
					'default' => true,
				),
				'layout_toggle'       => array(
					'mod'     => 'neve_enable_product_layout_toggle',
					'type'    => 'bool',
					'default' => false,
				),
				'add_to_cart_display' => array(
					'mod'     => 'neve_add_to_cart_display',
					'type'    => 'enum',
					'choices' => array( 'none', 'after', 'on_image' ),
					'default' => 'none',
				),
			);

			return array_merge( $fields, $this->gate_fields( $pro_fields, 'woocommerce_booster', __( 'WooCommerce Booster', 'neve-pro-addon' ) ) );
		}

		return $fields;
	}

	/**
	 * Mark fields unavailable when the license or their module does not allow them.
	 *
	 * @param array  $fields      Field definitions.
	 * @param string $module_slug Owning Pro module slug.
	 * @param string $module_name Owning Pro module label.
	 * @return array
	 */
	private function gate_fields( array $fields, $module_slug, $module_name ) {
		// Modules finish setting up on init; before that only the schema is built,
		// which does not depend on availability.
		if ( ! did_action( 'init' ) ) {
			return $fields;
		}

		if ( ! isset( $this->gate_messages[ $module_slug ] ) ) {
			$this->gate_messages[ $module_slug ] = $this->get_gate_message( $module_slug, $module_name );
		}

		$message = $this->gate_messages[ $module_slug ];

		if ( '' === $message ) {
			return $fields;
		}

		foreach ( $fields as $name => $field ) {
			$fields[ $name ]['unavailable'] = $message;
		}

		return $fields;
	}

	/**
	 * Why a module's settings cannot be changed, or an empty string when they can.
	 *
	 * @param string $module_slug Owning Pro module slug.
	 * @param string $module_name Owning Pro module label.
	 * @return string
	 */
	private function get_gate_message( $module_slug, $module_name ) {
		$module  = $this->get_pro_module( $module_slug );
		$message = '';

		if ( null === $module || ! $module['enabled'] ) {
			$message = $this->get_module_disabled_message( $module_name );
		} elseif ( $this->get_license_type() < $module['license_tier'] ) {
			$message = $this->get_license_message( $module_name );
		}

		return $message;
	}

	/**
	 * Message for a setting whose Pro module is not enabled.
	 *
	 * @param string $module_name Owning Pro module label.
	 * @return string
	 */
	private function get_module_disabled_message( $module_name ) {
		return sprintf(
			/* translators: %s: module name */
			__( 'This setting requires the %s module to be enabled.', 'neve-pro-addon' ),
			$module_name
		);
	}

	/**
	 * Message for a setting whose Pro module is not covered by the license.
	 *
	 * @param string $module_name Owning Pro module label.
	 * @return string
	 */
	private function get_license_message( $module_name ) {
		return sprintf(
			/* translators: %s: module name */
			__( 'This setting requires a Neve Pro license that includes the %s module.', 'neve-pro-addon' ),
			$module_name
		);
	}

	/**
	 * Keep the previous allowlist filter working now that the theme owns
	 * neve/site-set-theme-mod.
	 *
	 * @param string[] $allowlist Theme mod keys.
	 * @return string[]
	 */
	public function bridge_theme_mod_allowlist( $allowlist ) {
		$filtered = apply_filters( 'neve_pro_abilities_theme_mod_allowlist', $allowlist );

		return is_array( $filtered ) ? $filtered : $allowlist;
	}
}
