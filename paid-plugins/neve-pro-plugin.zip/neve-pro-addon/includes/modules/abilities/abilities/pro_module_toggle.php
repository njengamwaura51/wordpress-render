<?php
/**
 * Ability: neve/pro-module-toggle.
 *
 * Enable or disable a Neve Pro module (prerequisite for layouts / Pro builder
 * components). Uses the live module registry, so slug↔folder mismatches
 * (header_footer_grid → hfg_module, performance → performance_features) are
 * handled by referring to the canonical slug.
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */

namespace Neve_Pro\Modules\Abilities\Abilities;

/**
 * Class Pro_Module_Toggle
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */
class Pro_Module_Toggle extends Abstract_Ability {
	use Helpers;

	/**
	 * {@inheritDoc}
	 */
	protected function get_id() {
		return 'pro-module-toggle';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_label() {
		return __( 'Enable or disable a Pro module', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_description() {
		return __( 'Enable or disable a Neve Pro module by its slug (see pro-module-list). Some features require their module to be enabled first.', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_capability() {
		return 'manage_options';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_annotations() {
		return array( 'idempotent' => true );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_input_schema() {
		$slugs = wp_list_pluck( $this->get_pro_modules(), 'slug' );

		return array(
			'type'       => 'object',
			'required'   => array( 'action', 'module' ),
			'properties' => array(
				'action' => array(
					'type'        => 'string',
					'enum'        => array( 'enable', 'disable' ),
					'description' => 'Whether to enable or disable the module.',
				),
				'module' => array(
					'type'        => 'string',
					'enum'        => ! empty( $slugs ) ? array_values( $slugs ) : array( '' ),
					'description' => 'The module slug.',
				),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'module'  => array( 'type' => 'string' ),
				'enabled' => array( 'type' => 'boolean' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function run( array $input ) {
		$slug   = isset( $input['module'] ) ? $input['module'] : '';
		$enable = isset( $input['action'] ) && 'enable' === $input['action'];

		$module = $this->get_pro_module( $slug );

		if ( null === $module ) {
			return $this->error( 'unknown_module', __( 'Unknown module slug.', 'neve-pro-addon' ) );
		}

		if ( ! empty( $module['force_enabled'] ) ) {
			return $this->error( 'force_enabled', __( 'This module is always enabled and cannot be toggled.', 'neve-pro-addon' ) );
		}

		if ( $enable && ! $this->has_license_tier( $module['license_tier'] ) ) {
			return $this->error( 'license_required', __( 'Your license tier does not include this module.', 'neve-pro-addon' ), 403 );
		}

		update_option( $module['status_key'], $enable );

		return array(
			'module'  => $slug,
			'enabled' => $enable,
		);
	}
}
