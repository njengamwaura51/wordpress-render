<?php
/**
 * Ability: neve/custom-layout-delete.
 *
 * Delete a Custom Layout permanently.
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */

namespace Neve_Pro\Modules\Abilities\Abilities;

/**
 * Class Custom_Layout_Delete
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */
class Custom_Layout_Delete extends Custom_Layout_Helpers {

	/**
	 * {@inheritDoc}
	 */
	protected function get_id() {
		return 'custom-layout-delete';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_label() {
		return __( 'Delete custom layout', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_description() {
		return __( 'Permanently delete a Custom Layout. Set confirm=true to proceed.', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_capability() {
		return 'delete_custom_layouts';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_annotations() {
		return array( 'destructive' => true );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_input_schema() {
		return array(
			'type'       => 'object',
			'required'   => array( 'id' ),
			'properties' => array(
				'id'      => array(
					'type'        => 'integer',
					'description' => 'The layout post id.',
				),
				'confirm' => array(
					'type'        => 'boolean',
					'description' => 'Must be true to delete the layout.',
					'default'     => false,
				),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'success' => array( 'type' => 'boolean' ),
				'error'   => array(
					'type'       => 'object',
					'properties' => array(
						'code'    => array( 'type' => 'string' ),
						'message' => array( 'type' => 'string' ),
						'field'   => array( 'type' => 'string' ),
					),
				),
				'id'      => array( 'type' => 'integer' ),
				'deleted' => array( 'type' => 'boolean' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function run( array $input ) {
		$id   = isset( $input['id'] ) ? (int) $input['id'] : 0;
		$post = get_post( $id );

		if ( ! $post || self::CPT !== $post->post_type ) {
			return $this->validation_issue( 'not_found', __( 'No custom layout with that id.', 'neve-pro-addon' ), 'id' );
		}

		if ( empty( $input['confirm'] ) ) {
			return $this->validation_issue( 'confirm_required', __( 'Set confirm=true to permanently delete this custom layout.', 'neve-pro-addon' ), 'confirm' );
		}

		$deleted = wp_delete_post( $id, true );
		if ( ! $deleted ) {
			return $this->error( 'delete_failed', __( 'The custom layout could not be deleted.', 'neve-pro-addon' ), 500 );
		}

		delete_transient( 'custom_layouts_post_map_v3' );

		return array(
			'success' => true,
			'id'      => $id,
			'deleted' => true,
		);
	}
}
