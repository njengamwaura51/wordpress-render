<?php
/**
 * Shared runtime helpers for Neve abilities.
 *
 * Integration detection and Pro module enumeration, used by the grounding
 * reads and the module list/toggle abilities.
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */

namespace Neve_Pro\Modules\Abilities\Abilities;

use Neve_Pro\Core\Loader;

/**
 * Trait Helpers
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */
trait Helpers {

	/**
	 * Detect active integrations Neve cares about.
	 *
	 * @return array<string,bool>
	 */
	protected function get_integrations() {
		return array(
			'woocommerce' => class_exists( 'WooCommerce', false ),
			'sparks'      => defined( 'SPARKS_WC_VERSION' ) || function_exists( 'sparks' ),
			'edd'         => class_exists( 'Easy_Digital_Downloads', false ),
			'lifterlms'   => class_exists( 'LifterLMS', false ),
			'learndash'   => defined( 'LEARNDASH_VERSION' ),
			'elementor'   => defined( 'ELEMENTOR_VERSION' ),
			'seo'         => defined( 'WPSEO_VERSION' ) || class_exists( 'WPSEO_Options' ) || defined( 'RANK_MATH_VERSION' ),
		);
	}

	/**
	 * Enumerate the registered pluggable Pro modules with their live state.
	 *
	 * @return array<int,array{slug:string,label:string,enabled:bool,license_tier:int,force_enabled:bool,status_key:string}>
	 */
	protected function get_pro_modules() {
		$modules = array();

		if ( ! class_exists( '\Neve_Pro\Core\Loader' ) ) {
			return $modules;
		}

		foreach ( Loader::instance()->get_modules() as $module ) {
			if ( ! isset( $module->slug ) ) {
				continue;
			}

			$info          = $module->get_module_info();
			$module_info   = isset( $info[ $module->slug ] ) ? $info[ $module->slug ] : array();
			$force_enabled = ! empty( $module_info['hide'] );

			$modules[] = array(
				'slug'          => $module->slug,
				'label'         => isset( $module->name ) ? $module->name : $module->slug,
				'enabled'       => $force_enabled || (bool) get_option( $module->status_key, $module->get_default_module_status() ),
				'license_tier'  => isset( $module->min_req_license ) ? (int) $module->min_req_license : 1,
				'force_enabled' => $force_enabled,
				'status_key'    => $module->status_key,
			);
		}

		return $modules;
	}

	/**
	 * Look up a single Pro module descriptor by slug.
	 *
	 * @param string $slug Module slug (e.g. "hfg_module", "performance_features").
	 * @return array|null
	 */
	protected function get_pro_module( $slug ) {
		foreach ( $this->get_pro_modules() as $module ) {
			if ( $module['slug'] === $slug ) {
				return $module;
			}
		}

		return null;
	}
}
