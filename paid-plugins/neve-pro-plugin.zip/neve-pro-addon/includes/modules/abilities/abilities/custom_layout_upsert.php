<?php
/**
 * Ability: neve/custom-layout-upsert.
 *
 * Create or update a Custom Layout. The PHP/code-editor path is intentionally
 * read-only here: this only writes block/HTML content, never arbitrary code.
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */

namespace Neve_Pro\Modules\Abilities\Abilities;

/**
 * Class Custom_Layout_Upsert
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */
class Custom_Layout_Upsert extends Custom_Layout_Helpers {

	/**
	 * {@inheritDoc}
	 */
	protected function get_id() {
		return 'custom-layout-upsert';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_label() {
		return __( 'Create or update a custom layout', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_description() {
		return __( 'Create a new Custom Layout or update an existing one (pass id to update): set its type, hook, priority, content, conditions, expiration, sidebar replacement and status. Build conditions using custom-layout-get-condition-schema.', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_capability() {
		return 'edit_custom_layouts';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_annotations() {
		return array(
			'readonly'    => false,
			'destructive' => false,
			'idempotent'  => false,
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_input_schema() {
		return array(
			'type'       => 'object',
			'required'   => array( 'title', 'type' ),
			'properties' => array(
				'id'         => array(
					'type'        => 'integer',
					'minimum'     => 1,
					'description' => 'Existing layout id (omit to create).',
				),
				'title'      => array( 'type' => 'string' ),
				'type'       => array(
					'type' => 'string',
					'enum' => $this->layout_types(),
				),
				'hook'       => array(
					'type'        => 'string',
					'description' => 'Theme hook name (for type "hooks").',
				),
				'inside'     => array(
					'type'        => 'object',
					'description' => 'Placement for type "inside": insert the content after the Nth heading or block of the post.',
					'properties'  => array(
						'position' => array(
							'type' => 'string',
							'enum' => array( 'after_x_headings', 'after_x_blocks' ),
						),
						'after'    => array(
							'type'        => 'integer',
							'minimum'     => 1,
							'description' => 'Insert after this many headings/blocks.',
						),
					),
				),
				'priority'   => array(
					'type'    => 'integer',
					'default' => 10,
					'minimum' => 1,
					'maximum' => 150,
				),
				'content'    => array(
					'type'        => 'string',
					'description' => 'Block/HTML body.',
				),
				'status'     => array(
					'type'    => 'string',
					'enum'    => array( 'publish', 'draft' ),
					'default' => 'publish',
				),
				'expiration' => array(
					'type'       => 'object',
					'properties' => array(
						'enabled' => array( 'type' => 'boolean' ),
						'date'    => array(
							'type'        => 'string',
							'description' => 'Format: Y-m-dTH:i',
						),
					),
				),
				'sidebar'    => array(
					'type'       => 'object',
					'properties' => array(
						'id'     => array( 'type' => 'string' ),
						'action' => array(
							'type' => 'string',
							'enum' => array( 'replace', 'append', 'prepend' ),
						),
					),
				),
				'conditions' => array(
					'type'        => 'object',
					'description' => 'Conditional display. groups is an array of AND-groups; groups are OR-ed.',
					'properties'  => array(
						'groups' => array(
							'type'  => 'array',
							'items' => array(
								'type'  => 'array',
								'items' => array(
									'type'       => 'object',
									'required'   => array( 'root', 'condition' ),
									'properties' => array(
										'root'      => array( 'type' => 'string' ),
										'end'       => array( 'description' => 'String or array of strings.' ),
										'condition' => array(
											'type' => 'string',
											'enum' => array( '===', '!==' ),
										),
									),
								),
							),
						),
					),
				),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'success'            => array( 'type' => 'boolean' ),
				'error'              => array(
					'type'       => 'object',
					'properties' => array(
						'code'    => array( 'type' => 'string' ),
						'message' => array( 'type' => 'string' ),
						'field'   => array( 'type' => 'string' ),
					),
				),
				'id'                 => array( 'type' => 'integer' ),
				'edit_url'           => array( 'type' => 'string' ),
				'type'               => array( 'type' => 'string' ),
				'conditions_summary' => array( 'type' => 'string' ),
				'status'             => array( 'type' => 'string' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function run( array $input ) {
		if ( 'hooks' === $input['type'] && empty( $input['hook'] ) ) {
			return $this->validation_issue( 'missing_hook', __( 'A hook is required when creating or updating a hooks layout.', 'neve-pro-addon' ), 'hook' );
		}

		if ( 'inside' === $input['type'] ) {
			if ( empty( $input['inside'] ) || ! is_array( $input['inside'] ) ) {
				return $this->validation_issue( 'missing_inside', __( 'inside is required when creating or updating an inside layout.', 'neve-pro-addon' ), 'inside' );
			}

			if ( empty( $input['inside']['position'] ) || ! isset( $input['inside']['after'] ) ) {
				return $this->validation_issue( 'incomplete_inside', __( 'inside.position and inside.after are required when creating or updating an inside layout.', 'neve-pro-addon' ), 'inside.after' );
			}
		}

		$status  = isset( $input['status'] ) ? $input['status'] : 'publish';
		$postarr = array(
			'post_type'    => self::CPT,
			'post_title'   => sanitize_text_field( $input['title'] ),
			'post_status'  => $status,
			'post_content' => isset( $input['content'] ) ? $input['content'] : '',
		);

		if ( array_key_exists( 'id', $input ) ) {
			$id = (int) $input['id'];
			if ( $id < 1 ) {
				return $this->validation_issue( 'invalid_id', __( 'id must be a positive integer; omit it to create a new layout.', 'neve-pro-addon' ), 'id' );
			}
			$existing = get_post( $id );
			if ( ! $existing || self::CPT !== $existing->post_type ) {
				return $this->validation_issue( 'not_found', __( 'No custom layout with that id.', 'neve-pro-addon' ), 'id' );
			}
			$postarr['ID'] = $id;
			if ( ! isset( $input['content'] ) ) {
				unset( $postarr['post_content'] );
			}
			$post_id = wp_update_post( $postarr, true );
		} else {
			$post_id = wp_insert_post( $postarr, true );
		}

		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}

		update_post_meta( $post_id, self::META_LAYOUT, sanitize_text_field( $input['type'] ) );
		update_post_meta( $post_id, self::META_PRIORITY, isset( $input['priority'] ) ? (int) $input['priority'] : 10 );

		if ( isset( $input['hook'] ) ) {
			update_post_meta( $post_id, self::META_HOOK, sanitize_text_field( $input['hook'] ) );
		}

		if ( 'inside' === $input['type'] ) {
			// An "inside" layout needs a display position + count to render.
			$position = $input['inside']['position'];
			$after    = max( 1, (int) $input['inside']['after'] );
			update_post_meta( $post_id, self::META_INSIDE, sanitize_text_field( $position ) );
			update_post_meta( $post_id, self::META_EVENTS_NO, $after );
		}

		if ( isset( $input['conditions']['groups'] ) && is_array( $input['conditions']['groups'] ) ) {
			update_post_meta( $post_id, self::META_CONDITIONAL, wp_json_encode( $this->sanitize_groups( $input['conditions']['groups'] ) ) );
		}

		if ( isset( $input['expiration'] ) && is_array( $input['expiration'] ) ) {
			update_post_meta( $post_id, self::META_HAS_EXPIRATION, ! empty( $input['expiration']['enabled'] ) );
			if ( isset( $input['expiration']['date'] ) ) {
				update_post_meta( $post_id, self::META_EXPIRATION, sanitize_text_field( $input['expiration']['date'] ) );
			}
		}

		if ( isset( $input['sidebar']['id'] ) ) {
			update_post_meta( $post_id, self::META_SIDEBAR, sanitize_text_field( $input['sidebar']['id'] ) );
			if ( isset( $input['sidebar']['action'] ) ) {
				update_post_meta( $post_id, self::META_SIDEBAR_ACTION, sanitize_text_field( $input['sidebar']['action'] ) );
			}
		}

		delete_transient( 'custom_layouts_post_map_v3' );

		return array(
			'success'            => true,
			'id'                 => (int) $post_id,
			'edit_url'           => $this->edit_url( $post_id ),
			'type'               => $input['type'],
			'conditions_summary' => $this->conditions_summary( get_post_meta( $post_id, self::META_CONDITIONAL, true ) ),
			'status'             => get_post_status( $post_id ),
		);
	}

	/**
	 * Sanitize incoming condition groups to {root, condition, end}.
	 *
	 * @param array $groups The input groups.
	 * @return array
	 */
	private function sanitize_groups( array $groups ) {
		$clean = array();
		foreach ( $groups as $group ) {
			if ( ! is_array( $group ) ) {
				continue;
			}
			$rules = array();
			foreach ( $group as $rule ) {
				if ( ! isset( $rule['root'] ) ) {
					continue;
				}
				$end     = isset( $rule['end'] ) ? $rule['end'] : '';
				$rules[] = array(
					'root'      => sanitize_text_field( $rule['root'] ),
					'condition' => ( isset( $rule['condition'] ) && '!==' === $rule['condition'] ) ? '!==' : '===',
					'end'       => is_array( $end ) ? array_map( 'sanitize_text_field', $end ) : sanitize_text_field( $end ),
				);
			}
			if ( ! empty( $rules ) ) {
				$clean[] = $rules;
			}
		}

		return $clean;
	}
}
