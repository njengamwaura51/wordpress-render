<?php
/**
 * Ability: neve/starter-site-import.
 *
 * Slug-driven one-shot orchestration of a starter-site import (mirrors the
 * WP-CLI `themeisle-si import <slug>` flow). Reuses TPC's own REST handlers for
 * each step rather than reimplementing the importer.
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */

namespace Neve_Pro\Modules\Abilities\Abilities;

/**
 * Class Starter_Site_Import
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */
class Starter_Site_Import extends Starter_Site_Helpers {

	/**
	 * {@inheritDoc}
	 */
	protected function get_id() {
		return 'starter-site-import';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_label() {
		return __( 'Import a starter site', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_description() {
		return __( 'Import a Neve starter site by slug: installs required plugins, imports content, theme settings and widgets. This replaces significant parts of the site. Set confirm=true to proceed, or dry_run=true to inspect the import plan first.', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_capability() {
		return 'manage_options';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_annotations() {
		return array( 'destructive' => true );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_input_schema() {
		return array(
			'type'       => 'object',
			'required'   => array( 'slug' ),
			'properties' => array(
				'slug'         => array(
					'type'        => 'string',
					'description' => 'The starter site slug (see starter-site-list).',
				),
				'builder'      => array(
					'type'        => 'string',
					'enum'        => array( 'gutenberg', 'elementor', 'beaver', 'brizy' ),
					'description' => 'Constrain to a builder when slugs collide.',
				),
				'with_plugins' => array(
					'type'        => 'boolean',
					'default'     => true,
					'description' => 'Install the site\'s required/recommended plugins.',
				),
				'confirm'      => array(
					'type'        => 'boolean',
					'description' => 'Must be true to run the import.',
					'default'     => false,
				),
				'dry_run'      => array(
					'type'        => 'boolean',
					'description' => 'Return the resolved site and import plan without changing the site.',
					'default'     => false,
				),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'success'           => array( 'type' => 'boolean' ),
				'error'             => array(
					'type'       => 'object',
					'properties' => array(
						'code'    => array( 'type' => 'string' ),
						'message' => array( 'type' => 'string' ),
						'field'   => array( 'type' => 'string' ),
					),
				),
				'dry_run'           => array( 'type' => 'boolean' ),
				'imported'          => array( 'type' => 'boolean' ),
				'slug'              => array( 'type' => 'string' ),
				'builder'           => array( 'type' => 'string' ),
				'plugins_installed' => array(
					'type'  => 'array',
					'items' => array( 'type' => 'string' ),
				),
				'plugins_planned'   => array(
					'type'  => 'array',
					'items' => array( 'type' => 'string' ),
				),
				'front_page_url'    => array( 'type' => 'string' ),
				'steps'             => array(
					'type'                 => 'object',
					'additionalProperties' => true,
				),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function run( array $input ) {
		if ( ! $this->tpc_available() ) {
			return $this->structured_error( 'tpc_unavailable', __( 'The starter sites library is not available.', 'neve-pro-addon' ) );
		}

		$slug    = isset( $input['slug'] ) ? $input['slug'] : '';
		$builder = isset( $input['builder'] ) ? $input['builder'] : null;
		$found   = $this->find_site( $slug, $builder );

		if ( null === $found ) {
			return $this->validation_issue( 'unknown_site', __( 'No starter site with that slug.', 'neve-pro-addon' ), 'slug' );
		}

		$site   = $found['data'];
		$editor = isset( $site['editor'] ) ? $site['editor'] : $found['builder'];
		$source = $this->site_url( $site );

		$json = $this->fetch_site_json( $site );
		if ( is_wp_error( $json ) ) {
			return $this->structured_error( $json->get_error_code(), $json->get_error_message() );
		}

		$planned_plugins = array();
		if ( ! isset( $input['with_plugins'] ) || $input['with_plugins'] ) {
			foreach ( array( 'mandatory_plugins', 'recommended_plugins' ) as $group ) {
				if ( isset( $json[ $group ] ) && is_array( $json[ $group ] ) ) {
					foreach ( array_keys( $json[ $group ] ) as $plugin_slug ) {
						$planned_plugins[ $plugin_slug ] = true;
					}
				}
			}
		}

		if ( ! empty( $input['dry_run'] ) ) {
			return array(
				'success'         => true,
				'dry_run'         => true,
				'imported'        => false,
				'slug'            => $slug,
				'builder'         => $found['builder'],
				'plugins_planned' => array_keys( $planned_plugins ),
				'steps'           => array(
					'plugins'    => ! empty( $planned_plugins ),
					'content'    => ! empty( $json['content_file'] ),
					'theme_mods' => ! empty( $json['theme_mods'] ),
					'widgets'    => ! empty( $json['widgets'] ),
				),
			);
		}

		if ( empty( $input['confirm'] ) ) {
			return $this->validation_issue( 'confirm_required', __( 'Set confirm=true to import this starter site, or use dry_run=true to inspect the plan.', 'neve-pro-addon' ), 'confirm' );
		}

		// Register the demo source URL so imported links/slugs are rewritten to
		// this site (the WP-CLI importer does this before any step runs).
		if ( '' !== $source && class_exists( '\TIOB\Importers\Helpers\Slug_Mapping' ) ) {
			\TIOB\Importers\Helpers\Slug_Mapping::register_source_url( $source );
		}

		// Ensure the cleanup state tracker is listening so starter-site-cleanup can
		// revert this import. TPC wires this behind its admin-gated bootstrap, which
		// does not run on an MCP request (user is authenticated after plugins_loaded).
		if ( class_exists( '\TIOB\Importers\Cleanup\Active_State' ) ) {
			( new \TIOB\Importers\Cleanup\Active_State() )->init();
		}

		$steps             = array();
		$plugins_installed = array();

		// 1. Plugins.
		if ( ! isset( $input['with_plugins'] ) || $input['with_plugins'] ) {
			$plugins = $planned_plugins;
			if ( ! empty( $plugins ) ) {
				$result           = $this->tpc_run( 'plugins', $plugins );
				$steps['plugins'] = $this->step_result( $result );
				if ( ! is_wp_error( $result ) ) {
					$plugins_installed = array_keys( $plugins );
				}
			}
		}

		// 2. Content.
		if ( ! empty( $json['content_file'] ) ) {
			$content_payload = array(
				'contentFile' => $json['content_file'],
				'source'      => 'remote', // Mode flag for the importer (download), not the source URL.
				'demoSlug'    => $slug,
				'editor'      => $editor,
			);
			if ( isset( $json['front_page'] ) ) {
				$content_payload['frontPage'] = $json['front_page'];
			}
			if ( isset( $json['shop_pages'] ) ) {
				$content_payload['shopPages'] = $json['shop_pages'];
			}
			$steps['content'] = $this->step_result( $this->tpc_run( 'content', $content_payload ) );
		}

		// 3. Theme mods.
		if ( ! empty( $json['theme_mods'] ) ) {
			$steps['theme_mods'] = $this->step_result(
				$this->tpc_run(
					'theme_mods',
					array(
						'source_url' => $source,
						'theme_mods' => $json['theme_mods'],
						'wp_options' => isset( $json['wp_options'] ) ? $json['wp_options'] : array(),
					)
				)
			);
		}

		// 4. Widgets.
		if ( ! empty( $json['widgets'] ) ) {
			$steps['widgets'] = $this->step_result(
				$this->tpc_run(
					'widgets',
					array(
						'source_url' => $source,
						'widgets'    => $json['widgets'],
					)
				)
			);
		}

		// "imported" is true only if every step that ran succeeded.
		$imported = true;
		foreach ( $steps as $step ) {
			if ( empty( $step['success'] ) ) {
				$imported = false;
			}
		}

		return array(
			'success'           => $imported,
			'imported'          => $imported,
			'slug'              => $slug,
			'builder'           => $found['builder'],
			'plugins_installed' => $plugins_installed,
			'plugins_planned'   => array_keys( $planned_plugins ),
			'front_page_url'    => home_url( '/' ),
			'steps'             => $steps,
		);
	}

	/**
	 * Normalize a step dispatch result into { success, error? }.
	 *
	 * @param array|\WP_Error $result Dispatch result.
	 * @return array
	 */
	private function step_result( $result ) {
		if ( is_wp_error( $result ) ) {
			return array(
				'success' => false,
				'error'   => $result->get_error_message(),
			);
		}

		$success = ! ( isset( $result['success'] ) && false === $result['success'] );

		return array( 'success' => $success );
	}
}
