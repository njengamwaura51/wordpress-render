<?php
/**
 * Shared Custom Layouts helpers.
 *
 * Meta-key constants and read/format helpers used by the custom-layout
 * abilities.
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */

namespace Neve_Pro\Modules\Abilities\Abilities;

/**
 * Class Custom_Layout_Helpers
 *
 * Base class for the custom-layout abilities. Holds the shared meta-key
 * constants and read/format helpers. (A class rather than a trait because the
 * constants would otherwise require PHP 8.2.)
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */
abstract class Custom_Layout_Helpers extends Abstract_Ability {

	/**
	 * The Custom Layouts post type.
	 */
	const CPT = 'neve_custom_layouts';

	/**
	 * Meta keys (mirrors Layouts_Metabox).
	 */
	const META_LAYOUT         = 'custom-layout-options-layout';
	const META_HOOK           = 'custom-layout-options-hook';
	const META_PRIORITY       = 'custom-layout-options-priority-v2';
	const META_CONDITIONAL    = 'custom-layout-conditional-logic';
	const META_HAS_EXPIRATION = 'custom-layout-options-should-expire';
	const META_EXPIRATION     = 'custom-layout-expiration-date';
	const META_SIDEBAR        = 'custom-layout-options-sidebar';
	const META_SIDEBAR_ACTION = 'custom-layout-options-sidebar-action';
	const META_INSIDE         = 'custom-layout-options-inside-display';
	const META_EVENTS_NO      = 'custom-layout-options-events-no';

	/**
	 * Layout types accepted by the upsert ability.
	 *
	 * @return string[]
	 */
	protected function layout_types() {
		if ( class_exists( '\Neve_Pro\Modules\Custom_Layouts\Utilities' ) ) {
			return array_keys( \Neve_Pro\Modules\Custom_Layouts\Utilities::get_layouts() );
		}

		return array( 'individual', 'header', 'inside', 'footer', 'hooks', 'not_found', 'single_post', 'single_page', 'search', 'archives', 'maintenance', 'coming_soon' );
	}

	/**
	 * Build a compact summary for a layout post.
	 *
	 * @param \WP_Post $post The layout post.
	 * @return array
	 */
	protected function summarize_layout( $post ) {
		$type = get_post_meta( $post->ID, self::META_LAYOUT, true );

		$summary = array(
			'id'                 => $post->ID,
			'title'              => $post->post_title,
			'type'               => $type ? $type : 'none',
			'priority'           => (int) get_post_meta( $post->ID, self::META_PRIORITY, true ),
			'status'             => $post->post_status,
			'conditions_summary' => $this->conditions_summary( get_post_meta( $post->ID, self::META_CONDITIONAL, true ) ),
		);

		if ( 'hooks' === $type ) {
			$summary['location'] = get_post_meta( $post->ID, self::META_HOOK, true );
		}

		if ( get_post_meta( $post->ID, self::META_HAS_EXPIRATION, true ) ) {
			$summary['expires'] = get_post_meta( $post->ID, self::META_EXPIRATION, true );
		}

		return $summary;
	}

	/**
	 * Build full detail for a layout post.
	 *
	 * @param \WP_Post $post            The layout post.
	 * @param bool     $include_content Whether to include the body.
	 * @return array
	 */
	protected function format_layout( $post, $include_content = false ) {
		$detail = array(
			'id'         => $post->ID,
			'title'      => $post->post_title,
			'type'       => get_post_meta( $post->ID, self::META_LAYOUT, true ),
			'hook'       => get_post_meta( $post->ID, self::META_HOOK, true ),
			'priority'   => (int) get_post_meta( $post->ID, self::META_PRIORITY, true ),
			'conditions' => $this->decode_conditions( get_post_meta( $post->ID, self::META_CONDITIONAL, true ) ),
			'status'     => $post->post_status,
			'expiration' => array(
				'enabled' => (bool) get_post_meta( $post->ID, self::META_HAS_EXPIRATION, true ),
				'date'    => get_post_meta( $post->ID, self::META_EXPIRATION, true ),
			),
			'edit_url'   => $this->edit_url( $post->ID ),
		);

		if ( $include_content ) {
			$detail['content'] = $post->post_content;
		}

		return $detail;
	}

	/**
	 * Build the admin edit URL for a layout.
	 *
	 * The core get_edit_post_link() returns empty outside an admin screen (e.g.
	 * on a REST request), so build the canonical edit URL directly.
	 *
	 * @param int $post_id The layout post id.
	 * @return string
	 */
	protected function edit_url( $post_id ) {
		return admin_url( 'post.php?post=' . (int) $post_id . '&action=edit' );
	}

	/**
	 * Decode the conditional-logic meta into groups.
	 *
	 * @param mixed $value Raw meta value (string when set, but get_post_meta may return other types).
	 * @return array
	 */
	protected function decode_conditions( $value ) {
		if ( ! is_string( $value ) || '' === $value ) {
			return array();
		}
		$decoded = json_decode( $value, true );

		return is_array( $decoded ) ? $decoded : array();
	}

	/**
	 * Human-readable one-line summary of the conditions.
	 *
	 * @param string $value Raw meta value.
	 * @return string
	 */
	protected function conditions_summary( $value ) {
		$groups = $this->decode_conditions( $value );
		if ( empty( $groups ) ) {
			return __( 'Everywhere', 'neve-pro-addon' );
		}

		$group_strings = array();
		foreach ( $groups as $group ) {
			if ( ! is_array( $group ) ) {
				continue;
			}
			$parts = array();
			foreach ( $group as $rule ) {
				if ( ! isset( $rule['root'] ) ) {
					continue;
				}
				$end       = isset( $rule['end'] ) ? ( is_array( $rule['end'] ) ? implode( ',', $rule['end'] ) : $rule['end'] ) : '';
				$condition = isset( $rule['condition'] ) ? $rule['condition'] : '===';
				$parts[]   = trim( $rule['root'] . ' ' . $condition . ' ' . $end );
			}
			if ( ! empty( $parts ) ) {
				$group_strings[] = implode( ' AND ', $parts );
			}
		}

		return empty( $group_strings ) ? __( 'Everywhere', 'neve-pro-addon' ) : implode( ' OR ', $group_strings );
	}
}
