<?php
/**
 * Ability: neve/starter-site-cleanup.
 *
 * Undo / reset a previous starter-site import. Ships alongside the import.
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */

namespace Neve_Pro\Modules\Abilities\Abilities;

/**
 * Class Starter_Site_Cleanup
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */
class Starter_Site_Cleanup extends Starter_Site_Helpers {

	/**
	 * {@inheritDoc}
	 */
	protected function get_id() {
		return 'starter-site-cleanup';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_label() {
		return __( 'Clean up a starter site import', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_description() {
		return __( 'Revert the most recent starter-site import: removes imported content, attachments, menus and restores previous settings.', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_capability() {
		return 'manage_options';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_annotations() {
		return array( 'destructive' => true );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_input_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'confirm' => array(
					'type'        => 'boolean',
					'description' => 'Must be true to proceed.',
					'default'     => false,
				),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'success'  => array( 'type' => 'boolean' ),
				'error'    => array(
					'type'       => 'object',
					'properties' => array(
						'code'    => array( 'type' => 'string' ),
						'message' => array( 'type' => 'string' ),
						'field'   => array( 'type' => 'string' ),
					),
				),
				'reverted' => array( 'type' => 'boolean' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function run( array $input ) {
		if ( empty( $input['confirm'] ) ) {
			return $this->validation_issue( 'confirm_required', __( 'Set confirm=true to revert the last import.', 'neve-pro-addon' ), 'confirm' );
		}

		if ( ! $this->tpc_available() ) {
			return $this->error( 'tpc_unavailable', __( 'The starter sites library is not available.', 'neve-pro-addon' ), 501 );
		}

		$result = $this->tpc_cleanup();

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return array(
			'success'  => true,
			'reverted' => true,
		);
	}
}
