<?php
/**
 * Ability: neve/pro-module-list.
 *
 * Readable Pro module state (split out of the toggle so it can be read-only).
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */

namespace Neve_Pro\Modules\Abilities\Abilities;

/**
 * Class Pro_Module_List
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */
class Pro_Module_List extends Abstract_Ability {
	use Helpers;

	/**
	 * {@inheritDoc}
	 */
	protected function get_id() {
		return 'pro-module-list';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_label() {
		return __( 'List Neve Pro modules', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_description() {
		return __( 'List Neve Pro modules with their slug, label, enabled state, required license tier, and whether they are force-enabled. Optionally include each module\'s internal status option key for debugging. Use the slug with pro-module-toggle.', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_capability() {
		return 'manage_options';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_annotations() {
		return array( 'readonly' => true );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_input_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'include_status_keys' => array(
					'type'        => 'boolean',
					'description' => 'Include each module\'s internal status option key in the response. Clients that cannot call this ability with an empty object may send include_status_keys=false.',
				),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'modules' => array(
					'type'  => 'array',
					'items' => array(
						'type'       => 'object',
						'properties' => array(
							'slug'          => array( 'type' => 'string' ),
							'label'         => array( 'type' => 'string' ),
							'enabled'       => array( 'type' => 'boolean' ),
							'license_tier'  => array( 'type' => 'integer' ),
							'force_enabled' => array( 'type' => 'boolean' ),
							'status_key'    => array( 'type' => 'string' ),
						),
					),
				),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function run( array $input ) {
		$modules             = array();
		$include_status_keys = ! empty( $input['include_status_keys'] );

		foreach ( $this->get_pro_modules() as $module ) {
			if ( ! $include_status_keys ) {
				unset( $module['status_key'] );
			}
			$modules[] = $module;
		}

		return array( 'modules' => $modules );
	}
}
