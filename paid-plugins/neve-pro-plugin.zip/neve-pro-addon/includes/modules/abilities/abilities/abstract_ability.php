<?php
/**
 * Base class for all Neve abilities.
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */

namespace Neve_Pro\Modules\Abilities\Abilities;

use Neve_Pro\Traits\Core;
use WP_Error;

/**
 * Class Abstract_Ability
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */
abstract class Abstract_Ability {
	use Core;

	/**
	 * Namespace prefix shared by every Neve ability id.
	 */
	const PREFIX = 'neve';

	/**
	 * The ability slug, appended to the prefix (e.g. "site-get-state" for
	 * "neve/site-get-state"). Must match `^[a-z0-9-]+$`.
	 *
	 * @return string
	 */
	abstract protected function get_id();

	/**
	 * Human readable ability label.
	 *
	 * @return string
	 */
	abstract protected function get_label();

	/**
	 * Human readable ability description (used by the agent to pick the tool).
	 *
	 * @return string
	 */
	abstract protected function get_description();

	/**
	 * The JSON Schema describing the ability input.
	 *
	 * @return array
	 */
	abstract protected function get_input_schema();

	/**
	 * The JSON Schema describing the ability output.
	 *
	 * @return array
	 */
	abstract protected function get_output_schema();

	/**
	 * Run the ability.
	 *
	 * @param array $input Validated input matching get_input_schema().
	 * @return array|WP_Error
	 */
	abstract protected function run( array $input );

	/**
	 * MCP annotation hints (readonly / destructive / idempotent).
	 *
	 * Only non-null values are forwarded to the Abilities API. Override per
	 * ability to advertise read-only reads and destructive writes.
	 *
	 * @return array
	 */
	protected function get_annotations() {
		return array(
			'readonly'    => null,
			'destructive' => null,
			'idempotent'  => null,
		);
	}

	/**
	 * The WordPress capability required to use the ability.
	 *
	 * @return string
	 */
	protected function get_capability() {
		return 'edit_theme_options';
	}

	/**
	 * The MCP primitive type. Everything Neve exposes is a tool.
	 *
	 * @return string
	 */
	protected function get_mcp_type() {
		return 'tool';
	}

	/**
	 * The full ability id (e.g. "neve/site-get-state").
	 *
	 * @return string
	 */
	public function get_full_id() {
		return self::PREFIX . '/' . $this->get_id();
	}

	/**
	 * Register the ability with the WordPress Abilities API.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		wp_register_ability(
			self::PREFIX . '/' . $this->get_id(),
			array(
				'label'               => $this->get_label(),
				'description'         => $this->get_description(),
				'category'            => self::PREFIX,
				'input_schema'        => $this->get_input_schema(),
				'output_schema'       => $this->get_output_schema(),
				'execute_callback'    => array( $this, 'execute' ),
				'permission_callback' => array( $this, 'check_permission' ),
				'meta'                => array(
					'show_in_rest' => false,
					'annotations'  => array_filter(
						$this->get_annotations(),
						function ( $value ) {
							return null !== $value;
						}
					),
					'mcp'          => array(
						'public' => true,
						'type'   => $this->get_mcp_type(),
					),
				),
			)
		);
	}

	/**
	 * Permission callback.
	 *
	 * @return bool
	 */
	public function check_permission() {
		return current_user_can( $this->get_capability() );
	}

	/**
	 * Execute callback. Normalizes input and delegates to run().
	 *
	 * @param array|null $input The validated input.
	 * @return array|WP_Error
	 */
	public function execute( $input = array() ) {
		if ( ! is_array( $input ) ) {
			$input = array();
		}

		return $this->run( $input );
	}

	/**
	 * Build a WP_Error with a namespaced code and an HTTP-ish status.
	 *
	 * @param string $code    Short error code (namespaced automatically).
	 * @param string $message Human readable message.
	 * @param int    $status  HTTP status code.
	 * @return WP_Error
	 */
	protected function error( $code, $message, $status = 400 ) {
		return new WP_Error( 'neve_ability_' . $code, $message, array( 'status' => $status ) );
	}

	/**
	 * Build a structured validation payload for clients that collapse WP_Error
	 * details into a generic transport error.
	 *
	 * @param string $code    Short validation code.
	 * @param string $message Human readable validation message.
	 * @param string $field   Optional field name tied to the validation issue.
	 * @return array
	 */
	protected function validation_issue( $code, $message, $field = '' ) {
		$error = array(
			'code'    => $code,
			'message' => $message,
		);

		if ( '' !== $field ) {
			$error['field'] = $field;
		}

		return array(
			'success' => false,
			'error'   => $error,
		);
	}

	/**
	 * Build a structured non-validation error payload for clients that collapse
	 * WP_Error details into a generic transport error.
	 *
	 * @param string $code    Short error code.
	 * @param string $message Human readable error message.
	 * @param string $field   Optional field tied to the error.
	 * @return array
	 */
	protected function structured_error( $code, $message, $field = '' ) {
		$error = array(
			'code'    => $code,
			'message' => $message,
		);

		if ( '' !== $field ) {
			$error['field'] = $field;
		}

		return array(
			'success' => false,
			'error'   => $error,
		);
	}

	/**
	 * Whether the current site has at least the given Pro license tier.
	 *
	 * @param int $tier Minimum tier (1 personal, 2 business, 3 agency).
	 * @return bool
	 */
	protected function has_license_tier( $tier = 1 ) {
		return $this->get_license_type() >= $tier;
	}
}
