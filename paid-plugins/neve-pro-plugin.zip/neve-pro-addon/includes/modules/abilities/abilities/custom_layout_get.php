<?php
/**
 * Ability: neve/custom-layout-get.
 *
 * Full detail for a single Custom Layout. Body inclusion is opt-in to protect
 * context.
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */

namespace Neve_Pro\Modules\Abilities\Abilities;

/**
 * Class Custom_Layout_Get
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */
class Custom_Layout_Get extends Custom_Layout_Helpers {

	/**
	 * {@inheritDoc}
	 */
	protected function get_id() {
		return 'custom-layout-get';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_label() {
		return __( 'Get custom layout', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_description() {
		return __( 'Get the full detail of a Custom Layout for safe edit-in-place. Set include_content=true to also return the body.', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_capability() {
		return 'edit_custom_layouts';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_annotations() {
		return array( 'readonly' => true );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_input_schema() {
		return array(
			'type'       => 'object',
			'required'   => array( 'id' ),
			'properties' => array(
				'id'              => array(
					'type'        => 'integer',
					'description' => 'The layout post id.',
				),
				'include_content' => array(
					'type'        => 'boolean',
					'default'     => false,
					'description' => 'Include the layout body.',
				),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_output_schema() {
		return array(
			'type'                 => 'object',
			'additionalProperties' => true,
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function run( array $input ) {
		$id   = isset( $input['id'] ) ? (int) $input['id'] : 0;
		$post = get_post( $id );

		if ( ! $post || self::CPT !== $post->post_type ) {
			return $this->error( 'not_found', __( 'No custom layout with that id.', 'neve-pro-addon' ), 404 );
		}

		return $this->format_layout( $post, ! empty( $input['include_content'] ) );
	}
}
