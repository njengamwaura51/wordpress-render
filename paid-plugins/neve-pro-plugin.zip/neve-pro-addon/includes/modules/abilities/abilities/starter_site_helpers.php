<?php
/**
 * Shared Starter Sites helpers.
 *
 * Thin access layer over the Templates Patterns Collection (TPC) plugin: the
 * site catalogue and the import/cleanup REST routes. We reuse TPC's own tested
 * handlers via rest_do_request rather than reimplementing the import.
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */

namespace Neve_Pro\Modules\Abilities\Abilities;

/**
 * Class Starter_Site_Helpers
 *
 * Base class for the starter-site abilities. (A class rather than a trait
 * because the constant would otherwise require PHP 8.2.)
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */
abstract class Starter_Site_Helpers extends Abstract_Ability {

	/**
	 * Whether the TPC importer is available.
	 *
	 * @return bool
	 */
	protected function tpc_available() {
		return class_exists( '\TIOB\Main' );
	}

	/**
	 * Get the starter-site catalogue keyed by builder => slug => data.
	 *
	 * Reads the `themeisle-demo-import` theme support that TPC registers
	 * unconditionally, rather than going through TPC's `admin` object: on a REST
	 * (MCP) request the current user is set after `plugins_loaded`, so TPC's
	 * admin-gated bootstrap may not have run and `Main->admin` can be null.
	 *
	 * @return array
	 */
	protected function get_sites() {
		if ( ! $this->tpc_available() ) {
			return array();
		}

		$sites = $this->read_demo_support();

		// Cold case (empty transient / support not registered yet): let TPC
		// re-run its own registration, then re-read.
		if ( empty( $sites ) && class_exists( '\TIOB\Sites_Listing' ) ) {
			( new \TIOB\Sites_Listing() )->init();
			$sites = $this->read_demo_support();
		}

		return $sites;
	}

	/**
	 * Read the registered demo-import theme support catalogue.
	 *
	 * @return array
	 */
	private function read_demo_support() {
		$support = get_theme_support( 'themeisle-demo-import' );

		if ( is_array( $support ) && isset( $support[0]['remote'] ) && is_array( $support[0]['remote'] ) ) {
			return $support[0]['remote'];
		}

		return array();
	}

	/**
	 * Find a single site descriptor by slug (optionally constrained to a builder).
	 *
	 * @param string      $slug    Site slug.
	 * @param string|null $builder Builder to search within.
	 * @return array|null { builder, data }
	 */
	protected function find_site( $slug, $builder = null ) {
		foreach ( $this->get_sites() as $builder_key => $sites ) {
			if ( null !== $builder && $builder !== $builder_key ) {
				continue;
			}
			if ( isset( $sites[ $slug ] ) && is_array( $sites[ $slug ] ) ) {
				return array(
					'builder' => $builder_key,
					'data'    => $sites[ $slug ],
				);
			}
		}

		return null;
	}

	/**
	 * The demo site's base URL (used for source_url and the per-site JSON).
	 *
	 * @param array $site The site descriptor.
	 * @return string
	 */
	protected function site_url( array $site ) {
		if ( ! empty( $site['url'] ) ) {
			return $site['url'];
		}

		return ! empty( $site['remote_url'] ) ? $site['remote_url'] : '';
	}

	/**
	 * Map of import steps to their TPC importer class + method.
	 */
	const IMPORTERS = array(
		'plugins'    => array( '\TIOB\Importers\Plugin_Importer', 'install_plugins' ),
		'content'    => array( '\TIOB\Importers\Content_Importer', 'import_remote_xml' ),
		'theme_mods' => array( '\TIOB\Importers\Theme_Mods_Importer', 'import_theme_mods' ),
		'widgets'    => array( '\TIOB\Importers\Widgets_Importer', 'import_widgets' ),
	);

	/**
	 * Run a single import step by invoking the TPC importer class directly.
	 *
	 * We call the importer instead of dispatching to the `ti-sites-lib/v1` REST
	 * routes: TPC only registers those routes when its admin-gated bootstrap runs
	 * (`current_user_can('manage_options')` at `plugins_loaded`), which is false on
	 * an MCP request where the user is authenticated later. The importer classes
	 * are always autoloadable, so we build the same JSON request they expect and
	 * call them in-process.
	 *
	 * @param string $step    One of self::IMPORTERS keys.
	 * @param array  $payload JSON body the importer reads via get_json_params().
	 * @return array|\WP_Error
	 */
	protected function tpc_run( $step, array $payload ) {
		if ( ! isset( self::IMPORTERS[ $step ] ) ) {
			return new \WP_Error( 'neve_ability_unknown_step', 'Unknown import step.' );
		}

		list( $class, $method ) = self::IMPORTERS[ $step ];

		if ( ! class_exists( $class ) ) {
			/* translators: %s: importer step name */
			return new \WP_Error( 'neve_ability_importer_missing', sprintf( 'The %s importer is not available.', $step ) );
		}

		$request = new \WP_REST_Request( 'POST', '/neve-abilities/import-' . $step );
		$request->add_header( 'content-type', 'application/json' );
		$request->set_body( wp_json_encode( $payload ) );

		$response = ( new $class() )->$method( $request );

		return $this->normalize_tpc_response( $response );
	}

	/**
	 * Normalize a TPC importer response into data or a WP_Error.
	 *
	 * @param mixed $response The importer return value.
	 * @return array|\WP_Error
	 */
	private function normalize_tpc_response( $response ) {
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$data = $response instanceof \WP_REST_Response ? $response->get_data() : $response;

		if ( is_array( $data ) && isset( $data['success'] ) && false === $data['success'] ) {
			$message = ( isset( $data['data'] ) && is_string( $data['data'] ) ) ? $data['data'] : 'Import step failed.';
			return new \WP_Error( 'neve_ability_import_step', $message );
		}

		return is_array( $data ) ? $data : array();
	}

	/**
	 * Run the TPC cleanup (revert the last import).
	 *
	 * @return array|\WP_Error
	 */
	protected function tpc_cleanup() {
		if ( ! class_exists( '\TIOB\Importers\Cleanup\Manager' ) ) {
			return new \WP_Error( 'neve_ability_cleanup_missing', __( 'The starter sites cleanup is not available.', 'neve-pro-addon' ) );
		}

		return (array) \TIOB\Importers\Cleanup\Manager::instance()->do_cleanup();
	}

	/**
	 * Fetch the per-site demo JSON (theme_mods / widgets / plugins / pages).
	 *
	 * @param array $site The site descriptor.
	 * @return array|\WP_Error
	 */
	protected function fetch_site_json( array $site ) {
		$url = $this->site_url( $site );
		if ( '' === $url ) {
			return new \WP_Error( 'neve_ability_no_source', __( 'The starter site has no source URL.', 'neve-pro-addon' ) );
		}

		$response = $this->remote_get(
			trailingslashit( $url ) . 'wp-json/ti-demo-data/data',
			array(
				'timeout' => 30, //phpcs:ignore WordPressVIPMinimum.Performance.RemoteRequestTimeout.timeout_timeout, On VIP the Core::remote_get wrapper ignores this and uses the safe default.
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		if ( 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			return new \WP_Error( 'neve_ability_site_json', __( 'Could not fetch the starter site data.', 'neve-pro-addon' ) );
		}

		$json = json_decode( wp_remote_retrieve_body( $response ), true );

		return is_array( $json ) ? $json : new \WP_Error( 'neve_ability_site_json', __( 'The starter site data was malformed.', 'neve-pro-addon' ) );
	}
}
