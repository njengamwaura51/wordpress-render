<?php
/**
 * Ability: neve/site-set-performance.
 *
 * The four Neve Pro performance booleans.
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */

namespace Neve_Pro\Modules\Abilities\Abilities;

/**
 * Class Site_Set_Performance
 *
 * @package Neve_Pro\Modules\Abilities\Abilities
 */
class Site_Set_Performance extends Abstract_Ability {

	/**
	 * Map of friendly input keys to their underlying option keys.
	 */
	const OPTION_MAP = array(
		'remove_emoji'       => 'nv_pro_enable_emoji_removal',
		'remove_oembed'      => 'nv_pro_enable_embedded_removal',
		'local_google_fonts' => 'nv_pro_enable_local_fonts',
		'content_visibility' => 'nv_pro_enable_lazy_content',
	);

	/**
	 * {@inheritDoc}
	 */
	protected function get_id() {
		return 'site-set-performance';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_label() {
		return __( 'Set performance options', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_description() {
		return __( 'Toggle Neve performance optimizations: remove emoji scripts, remove oEmbed scripts, locally host Google fonts, and lazy-render off-screen content. Send only the keys you want to change.', 'neve-pro-addon' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_capability() {
		return 'manage_options';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_annotations() {
		return array(
			'destructive' => false,
			'idempotent'  => true,
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_input_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'remove_emoji'       => array(
					'type'        => 'boolean',
					'description' => 'Remove WordPress emoji scripts.',
				),
				'remove_oembed'      => array(
					'type'        => 'boolean',
					'description' => 'Remove oEmbed host scripts.',
				),
				'local_google_fonts' => array(
					'type'        => 'boolean',
					'description' => 'Host external (Google) fonts locally.',
				),
				'content_visibility' => array(
					'type'        => 'boolean',
					'description' => 'Lazy-render off-screen content with content-visibility.',
				),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'updated' => array(
					'type'  => 'array',
					'items' => array( 'type' => 'string' ),
				),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function run( array $input ) {
		$updated = array();

		foreach ( self::OPTION_MAP as $key => $option ) {
			if ( ! array_key_exists( $key, $input ) ) {
				continue;
			}

			update_option( $option, (bool) $input[ $key ] );
			$updated[] = $key;
		}

		if ( empty( $updated ) ) {
			return $this->error( 'no_changes', __( 'No performance options were provided.', 'neve-pro-addon' ) );
		}

		return array( 'updated' => $updated );
	}
}
