<?php
/**
 * Abilities module.
 *
 * Registers Neve abilities against the WordPress Abilities API so MCP clients
 * (Neve Agency and others) can drive Neve sites. The surface intentionally
 * spans both Neve (free) and Neve Pro features so a Pro-enabled site exposes a
 * single, coherent product. Neve Pro is the gate: this only runs when Pro is
 * present, and abilities only register when the Abilities API is available.
 *
 * @package Neve_Pro\Modules\Abilities
 */

namespace Neve_Pro\Modules\Abilities;

use Neve_Pro\Modules\Abilities\Abilities\Abstract_Ability;
use Neve_Pro\Modules\Abilities\Abilities\Free_Extensions;

/**
 * Class Module
 *
 * This is an always-on core component (declared in the loader's core modules),
 * not a pluggable dashboard module: there is nothing for a user to toggle and
 * the surface is gated only by Neve Pro being active.
 *
 * @package Neve_Pro\Modules\Abilities
 */
class Module {

	/**
	 * The ability category slug shared by all Neve abilities.
	 */
	const CATEGORY = 'neve';

	/**
	 * Cached list of ability class names (relative to the Abilities namespace).
	 *
	 * @var string[]
	 */
	private $abilities = array(
		// Cluster 1 - grounding reads.
		'Site_Get_State',
		'Header_List_Components',
		'Custom_Layout_Get_Condition_Schema',
		'Pro_Module_List',
		// Cluster 2 - brand & design writes.
		'Appearance_Update',
		'Appearance_Apply_Preset',
		// Cluster 3 - header / footer / menus.
		'Header_Configure',
		'Footer_Configure',
		'Site_Configure_Menu',
		'Site_Delete_Menu',
		// Cluster 4 - custom layouts.
		'Custom_Layout_List',
		'Custom_Layout_Get',
		'Custom_Layout_Upsert',
		'Custom_Layout_Delete',
		'Custom_Layout_Set_Status',
		'Custom_Layout_Set_Site_Mode',
		// Cluster 5 - starter sites.
		'Starter_Site_List',
		'Starter_Site_Import',
		'Starter_Site_Cleanup',
		// Cluster 6 - site ops & Pro modules.
		'Site_Set_Performance',
		'Site_Set_Theme_Mod',
		'Pro_Module_Toggle',
	);

	/**
	 * Initialize the module.
	 *
	 * @return void
	 */
	public function init() {
		// The Abilities API ships separately (e.g. bundled by Neve Agency or
		// WordPress 6.9+). Stay inert when it is not loaded.
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		add_action( 'wp_abilities_api_categories_init', array( $this, 'register_category' ) );
		add_action( 'wp_abilities_api_init', array( $this, 'register_abilities' ) );

		// Pro fields, settings and state for the abilities the Neve theme owns.
		( new Free_Extensions() )->init();
	}

	/**
	 * Ability ids (e.g. "neve/site-get-state") registered by the Neve theme.
	 *
	 * Newer versions of the theme own the shared abilities; Neve Pro then only
	 * extends them and keeps registering the Pro-only ones.
	 *
	 * @return string[]
	 */
	private function get_theme_owned_ids() {
		if ( ! class_exists( '\Neve\Abilities\Loader' ) ) {
			return array();
		}

		return (array) \Neve\Abilities\Loader::get_owned_ids();
	}

	/**
	 * Register the shared "neve" ability category.
	 *
	 * @return void
	 */
	public function register_category() {
		if ( ! function_exists( 'wp_register_ability_category' ) ) {
			return;
		}

		// The theme registers the same category when it owns the shared abilities.
		if ( ! empty( $this->get_theme_owned_ids() ) ) {
			return;
		}

		wp_register_ability_category(
			self::CATEGORY,
			array(
				'label'       => __( 'Neve', 'neve-pro-addon' ),
				'description' => __( 'Read and configure the Neve theme and Neve Pro features.', 'neve-pro-addon' ),
			)
		);
	}

	/**
	 * Register all Neve abilities.
	 *
	 * @return void
	 */
	public function register_abilities() {
		/**
		 * Filters the list of Neve ability class short-names to register.
		 *
		 * @param string[] $abilities Class names relative to the
		 *                            Neve_Pro\Modules\Abilities\Abilities namespace.
		 */
		$abilities = apply_filters( 'neve_pro_abilities', $this->abilities );
		$theme_ids = $this->get_theme_owned_ids();

		foreach ( $abilities as $short_name ) {
			$class = __NAMESPACE__ . '\\Abilities\\' . $short_name;

			if ( ! class_exists( $class ) ) {
				continue;
			}

			$ability = new $class();

			if ( ! $ability instanceof Abstract_Ability ) {
				continue;
			}

			// Registered once, by the theme.
			if ( in_array( $ability->get_full_id(), $theme_ids, true ) ) {
				continue;
			}

			$ability->register();
		}
	}
}
